(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))r(t);new MutationObserver(t=>{for(const d of t)if(d.type==="childList")for(const e of d.addedNodes)e.tagName==="LINK"&&e.rel==="modulepreload"&&r(e)}).observe(document,{childList:!0,subtree:!0});function a(t){const d={};return t.integrity&&(d.integrity=t.integrity),t.referrerPolicy&&(d.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?d.credentials="include":t.crossOrigin==="anonymous"?d.credentials="omit":d.credentials="same-origin",d}function r(t){if(t.ep)return;t.ep=!0;const d=a(t);fetch(t.href,d)}})();const ce=3,ve="v0.1.3",Fe="2026-11-15",Zn="https://terryfantpe.github.io/tstock-data/videoplayer/app_manifest.json",Xn="https://raw.githubusercontent.com/terryfantpe/tstock-data/main/videoplayer/app_manifest.json",Qn="v0.1.3 — 全面升級「全螢幕橫屏劇院級播放器 (Fullscreen Landscape Cinema UI)」：啟動直接鎖定全螢幕橫向模式 (sensorLandscape)、100vw×100dvh 零壓縮全畫面視訊舞台、極簡單行懸浮頂欄與底欄 (3 秒自動隱藏)、預設隱藏手勢導覽格線、並整合進階工具至設定中心";let _e=null;function He(){try{if(typeof window<"u"){const n=window.OmniPlayOTA||window.GroundOTA||window.ZiweiOTA;if(n&&typeof n.getOtaInfo=="function"){const o=n.getOtaInfo();if(o)return typeof o=="string"?JSON.parse(o):o}if(_e)return _e}}catch(n){console.warn("[OmniPlayOTA] Failed to read native OTA info:",n)}return null}async function xn(){var n,o,a;try{if(typeof window<"u"){const r=window.OmniPlayOTA||window.GroundOTA||window.ZiweiOTA;if(r&&typeof r.getOtaInfo=="function"){const d=r.getOtaInfo();if(d)return typeof d=="string"?JSON.parse(d):d}const t=((n=window.__TAURI_INTERNALS__)==null?void 0:n.invoke)||((a=(o=window.__TAURI__)==null?void 0:o.core)==null?void 0:a.invoke);if(typeof t=="function"){const d=await t("ota_get_info");if(d&&typeof d=="object")return _e=d,d}}}catch(r){console.warn("[OmniPlayOTA] Failed to refresh async OTA info:",r)}return He()}const f={nativeInfo:null,checking:!1,remoteManifest:null,fetchError:null,updating:!1,progressPct:0,progressMsg:"",confirmRollback:!1,apkUpgradeInProgress:!1,apkRetryQueue:[]};let Sn=!1,En=0;function Yn(n){return String(n??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function he(){return typeof window>"u"?null:window.OmniPlayOTA||window.GroundOTA||window.ZiweiOTA||null}function be(n){typeof window<"u"&&typeof window._showOmniPlayToast=="function"&&window._showOmniPlayToast(n)}function $e(n){return typeof n!="number"||!Number.isFinite(n)||n<=0?"--":n>=1024*1024?`${(n/(1024*1024)).toFixed(2)} MB`:`${(n/1024).toFixed(2)} KB`}function Se(){var n;return Math.max(ce,Number((n=f.nativeInfo)==null?void 0:n.effectiveVersion)||0)}function Jn(){var s,c;const n=Se(),o=typeof((s=f.remoteManifest)==null?void 0:s.version)=="number"?f.remoteManifest.version:null,a=f.nativeInfo,r=typeof((c=f.remoteManifest)==null?void 0:c.min_apk_version)=="number"?f.remoteManifest.min_apk_version:1,t=!!a&&o!==null&&(a.apkVersionCode||1)<r,d=o!==null&&o>n&&!t,e=d?`✨ v${o}`:`${ve}`;return`
    <div class="ota-nav-controls">
      <span
        class="version-badge${d?" has-update":""}"
        id="header-version-badge"
        role="button"
        tabindex="0"
        onclick="window.openOtaModal && window.openOtaModal()"
        onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();window.openOtaModal&&window.openOtaModal();}"
        title="點擊開啟 P2R-OTA 雲端熱更新與 APK 升級中心"
      >${Yn(e)}</span>
      <button
        type="button"
        class="header-ota-direct-btn ota-header-btn${d?" has-update":""}"
        id="btn-header-ota-direct"
        onclick="window.openOtaModal && window.openOtaModal()"
        title="雲端線上熱更新 (P2R-OTA) 與原生 APK 升級"
      >
        <span id="ota-header-btn-label">☁️ 更新</span>
        <span class="ota-dot" id="ota-header-direct-dot"${d?"":" hidden"}></span>
      </button>
    </div>
  `}function Dn(){var o,a,r,t,d,e;if(typeof document>"u"||!document.body)return null;let n=document.getElementById("ota-modal-backdrop");return n||(n=document.createElement("div"),n.className="ota-modal-backdrop",n.id="ota-modal-backdrop",n.setAttribute("role","dialog"),n.setAttribute("aria-modal","true"),n.setAttribute("aria-labelledby","ota-modal-title"),n.setAttribute("hidden",""),n.innerHTML=`
      <div class="ota-modal-card" id="ota-modal-card">
        <div class="ota-modal-header">
          <div class="ota-title-wrap">
            <span class="ota-cloud-icon" aria-hidden="true">☁️</span>
            <div>
              <h2 class="ota-title-main" id="ota-modal-title">OmniPlay Pro · 雲端 OTA 熱更新中心</h2>
              <p class="ota-title-sub" id="ota-modal-subtitle">P2R-OTA 差分前端熱重載 ＆ Tier-3 原生 APK 自升級系統</p>
            </div>
          </div>
          <button type="button" class="ota-close-btn" id="btn-close-ota-modal">✕ 關閉</button>
        </div>

        <!-- Data Isolation Safety Banner -->
        <div class="ota-safety-banner">
          <span class="ota-safety-icon" aria-hidden="true">🛡️</span>
          <div>
            <strong id="ota-safety-title">亮度記憶與播放設定 100% 安全保留：</strong>
            <span id="ota-safety-desc">雲端熱更新僅更新前端介面與核心邏輯，您的亮度記憶、音量、硬體解碼與播放進度均完整保留。</span>
          </div>
        </div>

        <!-- Local Telemetry Box -->
        <div class="ota-telemetry-box">
          <div class="ota-telemetry-row">
            <span class="ota-label" id="ota-lbl-local-ver">目前運作版本</span>
            <strong class="ota-val" id="ota-local-ver-text">OTA v${ce} (${ve} · ${Fe})</strong>
          </div>
          <div class="ota-telemetry-row">
            <span class="ota-label" id="ota-lbl-base-core">底層核心基座</span>
            <strong class="ota-val" id="ota-base-core-text">Web Runtime</strong>
          </div>
          <div class="ota-telemetry-row">
            <span class="ota-label" id="ota-lbl-engine-layer">目前載入圖層</span>
            <strong class="ota-val ota-engine-tag" id="ota-engine-layer-text">Web 瀏覽器直連模式</strong>
          </div>
          <div class="ota-telemetry-row" id="ota-local-hash-row" hidden>
            <span class="ota-label" id="ota-lbl-local-hash">本地套件雜湊 (SHA-256)</span>
            <code class="ota-code" id="ota-local-hash-text">--</code>
          </div>
        </div>

        <!-- Remote Cloud Node Box -->
        <div class="ota-remote-box" id="ota-remote-box">
          <div class="ota-remote-header">
            <span class="ota-remote-title" id="ota-remote-node-title">🌐 GitHub 雲端發佈節點 (tstock-data/videoplayer)</span>
            <button type="button" class="ota-refresh-btn" id="btn-ota-check-manifest">🔄 重新檢查</button>
          </div>

          <div class="ota-status-hint" id="ota-checking-hint" hidden>
            ⏳ 正在連線 GitHub 雲端節點檢查最新清單...
          </div>

          <div class="ota-error-hint" id="ota-error-hint" hidden></div>

          <div class="ota-manifest-details" id="ota-manifest-details" hidden>
            <div class="ota-telemetry-row">
              <span class="ota-label" id="ota-lbl-remote-ver">雲端最新版本</span>
              <strong class="ota-val" id="ota-remote-ver-text">--</strong>
            </div>
            <div class="ota-telemetry-row">
              <span class="ota-label" id="ota-lbl-remote-size">熱更套件大小</span>
              <span class="ota-val" id="ota-remote-size-text">--</span>
            </div>
            <div class="ota-telemetry-row" id="ota-remote-delta-row" hidden>
              <span class="ota-label" id="ota-lbl-remote-delta">差異更新檔案</span>
              <span class="ota-val" id="ota-remote-delta-text" style="color: #38bdf8;">--</span>
            </div>
            <div class="ota-telemetry-row">
              <span class="ota-label" id="ota-lbl-remote-time">雲端發佈時間</span>
              <span class="ota-val" id="ota-remote-time-text">--</span>
            </div>
            <div class="ota-telemetry-row">
              <span class="ota-label" id="ota-lbl-remote-hash">雲端 SHA-256 校驗碼</span>
              <code class="ota-code" id="ota-remote-hash-text">--</code>
            </div>
            <div class="ota-changelog-box">
              <div class="ota-changelog-title" id="ota-lbl-changelog">📋 版本更新日誌 (Changelog)</div>
              <div id="ota-remote-changelog-text">--</div>
            </div>
          </div>

          <div class="ota-apk-old-warn" id="ota-apk-old-warn" hidden></div>
        </div>

        <!-- Live Progress Bar -->
        <div class="ota-progress-wrap" id="ota-progress-wrap" hidden>
          <div class="ota-progress-meta">
            <span id="ota-progress-msg">正在同步雲端更新套件...</span>
            <strong id="ota-progress-pct">0%</strong>
          </div>
          <div class="ota-progress-track">
            <div class="ota-progress-fill" id="ota-progress-fill" style="width: 0%;"></div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="ota-actions-col">
          <button type="button" class="ota-btn-primary" id="btn-ota-start-update">
            ⚡ 立即強制同步雲端最新版本
          </button>
          <button
            type="button"
            class="ota-btn-apk-tier3"
            id="btn-ota-upgrade-apk"
            hidden
          >
            📦 下載並安裝最新完整版 APK (Tier-3 原生自升級)
          </button>
          <button
            type="button"
            class="ota-btn-apk-browser"
            id="btn-ota-browser-apk"
            hidden
          >
            🌐 使用系統瀏覽器直接下載最新 APK
          </button>
          <button type="button" class="ota-btn-rollback" id="btn-ota-rollback" hidden>
            ⏪ 還原為 APK 內建出廠版本 (v${ce})
          </button>
        </div>
      </div>
    `,document.body.appendChild(n),n.addEventListener("click",s=>{s.target&&s.target.id==="ota-modal-backdrop"&&Le()}),(o=document.getElementById("btn-close-ota-modal"))==null||o.addEventListener("click",Le),(a=document.getElementById("btn-ota-check-manifest"))==null||a.addEventListener("click",()=>{Ee(!1)}),(r=document.getElementById("btn-ota-start-update"))==null||r.addEventListener("click",()=>{ei()}),(t=document.getElementById("btn-ota-upgrade-apk"))==null||t.addEventListener("click",()=>{We()}),(d=document.getElementById("btn-ota-browser-apk"))==null||d.addEventListener("click",()=>{Ce()}),(e=document.getElementById("btn-ota-rollback"))==null||e.addEventListener("click",()=>{ni()})),!Sn&&typeof document<"u"&&(Sn=!0,document.addEventListener("keydown",s=>{if(s.key==="Escape"){const c=document.getElementById("ota-modal-backdrop");c&&!c.hasAttribute("hidden")&&Le()}})),n}function oe(){var k,Z,ne,ie;if(typeof document>"u")return;const n=document.getElementById("ota-modal-card"),o=document.getElementById("ota-remote-box"),a=document.getElementById("ota-local-ver-text"),r=document.getElementById("ota-base-core-text"),t=document.getElementById("ota-engine-layer-text"),d=document.getElementById("ota-local-hash-row"),e=document.getElementById("ota-local-hash-text"),s=document.getElementById("btn-ota-check-manifest"),c=document.getElementById("btn-close-ota-modal"),m=document.getElementById("ota-checking-hint"),p=document.getElementById("ota-error-hint"),h=document.getElementById("ota-manifest-details"),b=document.getElementById("ota-remote-ver-text"),A=document.getElementById("ota-remote-size-text"),T=document.getElementById("ota-remote-time-text"),V=document.getElementById("ota-remote-hash-text"),L=document.getElementById("ota-remote-changelog-text"),O=document.getElementById("ota-apk-old-warn"),C=document.getElementById("ota-progress-wrap"),x=document.getElementById("ota-progress-msg"),P=document.getElementById("ota-progress-pct"),$=document.getElementById("ota-progress-fill"),y=document.getElementById("btn-ota-start-update"),D=document.getElementById("btn-ota-upgrade-apk"),S=document.getElementById("btn-ota-browser-apk"),E=document.getElementById("btn-ota-rollback"),M=document.getElementById("ota-header-direct-dot"),F=document.getElementById("btn-header-ota-direct"),I=f.nativeInfo,G=!!I,H=he(),z=!!(H&&typeof H.downloadAndInstallApk=="function"),j=Se(),Q=typeof((k=f.remoteManifest)==null?void 0:k.version)=="number"?f.remoteManifest.version:null,se=typeof((Z=f.remoteManifest)==null?void 0:Z.min_apk_version)=="number"?f.remoteManifest.min_apk_version:1,te=G&&Q!==null&&(I.apkVersionCode||1)<se,W=Q!==null&&Q>j&&!te;M&&(M.hidden=!W,W?M.removeAttribute("hidden"):M.setAttribute("hidden","")),F&&F.classList.toggle("has-update",W);const Y=document.getElementById("header-version-badge");Y&&(Y.textContent=W?`✨ v${Q}`:`${ve}`,Y.classList.toggle("has-update",W));const R=document.getElementById("settings-ota-ver-label");R&&(R.textContent=`OTA v${j} (${ve} · ${Fe})`);const v=document.getElementById("settings-ota-layer-label");if(v&&(G?v.textContent=I.isOtaActive?`🟢 雲端熱更圖層 (web_live v${I.localOtaVersion||j})`:`📦 APK 內建出廠圖層 (v${I.apkVersionCode||ce})`:v.textContent="🌐 Web 瀏覽器直連執行環境"),n&&n.classList.toggle("has-update",W),o&&o.classList.toggle("has-update",W),c&&(c.hidden=f.updating),a&&(a.textContent=`OTA v${j} (${ve} · ${Fe})`),r)if(G){const N=String(I.apkVersionName||ve).replace(/^v/i,"");r.textContent=`Android APK Core #${I.apkVersionCode||ce} (v${N})`}else r.textContent="Web Runtime (Vite ES Module)";if(t&&(G?I.isOtaActive?(t.textContent=`🟢 雲端熱更圖層啟用中 (web_live v${I.localOtaVersion||j})`,t.style.color="#2ecc71"):(t.textContent=`📦 APK 內建資產圖層 (v${I.apkVersionCode||ce})`,t.style.color="#f6c050"):(t.textContent="🌐 Web 瀏覽器直連模式",t.style.color="#38bdf8")),d&&e&&(I!=null&&I.bundleHash&&I.isOtaActive?(d.hidden=!1,d.removeAttribute("hidden"),e.textContent=`${String(I.bundleHash).slice(0,16)}...`):(d.hidden=!0,d.setAttribute("hidden",""))),s&&(s.disabled=f.checking||f.updating,s.textContent=f.checking?"⏳ 檢查中...":"🔄 重新檢查"),m){const N=f.checking&&!f.remoteManifest;m.hidden=!N,N?m.removeAttribute("hidden"):m.setAttribute("hidden","")}if(p&&(f.fetchError?(p.hidden=!1,p.removeAttribute("hidden"),p.textContent=`⚠️ ${f.fetchError}`):(p.hidden=!0,p.setAttribute("hidden",""))),h){const N=f.remoteManifest;if(N){if(h.hidden=!1,h.removeAttribute("hidden"),b){const ee=N.display_version||N.version_name||`v0.1.${N.version}`;b.textContent=`OTA v${N.version} (${ee}) ${W?" — ✨ 發現新版本可升級！":" — ✓ 已是最新同步狀態"}`,b.style.color=W?"#4ade80":"#f6c050"}A&&(A.textContent=$e(N.bundle_size)),T&&(T.textContent=N.published_at||"--"),V&&(V.textContent=N.bundle_hash?`${String(N.bundle_hash).slice(0,16)}...`:"--"),L&&(L.textContent=N.changelog||Qn)}else h.hidden=!0,h.setAttribute("hidden","")}if(O&&(te?(O.hidden=!1,O.removeAttribute("hidden"),O.textContent=`⚠️ 此雲端熱更新需要底層 APK 版本 ≥ v${se}，請點擊下方綠色按鈕直接升級完整 APK！`):(O.hidden=!0,O.setAttribute("hidden",""))),C&&x&&P&&$&&(f.updating||f.progressMsg?(C.hidden=!1,C.removeAttribute("hidden"),x.textContent=f.progressMsg||"正在同步雲端更新套件...",P.textContent=f.updating?`${f.progressPct}%`:"100%",$.style.width=`${f.updating?f.progressPct:100}%`):(C.hidden=!0,C.setAttribute("hidden",""))),y&&(y.disabled=f.updating||te,y.classList.toggle("has-update",W),f.updating?y.textContent="⏳ 正在下載並套用雲端熱更新...":W?y.textContent=`🚀 立即熱更新至 OTA v${Q} (${$e((ne=f.remoteManifest)==null?void 0:ne.bundle_size)})`:G?y.textContent=`⚡ 強制重新同步雲端熱更套件${Q?` (v${Q})`:""}`:y.textContent="🔄 重新整理並清除快取載入最新版"),D)if(z){D.hidden=!1,D.removeAttribute("hidden"),D.disabled=f.updating;const ee=Number((ie=f.remoteManifest)==null?void 0:ie.apk_size)||0,de=ee>0?` (${$e(ee)})`:"";D.textContent=`📦 下載並安裝最新完整版 APK${de}`}else D.hidden=!0,D.setAttribute("hidden","");if(S&&(S.hidden=!1,S.removeAttribute("hidden"),S.disabled=!1,S.textContent="🌐 直接下載最新 Android APK 安裝包 (Videoplayer.apk)"),E)if(G&&(I!=null&&I.isOtaActive)){const N=I.apkVersionCode||ce;E.hidden=!1,E.removeAttribute("hidden"),E.disabled=f.updating,E.classList.toggle("is-confirming",f.confirmRollback),E.textContent=f.confirmRollback?`⚠️ 確定要清除雲端熱更並還原至出廠 v${N} 嗎？（再次點擊確認）`:`⏪ 還原為 APK 內建出廠版本 (v${N})`}else E.hidden=!0,E.setAttribute("hidden","")}async function Ee(n=!1){const o=typeof n=="object"?!!(n!=null&&n.silent):!!n;if(f.checking=!0,f.fetchError=null,oe(),typeof fetch!="function")return f.checking=!1,oe(),null;const a=[`${Zn}?t=${Date.now()}`,`${Xn}?t=${Date.now()}`];let r=null;for(const t of a){const d=typeof AbortController<"u"?new AbortController:null,e=d?setTimeout(()=>d.abort(),6e3):null;try{const s=await fetch(t,{cache:"no-store",signal:d?d.signal:void 0});if(e&&clearTimeout(e),!s.ok)throw new Error(`HTTP ${s.status}`);const c=await s.json();f.remoteManifest=c,f.fetchError=null;const m=Se(),p=typeof(c==null?void 0:c.min_apk_version)=="number"?c.min_apk_version:1,h=!!f.nativeInfo&&(f.nativeInfo.apkVersionCode||1)<p;return o&&typeof(c==null?void 0:c.version)=="number"&&c.version>m&&!h?be(`☁️ 發現新版雲端熱更 OTA v${c.version}，可點擊右上角「線上更新」升級！`):o||be(`✅ 已取得雲端最新版本資訊 (OTA v${(c==null?void 0:c.version)||ce})`),f.checking=!1,oe(),c}catch(s){e&&clearTimeout(e),r=s}}return f.checking=!1,f.fetchError=(r==null?void 0:r.name)==="AbortError"?"連線雲端更新節點逾時，請檢查網路連線":`無法連線至雲端更新節點 (${(r==null?void 0:r.message)||"Network Error"})`,oe(),null}async function Re(){Dn(),f.confirmRollback=!1;const n=document.getElementById("ota-modal-backdrop");n&&(n.hidden=!1,n.removeAttribute("hidden"),n.classList.add("is-open")),f.nativeInfo=await xn(),oe(),Ee(!1)}function Le(){if(f.updating)return;f.confirmRollback=!1;const n=document.getElementById("ota-modal-backdrop");n&&(n.hidden=!0,n.setAttribute("hidden",""),n.classList.remove("is-open"))}async function ei(){var d,e;if(f.updating)return;const n=Se(),o=typeof((d=f.remoteManifest)==null?void 0:d.version)=="number"?f.remoteManifest.version:null,r=!(o!==null&&o>n),t=he();if(t&&typeof t.triggerHotUpdate=="function"){f.updating=!0,f.progressPct=5,f.progressMsg="正在啟動 Android P2R-OTA 雲端差分熱更新引擎...",oe();try{t.triggerHotUpdate(!!r)}catch(s){f.updating=!1,f.progressMsg=`啟動熱更新失敗：${(s==null?void 0:s.message)||s}`,oe()}return}if(be("🔄 正在重新載入最新前端版本..."),typeof window<"u"&&((e=window.location)!=null&&e.href)){const s=new URL(window.location.href);s.searchParams.set("ota_t",String(Date.now())),window.location.replace(s.toString())}}function ti(n){const o=n||{},a=o.version||ce,r=`https://raw.githubusercontent.com/terryfantpe/tstock-data/main/videoplayer/Videoplayer.apk?v=${a}`,t=o.apk_pages_url||o.apk_url||`https://terryfantpe.github.io/tstock-data/videoplayer/Videoplayer.apk?v=${a}`,d=`https://github.com/terryfantpe/tstock-data/raw/main/videoplayer/Videoplayer.apk?v=${a}`,e=String(o.apk_hash||"").trim();return[{step:1,url:r,hash:e},{step:2,url:t,hash:""},{step:3,url:d,hash:""}]}function Ce(){const o=(f.remoteManifest||{}).version||ce,a=`https://raw.githubusercontent.com/terryfantpe/tstock-data/main/videoplayer/Videoplayer.apk?v=${o}&t=${Date.now()}`,r=he();f.updating=!1,f.apkUpgradeInProgress=!1,f.apkRetryQueue=[],f.progressPct=100,f.progressMsg="已開啟外部下載連結以取得最新 Videoplayer.apk",oe(),be("🌐 正在開啟最新 Videoplayer.apk 下載連結...");try{if(r&&typeof r.openExternalUrl=="function"&&r.openExternalUrl(a))return}catch{}if(typeof document<"u"&&document.body){const t=document.createElement("a");t.href=a,t.target="_blank",t.rel="noopener noreferrer",t.setAttribute("download",`OmniPlay_Pro_v0.1.${o}.apk`),document.body.appendChild(t),t.click(),t.remove()}else typeof window<"u"&&typeof window.open=="function"&&window.open(a,"_blank")}async function We(){if(f.updating)return;const n=he();if(!n||typeof n.downloadAndInstallApk!="function"){Ce();return}!f.remoteManifest&&!f.checking&&await Ee(!0);const o=ti(f.remoteManifest),a=o.shift();f.apkUpgradeInProgress=!0,f.apkRetryQueue=o,f.updating=!0,f.progressPct=4,f.progressMsg="正在從雲端下載最新完整版 Videoplayer.apk...",oe();try{n.downloadAndInstallApk(a.url,a.hash)}catch(r){f.updating=!1,f.apkUpgradeInProgress=!1,f.apkRetryQueue=[],f.progressMsg=`APK 下載啟動失敗：${(r==null?void 0:r.message)||r}`,oe()}}async function ni(){if(f.updating||!f.nativeInfo)return;if(!f.confirmRollback){f.confirmRollback=!0,oe();return}const n=he();n&&typeof n.resetToBuiltinAssets=="function"&&(f.updating=!0,f.progressPct=50,f.progressMsg="正在清除 web_live 熱更圖層並還原 APK 內建版本...",oe(),n.resetToBuiltinAssets())}function ii(){try{if(Dn(),f.nativeInfo=He(),typeof window<"u"){window.openOtaModal=Re,window.closeOtaModal=Le,window.triggerTier3ApkUpgrade=We;const n=(a,r)=>{f.updating=!0,f.progressPct=typeof a=="number"?Math.max(0,Math.min(100,Math.round(a))):0,f.progressMsg=r||"正在同步雲端更新套件...",oe()},o=(a,r,t)=>{const d=Date.now();if(d-En<350)return;En=d;const e=typeof r=="number",s=e?t:typeof r=="string"?r:t;if(!a&&f.apkUpgradeInProgress){const c=he();if(f.apkRetryQueue.length>0&&c&&typeof c.downloadAndInstallApk=="function"){const m=f.apkRetryQueue.shift();f.updating=!0,f.progressPct=8,f.progressMsg=`正在切換備援鏡像節點 (#${m.step}) 下載 APK...`,oe(),setTimeout(()=>{try{c.downloadAndInstallApk(m.url,m.hash)}catch{Ce()}},450);return}f.apkUpgradeInProgress=!1,f.apkRetryQueue=[],Ce();return}if(f.apkUpgradeInProgress=!1,f.apkRetryQueue=[],f.updating=!1,f.nativeInfo=He(),a){const c=e?r:Se();f.progressPct=100,f.progressMsg=s||`✅ 已成功熱更新至 OTA v${c}，即將重新載入...`,be(f.progressMsg)}else f.progressMsg=s||"目前已在最新版本狀態",s&&be(s);oe()};window.__onOmniPlayOtaProgress=n,window.__onOmniPlayOtaComplete=o,window.__onOmniPlayOtaDone=o,window.__onGroundOtaProgress=n,window.__onGroundOtaComplete=o,window.__onGroundOtaDone=o,window.__onZiweiOtaProgress=n,window.__onZiweiOtaComplete=o,window.__onZiweiOtaDone=o}oe(),xn().then(n=>{f.nativeInfo=n,oe(),setTimeout(()=>{Ee(!0)},1500)})}catch(n){console.warn("[OmniPlayOTA] initOtaSystem warning:",n)}}const Pn=[{id:"demo-cinema-16-9",title:"星際地平線：16:9 劇院寬螢幕測試",subtitle:"1280×720 • 60FPS • 16:9 橫向標準",width:1280,height:720,aspectLabel:"16:9",orientation:"landscape",sceneType:"cosmos",duration:120,fps:60,isDemo:!0,badge:"16:9 橫向劇院",description:"用於測試標準 16:9 劇院比例在橫向視窗滿版播放，以及切換至手機直向視窗時自動旋轉 90° 無損放大。"},{id:"demo-shorts-9-16",title:"霓虹賽博直式短片：9:16 自動轉向測試",subtitle:"720×1280 • 60FPS • 9:16 直向滿版",width:720,height:1280,aspectLabel:"9:16",orientation:"portrait",sceneType:"neon-vertical",duration:90,fps:60,isDemo:!0,badge:"9:16 直向短片",description:"用於測試 9:16 直向影片在橫向螢幕自動轉向 90° 以達成不改變 scale(1) 的最大可視面積。"},{id:"demo-ultra-21-9",title:"極光流體實驗：21:9 超寬電影測試",subtitle:"1260×540 • 60FPS • 21:9 超寬比例",width:1260,height:540,aspectLabel:"21:9",orientation:"landscape",sceneType:"aurora",duration:150,fps:60,isDemo:!0,badge:"21:9 電影超寬",description:"用於測試 21:9 電影寬銀幕在各種視窗比例下的幾何中心對齊與四角零裁切校準。"},{id:"demo-classic-4-3",title:"復古膠片校準圖卡：4:3 無損比例測試",subtitle:"960×720 • 60FPS • 4:3 經典比例",width:960,height:720,aspectLabel:"4:3",orientation:"landscape",sceneType:"calibration",duration:60,fps:60,isDemo:!0,badge:"4:3 經典校準",description:"內建四角準星與正圓幾何圖卡，可直觀驗證旋轉與最大化時 0% 畫面裁切、1:1 等比無變形。"}],Bn=[{id:"flat",name:"原音直通 (Flat)",bass:0,mid:0,treble:0,boost:1},{id:"cinema",name:"劇院震撼 (Cinema)",bass:6,mid:2,treble:4,boost:1.15},{id:"vocal",name:"人聲清晰 (Vocal)",bass:-2,mid:6,treble:3,boost:1.1},{id:"bass",name:"重低音增強 (Bass)",bass:9,mid:0,treble:1,boost:1.1},{id:"night",name:"夜間柔化 (Night)",bass:-5,mid:3,treble:-2,boost:.9}],oi=[{key:"Space",action:"播放 / 暫停",desc:"切換影片播放或暫停狀態（等同點擊畫面中央區域）"},{key:"PageUp / P / Shift+←",action:"同目錄上一片 (⏮)",desc:"立即切換至同資料夾 / 播放清單的上一部影片（亦可使用畫面左側 ⏮ 按鈕）"},{key:"PageDown / N / Shift+→",action:"同目錄下一片 (⏭)",desc:"立即切換至同資料夾 / 播放清單的下一部影片（亦可使用畫面右側 ⏭ 按鈕）"},{key:"← / →",action:"快退 / 快轉 或 前後換片",desc:"預設前後跳轉 ±5 秒；開啟「方向鍵換片」模式後可直接按 ← / → 切換同目錄前後片"},{key:"↑ / ↓",action:"調整音量 (±5%)",desc:"提高或降低音量（等同右側區域上下滑動）"},{key:"W / S",action:"調整亮度 (±5%)",desc:"提高或降低畫面亮度並自動記憶（等同左側區域上下滑動）"},{key:"R",action:"手動旋轉 90°",desc:"順時針旋轉影片 90°（0° → 90° → 180° → 270°）"},{key:"A",action:"切換自動轉向",desc:"開啟或關閉智慧偵測長寬比自動轉向無損最大化"},{key:"M",action:"靜音切換",desc:"一鍵切換靜音與恢復原音量"},{key:"F",action:"全螢幕切換",desc:"進入或退出劇院全螢幕模式"},{key:"G",action:"手勢導覽格線",desc:"顯示或隱藏左亮度 / 中播放 / 右音量三區手勢提示層"},{key:"E",action:"硬體解碼 / 節電模式",desc:"切換 GPU 硬體解碼 (MPO Zero-Copy) 與智慧省電模式"},{key:"O / ,",action:"⚙️ 設定中心",desc:"開啟整合式設定抽屜（亮度、自動轉向、前後鍵換片、硬體解碼、省電與恢復預設）"},{key:"U",action:"☁️ 線上更新 (P2R-OTA)",desc:"開啟 P2R-OTA 雲端熱更新與 APK 原生升級面板，檢查 GitHub 最新版本"},{key:"[ / ]",action:"A-B 區間循環",desc:"設定 A 點起點、B 點終點進行片段無限循環播放"}],fe={arrowKeySwitchOnTip:"已開啟「方向鍵換片」：按 ← / → 直接切換同目錄上一片 / 下一片",arrowKeySwitchOffTip:"已關閉「方向鍵換片」：按 ← / → 快退 / 快轉 5 秒（換片請按 PageUp/PageDown、P/N 或 Shift+←/→）"},ai=[.5,.75,1,1.25,1.5,2],ri=[{start:0,end:5,text:"💡 試試在畫面【左側上下滑動】調整亮度（自動記憶上次設定）"},{start:5,end:10,text:"🔊 在畫面【右側上下滑動】可即時無段調整音量大小"},{start:10,end:15,text:"⏯️ 點擊畫面【正中央區域】可快速切換播放與暫停"},{start:15,end:22,text:"⏮️⏭️ 同目錄可按前後鍵（PageUp/PageDown、P/N、Shift+←/→ 或兩側按鈕）直接換片！"},{start:22,end:30,text:"🔄 切換「9:16 直式短片」或點擊「模擬直向視窗」體驗不改變 Scale(1) 的自動轉向最大化！"}],qe="vp_hw_decode",Ge="vp_power_save",si=[{id:"h264",name:"H.264 / AVC",contentType:'video/mp4; codecs="avc1.640028"',webCodec:"avc1.640028"},{id:"hevc",name:"HEVC / H.265",contentType:'video/mp4; codecs="hev1.1.6.L120.90"',webCodec:"hev1.1.6.L120.90"},{id:"vp9",name:"VP9 Profile 0",contentType:'video/webm; codecs="vp09.00.50.08"',webCodec:"vp09.00.50.08"},{id:"av1",name:"AV1 Main 10",contentType:'video/mp4; codecs="av01.0.08M.08"',webCodec:"av01.0.08M.08"}];function li(){try{const n=localStorage.getItem(qe);return n===null?(localStorage.setItem(qe,"true"),!0):n!=="false"&&n!=="0"}catch{return!0}}function Tn(n){const o=!!n;try{localStorage.setItem(qe,String(o))}catch{}return o}function $n(){try{const n=localStorage.getItem(Ge);return n===null?(localStorage.setItem(Ge,"true"),!0):n!=="false"&&n!=="0"}catch{return!0}}function In(n){const o=!!n;try{localStorage.setItem(Ge,String(o))}catch{}return o}function Ue(n=!0,o=!1){const a=!!(o||typeof document<"u"&&document.hidden);return n&&a?5:n?30:60}function Nn(n=!0){return{alpha:!1,desynchronized:!!n,willReadFrequently:!1}}function Ne(n=!0,o=!0){return n||!o?250:16}async function di(){var r,t,d;const n={};for(const e of si){let s={id:e.id,name:e.name,supported:e.id==="h264"||e.id==="vp9",smooth:!0,powerEfficient:!0};try{if(typeof navigator<"u"&&((r=navigator.mediaCapabilities)!=null&&r.decodingInfo)){const c=await navigator.mediaCapabilities.decodingInfo({type:"file",video:{contentType:e.contentType,width:1920,height:1080,bitrate:8e6,framerate:60}});s={id:e.id,name:e.name,supported:!!c.supported,smooth:!!c.smooth,powerEfficient:!!c.powerEfficient}}}catch{}n[e.id]=s}let o={supported:!1,hardwareAcceleration:"prefer-hardware"};try{if(typeof window<"u"&&typeof((t=window.VideoDecoder)==null?void 0:t.isConfigSupported)=="function"){const e=await window.VideoDecoder.isConfigSupported({codec:"avc1.640028",width:1920,height:1080,hardwareAcceleration:"prefer-hardware"});o={supported:!!(e!=null&&e.supported),hardwareAcceleration:((d=e==null?void 0:e.config)==null?void 0:d.hardwareAcceleration)||"prefer-hardware"}}}catch{}const a=Object.values(n).some(e=>e.supported&&e.powerEfficient)||o.supported;return{codecs:n,webCodecsHw:o,hardwareAcceleratedAvailable:a,probedAt:Date.now()}}function An(n,{videoEl:o,veilEl:a,hwDecodeEnabled:r=!0,powerSaveEnabled:t=!0}={}){const d=Math.max(0,Math.min(100,Number.isFinite(Number(n))?Number(n):85)),e=!!(r&&t&&d<=85);let s="none",c=0;if(d<=85){const m=(85-d)/85;e?(s="none",c=Number((m*.92).toFixed(2))):(s=`brightness(${Number((.15+d/85*.85).toFixed(2))})`,c=Number((m*.45).toFixed(2)))}else{const m=(d-85)/15,p=Number((1+m*.35).toFixed(2)),h=Number((1+m*.04).toFixed(2));s=`brightness(${p}) contrast(${h})`,c=0}return o&&o.style&&(o.style.filter=s==="none"?"":s,o.dataset.mpoZeroCopy=e?"true":"false"),a&&a.style&&(a.style.opacity=String(c)),{brightness:d,mpoZeroCopyActive:e,videoFilter:s,veilOpacity:c}}function ci({videoEl:n=null,stageEl:o=null,veilEl:a=null,onStatusChange:r=null}={}){let t=n,d=o,e=a,s=li(),c=$n();Tn(s),In(c);let m=85,p=!!(s&&c&&m<=85),h=!0,b=!1,A={codecs:{h264:{id:"h264",name:"H.264 / AVC",supported:!0,smooth:!0,powerEfficient:!0},hevc:{id:"hevc",name:"HEVC / H.265",supported:!0,smooth:!0,powerEfficient:!0},vp9:{id:"vp9",name:"VP9 Profile 0",supported:!0,smooth:!0,powerEfficient:!0},av1:{id:"av1",name:"AV1 Main 10",supported:!0,smooth:!0,powerEfficient:!0}},webCodecsHw:{supported:!0,hardwareAcceleration:"prefer-hardware"},hardwareAcceleratedAvailable:!0,probedAt:0},T=null,V={supported:!1,levelPercent:100,charging:!0,statusLabel:"電源直供 / 智慧節電待命"},L=null,O=!1;function C(){if(typeof r=="function")try{r(I())}catch{}}function x(){if(!t)return;t.playsInline=!0,t.setAttribute("playsinline",""),t.setAttribute("webkit-playsinline",""),"disableRemotePlayback"in t&&(t.disableRemotePlayback=!!s),s?(t.dataset.hwDecode="prefer-hardware",t.setAttribute("decoding","async"),t.style.transform="translateZ(0)",t.style.backfaceVisibility="hidden",t.style.willChange="transform"):(t.dataset.hwDecode="software",t.style.transform="",t.style.backfaceVisibility="",t.style.willChange="auto"),d&&(d.classList.toggle("is-hw-decode",!!s),d.classList.toggle("is-power-save",!!c),d.classList.toggle("is-bg-throttled",!!b)),p=An(m,{videoEl:t,veilEl:e,hwDecodeEnabled:s,powerSaveEnabled:c}).mpoZeroCopyActive}async function P(){var k;const v=!!(t&&!t.paused&&!t.ended&&t.readyState>=1&&typeof document<"u"&&!document.hidden);if(v&&!L)try{typeof navigator<"u"&&((k=navigator.wakeLock)!=null&&k.request)&&(L=await navigator.wakeLock.request("screen"),O=!0,L.addEventListener("release",()=>{L=null,O=!1,C()}),C())}catch{L=null,O=!1}else if(!v&&L){try{await L.release()}catch{}L=null,O=!1,C()}}function $(R){if(!R)return;const v=Number.isFinite(R.level)?R.level*100:100,k=Number(v.toFixed(0)),Z=!!R.charging;V={supported:!0,levelPercent:k,charging:Z,statusLabel:`${Z?"⚡ 充電中":"🔋 電池供電"} ${k}%`},C()}const y=()=>{$(T)};async function D(){var R,v;try{typeof navigator<"u"&&typeof navigator.getBattery=="function"&&(T=await navigator.getBattery(),$(T),(R=T.addEventListener)==null||R.call(T,"chargingchange",y),(v=T.addEventListener)==null||v.call(T,"levelchange",y))}catch{}}const S=()=>{b=!!(typeof document<"u"&&!!document.hidden&&c),d&&d.classList.toggle("is-bg-throttled",b),P(),C()},E=()=>{P(),C()};function M(R){R&&(R.addEventListener("play",E),R.addEventListener("playing",E),R.addEventListener("pause",E),R.addEventListener("ended",E))}function F(R){R&&(R.removeEventListener("play",E),R.removeEventListener("playing",E),R.removeEventListener("pause",E),R.removeEventListener("ended",E))}function I(){let R=0,v=0;if(t&&typeof t.getVideoPlaybackQuality=="function")try{const ue=t.getVideoPlaybackQuality();R=Number((ue==null?void 0:ue.totalVideoFrames)||0),v=Number((ue==null?void 0:ue.droppedVideoFrames)||0)}catch{}else t&&(R=Number(t.webkitDecodedFrameCount||0),v=Number(t.webkitDroppedFrameCount||0));const k=R>0?v/R*100:0,Z=Number(k.toFixed(2)),ne=s?p?"GPU 硬體加速 (MPO Zero-Copy)":"GPU 硬體加速 (Prefer-HW)":"軟體解碼 (CPU Shader)",ie=c?b?"背景深度節電 (5FPS • HUD 休眠)":"節電中 • CPU 休眠優化":"全速效能模式 (60Hz)",N=`${s?"⚡ 硬體解碼":"🖥️ 軟體解碼"} • ${c?"🍃 節電中":"🔥 效能"}`,ee=Ne(c,h),de=ee>=250?4:60,ye=Ue(c,typeof document<"u"&&document.hidden);let me=0;return s&&c?me=p?42:34:s?me=24:c&&(me=18),{hwDecodeEnabled:s,powerSaveEnabled:c,mpoZeroCopyActive:p,decodeModeLabel:ne,powerStateLabel:ie,topbarBadgeText:N,targetDemoFps:ye,uiTickIntervalMs:ee,uiTickHz:de,totalVideoFrames:R,droppedVideoFrames:v,dropRatePercent:Z,wakeLockActive:O,isBackgroundThrottled:b,estimatedPowerSavingPercent:me,brightness:m,battery:{...V},codecs:{...A.codecs},webCodecsHw:{...A.webCodecsHw},hardwareAcceleratedAvailable:A.hardwareAcceleratedAvailable}}function G(R){return s=Tn(!!R),x(),C(),s}function H(){return G(!s)}function z(R){return c=In(!!R),b=!!(typeof document<"u"&&document.hidden&&c),x(),C(),c}function j(){return z(!c)}function Q(R){m=Math.max(0,Math.min(100,Number.isFinite(Number(R))?Number(R):85));const v=An(m,{videoEl:t,veilEl:e,hwDecodeEnabled:s,powerSaveEnabled:c});return p=v.mpoZeroCopyActive,C(),v}function se(R){return h=!!R,Ne(c,h)}function te({videoEl:R,stageEl:v,veilEl:k}={}){R&&R!==t&&(F(t),t=R,M(t)),v&&(d=v),k&&(e=k),x(),C()}async function W(){return A=await di(),C(),A}function Y(){var R,v;F(t),typeof document<"u"&&document.removeEventListener("visibilitychange",S),T&&((R=T.removeEventListener)==null||R.call(T,"chargingchange",y),(v=T.removeEventListener)==null||v.call(T,"levelchange",y)),L&&(L.release().catch(()=>{}),L=null,O=!1)}return M(t),x(),typeof document<"u"&&document.addEventListener("visibilitychange",S),D(),W(),{get isHwDecodeEnabled(){return s},get isPowerSaveEnabled(){return c},setHwDecodeEnabled:G,toggleHwDecode:H,setPowerSaveEnabled:z,togglePowerSave:j,applyBrightness:Q,setControlsVisible:se,bindElements:te,probeHardwareCapabilities:W,getEcoTickInterval:(R=h)=>Ne(c,R),getTargetDemoFps:()=>Ue(c,typeof document<"u"&&document.hidden),getEcoCanvasContextAttributes:()=>Nn(c),getTelemetry:I,syncWakeLock:P,destroy:Y}}const Ve=new WeakMap;let Ie=null;function ui(){if(typeof window>"u")return!1;if(window.AndroidPlayerBridge||window.GroundOTA||window.ZiweiOTA||window.OmniPlayOTA)return!0;const n=typeof navigator<"u"&&navigator.userAgent||"";return/Android/i.test(n)&&/wv|Version\/\d+\.\d+/i.test(n)}function pi(){if(typeof window>"u")return null;const n=window.AudioContext||window.webkitAudioContext;if(!n)return null;if(!Ie||Ie.state==="closed")try{Ie=new n}catch{return null}return Ie}function ke(n,o,a){return Math.max(o,Math.min(a,n))}function Mn(n="cosmos"){const o=pi();if(!o)return null;try{const a=typeof o.createMediaStreamDestination=="function"?o.createMediaStreamDestination():null,r={cosmos:[110,164.81,220,277.18],"neon-vertical":[130.81,196,246.94,293.66],aurora:[146.83,220,261.63,329.63],calibration:[123.47,185,246.94,308.68]},t=String(n||"cosmos").trim(),d=r[t]||r.cosmos,e=o.createBiquadFilter();e.type="lowshelf",e.frequency.value=120,e.gain.value=0;const s=o.createBiquadFilter();s.type="peaking",s.frequency.value=1e3,s.Q.value=1,s.gain.value=0;const c=o.createBiquadFilter();c.type="highshelf",c.frequency.value=6e3,c.gain.value=0;const m=o.createBiquadFilter();m.type="lowpass",m.frequency.value=1400,m.Q.value=.7;const p=o.createOscillator(),h=o.createGain();p.type="sine",p.frequency.value=.22,h.gain.value=450,p.connect(h),h.connect(m.frequency),p.start();const b=o.createGain();if(b.gain.value=0,m.connect(e),e.connect(s),s.connect(c),c.connect(b),b.connect(o.destination),a){const T=o.createGain();T.gain.value=1e-4,b.connect(T),T.connect(a)}const A=d.map((T,V)=>{const L=o.createOscillator(),O=o.createGain();return L.type=V%2===0?"sine":"triangle",L.frequency.value=T,L.detune.value=(V-1.5)*4,O.gain.value=V===0?.32:.16,L.connect(O),O.connect(m),L.start(),{osc:L,oscGain:O}});return{ctx:o,stream:a?a.stream:null,masterGain:b,bassFilter:e,midFilter:s,trebleFilter:c,UpdateVolume(T,V=.8,L=!1,O=1){try{o.state==="suspended"&&T&&!L&&V>0&&o.resume().catch(()=>{});const C=!T||L?0:Math.pow(ke(V,0,1),1.4)*.14*ke(O,.5,2);b.gain.setTargetAtTime(C,o.currentTime,.04)}catch{try{b.gain.value=0}catch{}}},setEq({bass:T=0,mid:V=0,treble:L=0}={}){try{e.gain.setTargetAtTime(T,o.currentTime,.05),s.gain.setTargetAtTime(V,o.currentTime,.05),c.gain.setTargetAtTime(L,o.currentTime,.05)}catch{}},destroy(){try{b.gain.value=0,p.stop(),p.disconnect(),A.forEach(({osc:T,oscGain:V})=>{try{T.stop(),T.disconnect(),V.disconnect()}catch{}}),b.disconnect()}catch{}}}}catch{return null}}function mi(n,o,a,r,t,d,e=30,s=!0){const c=String((d==null?void 0:d.sceneType)||"cosmos").trim();d!=null&&d.title,d!=null&&d.aspectLabel||`${o}${a}`;const m=r;n.save(),n.clearRect(0,0,o,a),c==="neon-vertical"?vi(n,o,a,m):c==="aurora"?fi(n,o,a,m):c==="calibration"?bi(n,o,a,m):gi(n,o,a,m),hi(n,o,a),n.restore()}function gi(n,o,a,r){const t=o*.5,d=a*.5,e=Math.min(o,a),s=n.createRadialGradient(t,d,e*.04,t,d,Math.max(o,a)*.75);s.addColorStop(0,"#1e1238"),s.addColorStop(.45,"#0b0e22"),s.addColorStop(1,"#04050c"),n.fillStyle=s,n.fillRect(0,0,o,a);for(let m=0;m<70;m++){const h=(m*9301+49297)%233280/233280,b=.025+m%4*.015,A=((h*o+r*b*o*(m%2===0?1:-.6))%o+o)%o,T=m*4177%1e3/1e3*a,V=.8+m%3*.85,L=.35+.55*Math.abs(Math.sin(r*2.1+m));n.fillStyle=m%5===0?`rgba(56, 189, 248, ${L})`:`rgba(255, 255, 255, ${L})`,n.beginPath(),n.arc(A,T,V,0,Math.PI*2),n.fill()}n.save(),n.translate(t,d);for(let m=1;m<=4;m++){const p=e*(.12+m*.075);n.strokeStyle=m%2===0?"rgba(139, 92, 246, 0.35)":"rgba(56, 189, 248, 0.32)",n.lineWidth=1.6,n.beginPath(),n.arc(0,0,p,0,Math.PI*2),n.stroke();const h=r*(.9-m*.16)*(m%2===0?1:-1)+m*1.3,b=Math.cos(h)*p,A=Math.sin(h)*p;n.fillStyle=m%2===0?"#a855f7":"#38bdf8",n.beginPath(),n.arc(b,A,5.5,0,Math.PI*2),n.fill()}const c=n.createRadialGradient(0,0,e*.03,0,0,e*.16);c.addColorStop(0,"#ffffff"),c.addColorStop(.3,"#38bdf8"),c.addColorStop(.7,"rgba(139, 92, 246, 0.45)"),c.addColorStop(1,"rgba(139, 92, 246, 0)"),n.fillStyle=c,n.beginPath(),n.arc(0,0,e*.16,0,Math.PI*2),n.fill(),n.restore()}function vi(n,o,a,r){const t=o*.5,d=a*.5,e=Math.min(o,a),s=n.createLinearGradient(0,0,0,a);s.addColorStop(0,"#090418"),s.addColorStop(.5,"#170930"),s.addColorStop(1,"#061527"),n.fillStyle=s,n.fillRect(0,0,o,a),n.strokeStyle="rgba(236, 72, 153, 0.28)",n.lineWidth=1.2;const c=12,m=r*60%(a/c);for(let p=m;p<a;p+=a/c)n.beginPath(),n.moveTo(0,p),n.lineTo(o,p),n.stroke();for(let p=0;p<=o;p+=o/8)n.strokeStyle="rgba(34, 211, 238, 0.2)",n.beginPath(),n.moveTo(p,0),n.lineTo(p,a),n.stroke();for(let p=0;p<3;p++){const h=a*(.25+p*.25),b=1+.08*Math.sin(r*3+p*1.5),A=e*.22*b;n.strokeStyle=p===1?"#22d3ee":"#f472b6",n.lineWidth=3,n.beginPath(),n.arc(t,h,A,0,Math.PI*2),n.stroke()}for(let p=0;p<24;p++){const h=(p+.5)/24*o,b=Math.abs(Math.sin(r*2.8+p*.55))*(a*.14)+12;n.fillStyle=p%2===0?"rgba(34, 211, 238, 0.45)":"rgba(244, 114, 182, 0.45)",n.fillRect(h-6,d-b/2,12,b)}}function fi(n,o,a,r){const t=n.createLinearGradient(0,0,o,a);t.addColorStop(0,"#03131f"),t.addColorStop(.5,"#07222c"),t.addColorStop(1,"#0c1026"),n.fillStyle=t,n.fillRect(0,0,o,a),[{color:"rgba(16, 185, 129, 0.34)",amp:a*.15,freq:.0045,speed:1.4,yBase:a*.36},{color:"rgba(56, 189, 248, 0.30)",amp:a*.12,freq:.006,speed:-1.1,yBase:a*.52},{color:"rgba(168, 85, 247, 0.26)",amp:a*.1,freq:.005,speed:1.8,yBase:a*.65}].forEach(s=>{n.fillStyle=s.color,n.beginPath(),n.moveTo(0,a);for(let c=0;c<=o;c+=18){const m=s.yBase+Math.sin(c*s.freq+r*s.speed)*s.amp+Math.cos(c*s.freq*.5-r*.8)*(s.amp*.45);n.lineTo(c,m)}n.lineTo(o,a),n.closePath(),n.fill()});const e=Math.min(o,a);n.strokeStyle="rgba(52, 211, 153, 0.55)",n.lineWidth=2,n.beginPath(),n.arc(o*.5,a*.5,e*.32,0,Math.PI*2),n.stroke()}function bi(n,o,a,r){const t=o*.5,d=a*.5,e=Math.min(o,a);n.fillStyle="#0e1118",n.fillRect(0,0,o,a);const s=Math.round(e/12);n.strokeStyle="rgba(255, 255, 255, 0.12)",n.lineWidth=1;for(let A=t%s;A<o;A+=s)n.beginPath(),n.moveTo(A,0),n.lineTo(A,a),n.stroke();for(let A=d%s;A<a;A+=s)n.beginPath(),n.moveTo(0,A),n.lineTo(o,A),n.stroke();const c=["#e2e8f0","#facc15","#22d3ee","#4ade80","#e879f9","#f87171","#3b82f6"],m=o*.56/c.length,p=t-o*.56/2,h=d-e*.26;c.forEach((A,T)=>{n.fillStyle=A,n.globalAlpha=.78,n.fillRect(p+T*m,h,m-2,e*.11)}),n.globalAlpha=1,n.strokeStyle="#facc15",n.lineWidth=3,n.beginPath(),n.arc(t,d,e*.36,0,Math.PI*2),n.stroke();const b=r*1.5;n.strokeStyle="#38bdf8",n.lineWidth=2.5,n.beginPath(),n.moveTo(t,d),n.lineTo(t+Math.cos(b)*e*.36,d+Math.sin(b)*e*.36),n.stroke()}function hi(n,o,a){const r=Math.min(o,a),t=Math.max(16,Math.round(r*.035)),d=8;n.save(),n.strokeStyle="rgba(255, 255, 255, 0.14)",n.lineWidth=1.5,n.beginPath(),n.moveTo(d,d+t),n.lineTo(d,d),n.lineTo(d+t,d),n.moveTo(o-d-t,d),n.lineTo(o-d,d),n.lineTo(o-d,d+t),n.moveTo(d,a-d-t),n.lineTo(d,a-d),n.lineTo(d+t,a-d),n.moveTo(o-d-t,a-d),n.lineTo(o-d,a-d),n.lineTo(o-d,a-d-t),n.stroke(),n.restore()}function yi(n=null,o={}){let a=typeof(o==null?void 0:o.powerSaveEnabled)=="boolean"?o.powerSaveEnabled:$n();const r=document.createElement("canvas");r.className="vp-demo-canvas",r.style.cssText="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;pointer-events:none;z-index:2;display:block;";let t=null;try{t=r.getContext("2d",Nn(a))}catch{t=null}if(!t)try{t=r.getContext("2d")}catch{t=null}let d=n||{id:"demo-cinema-16-9",title:"星際地平線：16:9 劇院寬螢幕測試",width:1280,height:720,aspectLabel:"16:9",sceneType:"cosmos",duration:120},e=Number(d.width)||1280,s=Number(d.height)||720,c=Number(d.duration)||120,m=0,p=1,h=(o==null?void 0:o.autoPlay)!==!1,b=null,A=null,T=0,V=0,L=!1,O=null,C=null,x=null;r.width=e,r.height=s;function P(){const v=typeof document<"u"&&!!document.hidden;return Ue(a,v)}function $(){var k;if(!x||!r)return;const v=((k=x.style)==null?void 0:k.filter)||"";r.style.filter!==v&&(r.style.filter=v)}function y(){if(!t)return;$();const v=P();mi(t,e,s,m,c,d,v,a)}function D(){if(!C)return;const v=x?x.volume:.8,k=x?x.muted:!1;C.UpdateVolume(h&&!L,v,k,1)}function S(v){if(x)try{x.dispatchEvent(new Event(v))}catch{}}function E(v){var ie,N,ee;if(L)return;A===null&&(A=v);const k=Math.min(.1,Math.max(0,(v-A)/1e3));A=v;const Z=P(),ne=1e3/Math.max(1,Z)-1.5;if(h){m+=k*p,m>=c&&((x?x.loop!==!1:!0)?m=m%c:(m=c,h=!1,D(),S("ended"),(ie=o==null?void 0:o.onPlayChange)==null||ie.call(o,!1),(N=o==null?void 0:o.onEnded)==null||N.call(o)));const de=a?200:80;v-V>=de&&(V=v,S("timeupdate"),(ee=o==null?void 0:o.onTimeUpdate)==null||ee.call(o,m,c))}v-T>=ne&&(T=v,y()),b=requestAnimationFrame(E)}function M(){b!==null||L||(A=performance.now(),y(),b=requestAnimationFrame(E))}function F(){b!==null&&(cancelAnimationFrame(b),b=null),A=null}function I(v){var Z;return m=ke(Number(v)||0,0,c),y(),S("seeking"),S("seeked"),S("timeupdate"),(Z=o==null?void 0:o.onTimeUpdate)==null||Z.call(o,m,c),m}function G(v=1){const k=Number(d==null?void 0:d.fps)||60;return I(m+v/k)}function H(){var v;if(h=!0,A=performance.now(),M(),D(),(v=o==null?void 0:o.onPlayChange)==null||v.call(o,!0),x&&x.srcObject&&x.paused)try{const k=x.play();k&&typeof k.catch=="function"&&k.catch(()=>{})}catch{}}function z(){var v;if(h=!1,D(),y(),(v=o==null?void 0:o.onPlayChange)==null||v.call(o,!1),x&&x.srcObject&&!x.paused)try{x.pause()}catch{}}function j(){return h?z():H(),h}function Q(v){return p=ke(Number(v)||1,.25,4),p}function se(v){return a=!!v,y(),a}function te(v){var k,Z;v&&(d=v,e=Number(d.width)||1280,s=Number(d.height)||720,c=Number(d.duration)||120,m=0,r.width=e,r.height=s,C&&C.destroy(),C=Mn(d.sceneType),y(),D(),S("durationchange"),S("loadedmetadata"),S("timeupdate"),(k=o==null?void 0:o.onMetadata)==null||k.call(o,{width:e,height:s,duration:c,demoItem:d}),(Z=o==null?void 0:o.onLoadedMetadata)==null||Z.call(o,{width:e,height:s,duration:c,demoItem:d}))}function W(v){x=v,y();try{v.parentElement&&(v.parentElement.querySelectorAll(".vp-demo-canvas").forEach(ee=>{ee!==r&&ee.remove()}),v.insertAdjacentElement("afterend",r))}catch{}if(C=Mn(d.sceneType),!ui()&&typeof r.captureStream=="function")try{if(O=r.captureStream(30),C!=null&&C.stream){const N=C.stream.getAudioTracks();N.length>0&&O.addTrack(N[0])}v.srcObject=O}catch{O=null}try{v.dataset.isDemo="true",v.dataset.demoId=d.id||"demo",v.dataset.demoWidth=String(e),v.dataset.demoHeight=String(s)}catch{}try{Object.defineProperty(v,"duration",{configurable:!0,get(){return c}}),Object.defineProperty(v,"currentTime",{configurable:!0,get(){return m},set(N){I(N)}})}catch{}const k=()=>{var N;h=!0,A=performance.now(),D(),(N=o==null?void 0:o.onPlayChange)==null||N.call(o,!0)},Z=()=>{var N;h=!1,D(),(N=o==null?void 0:o.onPlayChange)==null||N.call(o,!1)},ne=()=>{D()},ie=()=>{Number.isFinite(v.playbackRate)&&v.playbackRate>0&&(p=v.playbackRate)};if(v.addEventListener("play",k),v.addEventListener("pause",Z),v.addEventListener("volumechange",ne),v.addEventListener("ratechange",ie),v.__demoCleanupListeners=()=>{v.removeEventListener("play",k),v.removeEventListener("pause",Z),v.removeEventListener("volumechange",ne),v.removeEventListener("ratechange",ie)},M(),D(),queueMicrotask(()=>{var N,ee,de;L||(S("durationchange"),S("loadedmetadata"),S("canplay"),(N=o==null?void 0:o.onMetadata)==null||N.call(o,{width:e,height:s,duration:c,demoItem:d}),(ee=o==null?void 0:o.onLoadedMetadata)==null||ee.call(o,{width:e,height:s,duration:c,demoItem:d}),(de=o==null?void 0:o.onPlayChange)==null||de.call(o,h))}),(o==null?void 0:o.autoPlay)!==!1&&(h=!0,D(),v.srcObject))try{const N=v.play();N&&typeof N.catch=="function"&&N.catch(()=>{})}catch{}}function Y(){if(!L){L=!0,F();try{r.remove()}catch{r.parentNode&&r.parentNode.removeChild(r)}if(C&&(C.destroy(),C=null),O){try{O.getTracks().forEach(v=>v.stop())}catch{}O=null}if(x){if(typeof x.__demoCleanupListeners=="function"){try{x.__demoCleanupListeners()}catch{}delete x.__demoCleanupListeners}try{delete x.duration,delete x.currentTime}catch{}try{delete x.dataset.isDemo,delete x.dataset.demoId,delete x.dataset.demoWidth,delete x.dataset.demoHeight,delete x.__demoController}catch{}try{x.srcObject&&(x.srcObject=null)}catch{}x=null}}}return y(),{canvas:r,get stream(){return O},get currentTime(){return m},set currentTime(v){I(v)},get duration(){return c},get width(){return e},get height(){return s},get paused(){return!h},get playbackRate(){return p},set playbackRate(v){Q(v)},get powerSaveEnabled(){return a},get targetFps(){return P()},get demoItem(){return d},getCurrentTime:()=>m,getDuration:()=>c,getDimensions:()=>({width:e,height:s}),getTargetFps:P,getCanvas:()=>r,seek:I,stepFrame:G,play:H,pause:z,togglePlay:j,setPlaybackRate:Q,setPowerSaveMode:se,setEqGains:v=>{var k;return(k=C==null?void 0:C.setEq)==null?void 0:k.call(C,v)},loadDemo:te,bindToVideoElement:W,captureFrameDataUrl:(v="image/png")=>(y(),r.toDataURL(v)),destroy:Y,detach:Y}}function wi(n,o,a={}){if(!n)return null;On(n);try{n.getAttribute("src")&&(n.pause(),n.removeAttribute("src"),n.load())}catch{}const r=yi(o,a);return r.bindToVideoElement(n),Ve.set(n,r),n.__demoController=r,r}function On(n){if(!n)return;const o=Ve.get(n)||n.__demoController;o&&(o.destroy(),Ve.delete(n));try{n.parentElement&&n.parentElement.querySelectorAll(".vp-demo-canvas").forEach(a=>a.remove())}catch{}}function le(n){return n&&(Ve.get(n)||n.__demoController)||null}function Ae(n){return!!le(n)}const Si=.35,Ei=.65,Pi=6,Bi=8,Ti=6,Ii=1.2,Rn=5,Ai=280,Mi=40,Me=700;function we(n){const o=Number(n);return Number.isFinite(o)?Math.max(0,Math.min(100,Math.round(o))):0}function Ri(n,o={}){if(!n)return{destroy(){},getZoneAt(){return"center"}};const a=new Map;let r=null,t={zone:null,time:0,x:0,y:0};function d(P){const $=a.get(P);$&&(clearTimeout($),a.delete(P))}function e(P,$,y={},D=0){var S;if(d(P),(S=o.onGestureHud)==null||S.call(o,P,!0,$,y),D>0){const E=setTimeout(()=>{var M;a.delete(P),(M=o.onGestureHud)==null||M.call(o,P,!1,$,{...y,ended:!0})},D);a.set(P,E)}}function s(){return n.getBoundingClientRect()}function c(P){const $=s(),y=Math.max(1,$.width),D=(P-$.left)/y;return D<Si?"left":D>Ei?"right":"center"}function m(P,$){const D={left:".vp-zone-left",center:".vp-zone-center",right:".vp-zone-right"}[P];if(!D)return;const S=n.querySelector(D);S&&S.classList.toggle("is-active",!!$)}function p(){n.querySelectorAll(".vp-zone-left, .vp-zone-center, .vp-zone-right").forEach($=>$.classList.remove("is-active"))}function h(){var $;const P=($=o.getBrightness)==null?void 0:$.call(o);return Number.isFinite(Number(P))?we(P):85}function b(){var $;const P=($=o.getVolume)==null?void 0:$.call(o);return Number.isFinite(Number(P))?we(P):80}function A(P){if(P.pointerType==="mouse"&&P.button!==0||P.target&&typeof P.target.closest=="function"&&P.target.closest("button, input, a, select, textarea"))return;const $=s(),y=c(P.clientX),D=y==="left"?h():y==="right"?b():null;r={pointerId:P.pointerId,pointerType:P.pointerType,zone:y,startX:P.clientX,startY:P.clientY,lastX:P.clientX,lastY:P.clientY,stageHeight:Math.max(160,$.height),startValue:D,currentValue:D,isDragging:!1,maxDistance:0,downTime:performance.now()},m(y,!0)}function T(P){var S,E,M;if(!r||P.pointerId!==r.pointerId)return;const $=P.clientX-r.startX,y=P.clientY-r.startY,D=Math.hypot($,y);if(D>r.maxDistance&&(r.maxDistance=D),r.lastX=P.clientX,r.lastY=P.clientY,r.zone==="left"||r.zone==="right"){if(!r.isDragging){const F=Math.abs($),I=Math.abs(y);if(I>=Pi&&I>=F*.75){r.isDragging=!0;try{(S=n.setPointerCapture)==null||S.call(n,P.pointerId)}catch{}}}if(r.isDragging){P.cancelable&&P.preventDefault();const F=s(),I=Math.max(160,F.height||r.stageHeight),G=-y/I*100*Ii,H=we(r.startValue+G);if(r.currentValue=H,r.zone==="left"){const z={source:"gesture-left-swipe",zone:"left",deltaPct:Number(G.toFixed(2)),dy:y,dragging:!0};(E=o.setBrightness)==null||E.call(o,H,z),e("brightness",H,z,0)}else{const z={source:"gesture-right-swipe",zone:"right",deltaPct:Number(G.toFixed(2)),dy:y,dragging:!0};(M=o.setVolume)==null||M.call(o,H,z),e("volume",H,z,0)}}}}function V(P,$=!1){var E,M,F;if(!r||P.pointerId!==r.pointerId)return;const y=r;r=null,m(y.zone,!1);try{(E=n.hasPointerCapture)!=null&&E.call(n,P.pointerId)&&n.releasePointerCapture(P.pointerId)}catch{}if($){if(y.isDragging){const I=y.zone==="left"?"brightness":"volume";e(I,y.currentValue,{zone:y.zone,dragging:!1},Me)}return}if(y.isDragging){const I=y.zone==="left"?"brightness":"volume",G=y.zone==="left"?h():b();e(I,G,{zone:y.zone,source:y.zone==="left"?"gesture-left-swipe":"gesture-right-swipe",dragging:!1},Me);return}const D=Math.hypot(P.clientX-y.startX,P.clientY-y.startY),S=Math.max(D,y.maxDistance);if(y.zone==="center"&&S<Bi){(M=o.onTogglePlayPause)==null||M.call(o,"center-tap"),e("play-pause",null,{zone:"center",source:"center-tap"},550);return}if((y.zone==="left"||y.zone==="right")&&S<Ti){const I=performance.now(),G=I-t.time,H=Math.hypot(P.clientX-t.x,P.clientY-t.y);if(t.zone===y.zone&&G>0&&G<=Ai&&H<=Mi){const z=y.zone==="left"?-10:10;t={zone:null,time:0,x:0,y:0},(F=o.onDoubleTapSeek)==null||F.call(o,z,y.zone),e("seek",z,{zone:y.zone,side:y.zone,deltaSec:z},650)}else t={zone:y.zone,time:I,x:P.clientX,y:P.clientY}}}function L(P){V(P,!1)}function O(P){V(P,!0)}function C(P){var D,S;const $=c(P.clientX);if($!=="left"&&$!=="right")return;P.cancelable&&P.preventDefault();const y=P.deltaY<0?Rn:-Rn;if($==="left"){const E=we(h()+y),M={source:"wheel-left",zone:"left",step:y};(D=o.setBrightness)==null||D.call(o,E,M),e("brightness",E,M,Me)}else if($==="right"){const E=we(b()+y),M={source:"wheel-right",zone:"right",step:y};(S=o.setVolume)==null||S.call(o,E,M),e("volume",E,M,Me)}}function x(P){r!=null&&r.isDragging&&P.preventDefault()}return n.addEventListener("pointerdown",A),n.addEventListener("pointermove",T),n.addEventListener("pointerup",L),n.addEventListener("pointercancel",O),n.addEventListener("wheel",C,{passive:!1}),n.addEventListener("contextmenu",x),{getZoneAt:c,destroy(){a.forEach(P=>clearTimeout(P)),a.clear(),p(),n.removeEventListener("pointerdown",A),n.removeEventListener("pointermove",T),n.removeEventListener("pointerup",L),n.removeEventListener("pointercancel",O),n.removeEventListener("wheel",C),n.removeEventListener("contextmenu",x)}}}function Oe(n){const o=Number(n);return Number.isFinite(o)?(Math.round(o/90)*90%360+360)%360:0}function Li(n,o){if(!n||!o)return"16:9";const a=n/o;return Math.abs(a-16/9)<.08?"16:9":Math.abs(a-9/16)<.05?"9:16":Math.abs(a-21/9)<.12?"21:9":Math.abs(a-4/3)<.06?"4:3":Math.abs(a-3/4)<.06?"3:4":Math.abs(a-1)<.05?"1:1":`${a.toFixed(2)}:1`}function Ci(n={}){const{stageEl:o,rotatorEl:a,videoEl:r,onUpdate:t}=n,d=n.initialAutoRotate!==void 0?!!n.initialAutoRotate:n.autoRotate!==void 0?!!n.autoRotate:!0,e=Oe(n.initialManualRotation!==void 0?n.initialManualRotation:n.manualRotation!==void 0?n.manualRotation:0);let s={width:0,height:0,preferOverride:!1},c={autoRotate:d,manualRotation:e,effectiveRotation:e,rotation:e,isAutoRotated:!1,isQuarterTurn:e===90||e===270,scale:1,stageWidth:1280,stageHeight:720,videoWidth:1280,videoHeight:720,targetWidth:1280,targetHeight:720,fitW0:1280,fitH0:720,area0:1280*720,fitW90:405,fitH90:720,area90:405*720,areaGainRatio:1,coveragePercent:100,simulateViewport:n.simulateViewport||"none",videoAspectLabel:"16:9",stageOrientation:"landscape"},m=null,p=[];function h(){p.forEach(E=>clearTimeout(E)),p=[]}function b(){const E=Number(r==null?void 0:r.videoWidth)||0,M=Number(r==null?void 0:r.videoHeight)||0;return s.preferOverride&&s.width>0&&s.height>0?{vw:s.width,vh:s.height}:E>0&&M>0?{vw:E,vh:M}:s.width>0&&s.height>0?{vw:s.width,vh:s.height}:{vw:1280,vh:720}}function A(){if(!o)return{W:1280,H:720};let E=o.clientWidth,M=o.clientHeight;if(!E||!M){const F=o.getBoundingClientRect();E=Math.round(F.width),M=Math.round(F.height)}return{W:Math.max(1,E||1280),H:Math.max(1,M||720)}}function T(){const{W:E,H:M}=A(),{vw:F,vh:I}=b(),G=Math.min(E/F,M/I),H=Math.max(1,Math.floor(F*G)),z=Math.max(1,Math.floor(I*G)),j=H*z,Q=Math.min(M/F,E/I),se=Math.max(1,Math.floor(F*Q)),te=Math.max(1,Math.floor(I*Q)),W=se*te;let Y=c.manualRotation,R=!1;c.autoRotate&&(W>j*1.04?(Y=(c.manualRotation+90)%360,R=!0):Y=c.manualRotation);const v=Y===90||Y===270,k=v?se:H,Z=v?te:z,ne=k*Z,ie=Math.max(1,E*M);return a&&(a.style.width=`${k}px`,a.style.height=`${Z}px`,a.style.transform=`rotate(${Y}deg) scale(1)`,a.dataset.rotation=String(Y),a.dataset.autoRotated=String(R),a.dataset.scale="1"),c={...c,effectiveRotation:Y,rotation:Y,isAutoRotated:R,isQuarterTurn:v,scale:1,stageWidth:E,stageHeight:M,videoWidth:F,videoHeight:I,targetWidth:k,targetHeight:Z,fitW0:H,fitH0:z,area0:j,fitW90:se,fitH90:te,area90:W,areaGainRatio:j>0?Number((ne/j).toFixed(2)):1,coveragePercent:Number(Math.min(100,ne/ie*100).toFixed(1)),videoAspectLabel:Li(F,I),stageOrientation:E>=M?"landscape":"portrait"},t==null||t({...c}),{...c}}function V(){m!==null&&cancelAnimationFrame(m),m=requestAnimationFrame(()=>{m=null,T()})}function L(E){return c.autoRotate=!!E,T()}function O(){return c.autoRotate=!c.autoRotate,T()}function C(E){return c.manualRotation=Oe(E),T()}function x(E=90){return c.manualRotation=Oe(c.manualRotation+Number(E||0)),T()}function P(E,M){const F=Number(E)||0,I=Number(M)||0;return F>0&&I>0?s={width:Math.round(F),height:Math.round(I),preferOverride:!0}:s={width:0,height:0,preferOverride:!1},T()}function $(E="none"){const M=E==="portrait"||E==="landscape"?E:"none";c.simulateViewport=M;const F=o==null?void 0:o.parentElement;F&&(F.classList.toggle("sim-portrait",M==="portrait"),F.classList.toggle("sim-landscape",M==="landscape"));const I=T();return h(),p.push(setTimeout(()=>T(),60),setTimeout(()=>T(),180),setTimeout(()=>T(),320)),I}function y(){const E=Number(r==null?void 0:r.videoWidth)||0,M=Number(r==null?void 0:r.videoHeight)||0;E>0&&M>0&&(s={width:E,height:M,preferOverride:!1}),T()}function D(){var F,I,G,H,z,j;const{vw:E,vh:M}=b();if(document.fullscreenElement&&c.autoRotate){const Q=E>=M?"landscape":"portrait";try{(H=(G=(I=(F=screen.orientation)==null?void 0:F.lock)==null?void 0:I.call(F,Q))==null?void 0:G.catch)==null||H.call(G,()=>{})}catch{}}else if(!document.fullscreenElement)try{(j=(z=screen.orientation)==null?void 0:z.unlock)==null||j.call(z)}catch{}V(),h(),p.push(setTimeout(()=>T(),120))}let S=null;return typeof ResizeObserver<"u"&&o&&(S=new ResizeObserver(()=>{V()}),S.observe(o),o.parentElement&&S.observe(o.parentElement)),window.addEventListener("resize",V),window.addEventListener("orientationchange",V),document.addEventListener("fullscreenchange",D),r&&(r.addEventListener("loadedmetadata",y),r.addEventListener("resize",y)),T(),{recalculate:T,setAutoRotate:L,toggleAutoRotate:O,setManualRotation:C,rotateBy:x,setIntrinsicSize:P,setSimulateViewport:$,getState(){return{...c}},destroy(){m!==null&&(cancelAnimationFrame(m),m=null),h(),S&&(S.disconnect(),S=null),window.removeEventListener("resize",V),window.removeEventListener("orientationchange",V),document.removeEventListener("fullscreenchange",D),r&&(r.removeEventListener("loadedmetadata",y),r.removeEventListener("resize",y))}}}const _={BRIGHTNESS:"vp_brightness",BRIGHTNESS_META:"vp_brightness_meta",HW_DECODE:"vp_hw_decode",POWER_SAVE:"vp_power_save",ARROW_SWITCH_MODE:"vp_arrow_switch_mode",LAST_DIR_PATH:"vp_last_dir_path",GESTURE_SENSITIVITY:"vp_gesture_sensitivity",REMEMBER_RESUME:"vp_remember_resume",UI_V3_CLEAN:"vp_ui_v3_clean",SETTINGS:"vp_settings_v1",RESUME_MAP:"vp_resume_map"},re={brightness:85,volume:80,muted:!1,autoRotate:!0,manualRotation:0,playbackRate:1,eqPreset:"flat",eqCustom:{bass:0,mid:0,treble:0,boost:1},showGestureGuide:!1,loopMode:"all",simPortrait:!1,hwDecodeEnabled:!0,powerSaveEnabled:!0,arrowKeySwitchMode:!0,gestureSensitivity:1.2,rememberResumePosition:!0,lastDirectoryPath:"",lastVideoId:"demo-cinema-16-9"};function Fn(n){const o=Number(n);return Number.isFinite(o)?Math.max(0,Math.min(100,Math.round(o))):re.brightness}function _n(n){const o=Number(n);return Number.isFinite(o)?Math.max(0,Math.min(100,Math.round(o))):re.volume}function ze(){try{const n=localStorage.getItem(_.BRIGHTNESS);if(n!==null&&n.trim()!==""){const a=Number(n);if(Number.isFinite(a)&&a>=0&&a<=100)return Math.round(a)}if(typeof window<"u"&&window.AndroidPlayerBridge&&typeof window.AndroidPlayerBridge.getSavedBrightness=="function"){const a=Number(window.AndroidPlayerBridge.getSavedBrightness());if(Number.isFinite(a)&&a>=0&&a<=100){const r=Math.round(a);return localStorage.setItem(_.BRIGHTNESS,String(r)),r}}const o=localStorage.getItem(_.SETTINGS);if(o){const a=JSON.parse(o);if(a&&typeof a.brightness=="number"&&Number.isFinite(a.brightness)&&a.brightness>=0&&a.brightness<=100){const r=Math.round(a.brightness);return localStorage.setItem(_.BRIGHTNESS,String(r)),r}}}catch(n){console.warn("[OmniPlay Storage] Failed to read saved brightness:",n)}try{localStorage.setItem(_.BRIGHTNESS,String(re.brightness))}catch{}return re.brightness}function Vi(){try{const n=localStorage.getItem(_.BRIGHTNESS);if(n===null||n.trim()==="")return!1;const o=Number(n);return Number.isFinite(o)&&o>=0&&o<=100}catch{return!1}}function Hn(n,o="user"){const a=Fn(n);try{localStorage.setItem(_.BRIGHTNESS,String(a)),localStorage.setItem(_.BRIGHTNESS_META,JSON.stringify({value:a,source:o,updatedAt:new Date().toISOString()}));const r=localStorage.getItem(_.SETTINGS),t=r?JSON.parse(r):{...re};t.brightness=a,localStorage.setItem(_.SETTINGS,JSON.stringify(t)),typeof window<"u"&&window.AndroidPlayerBridge&&typeof window.AndroidPlayerBridge.setScreenBrightness=="function"&&window.AndroidPlayerBridge.setScreenBrightness(a)}catch(r){console.warn("[OmniPlay Storage] Failed to save brightness:",r)}return a}function qn(){const n=ze();try{const o=localStorage.getItem(_.UI_V3_CLEAN)==="1",a=localStorage.getItem(_.SETTINGS);if(!a){const e={...re,brightness:n,showGestureGuide:!1};return localStorage.setItem(_.SETTINGS,JSON.stringify(e)),localStorage.setItem(_.UI_V3_CLEAN,"1"),e}const r=JSON.parse(a),t=o&&typeof(r==null?void 0:r.showGestureGuide)=="boolean"?r.showGestureGuide:!1,d={...re,...r,brightness:n,volume:_n((r==null?void 0:r.volume)??re.volume),muted:!!((r==null?void 0:r.muted)??re.muted),autoRotate:typeof(r==null?void 0:r.autoRotate)=="boolean"?r.autoRotate:re.autoRotate,manualRotation:[0,90,180,270].includes(Number(r==null?void 0:r.manualRotation))?Number(r.manualRotation):0,playbackRate:Number.isFinite(Number(r==null?void 0:r.playbackRate))&&Number(r.playbackRate)>=.25&&Number(r.playbackRate)<=4?Number(r.playbackRate):1,eqPreset:typeof(r==null?void 0:r.eqPreset)=="string"?r.eqPreset:"flat",eqCustom:{...re.eqCustom,...(r==null?void 0:r.eqCustom)||{}},showGestureGuide:t,hwDecodeEnabled:localStorage.getItem(_.HW_DECODE)!==null?localStorage.getItem(_.HW_DECODE)!=="false":typeof(r==null?void 0:r.hwDecodeEnabled)=="boolean"?r.hwDecodeEnabled:!0,powerSaveEnabled:localStorage.getItem(_.POWER_SAVE)!==null?localStorage.getItem(_.POWER_SAVE)!=="false":typeof(r==null?void 0:r.powerSaveEnabled)=="boolean"?r.powerSaveEnabled:!0,arrowKeySwitchMode:localStorage.getItem(_.ARROW_SWITCH_MODE)!==null?localStorage.getItem(_.ARROW_SWITCH_MODE)!=="false":typeof(r==null?void 0:r.arrowKeySwitchMode)=="boolean"?r.arrowKeySwitchMode:!0,lastDirectoryPath:localStorage.getItem(_.LAST_DIR_PATH)||(typeof(r==null?void 0:r.lastDirectoryPath)=="string"?r.lastDirectoryPath:""),gestureSensitivity:[.8,1,1.2,1.5].includes(Number(localStorage.getItem(_.GESTURE_SENSITIVITY)??(r==null?void 0:r.gestureSensitivity)))?Number(localStorage.getItem(_.GESTURE_SENSITIVITY)??(r==null?void 0:r.gestureSensitivity)):1.2,rememberResumePosition:localStorage.getItem(_.REMEMBER_RESUME)!==null?localStorage.getItem(_.REMEMBER_RESUME)!=="false":typeof(r==null?void 0:r.rememberResumePosition)=="boolean"?r.rememberResumePosition:!0};return o||(localStorage.setItem(_.UI_V3_CLEAN,"1"),localStorage.setItem(_.SETTINGS,JSON.stringify(d))),d}catch(o){return console.warn("[OmniPlay Storage] Failed to load settings, using defaults:",o),{...re,brightness:n}}}function J(n={}){try{const a={...qn(),...n};if(n.brightness!==void 0&&(a.brightness=Fn(n.brightness),localStorage.setItem(_.BRIGHTNESS,String(a.brightness))),n.volume!==void 0&&(a.volume=_n(n.volume)),n.hwDecodeEnabled!==void 0&&(a.hwDecodeEnabled=!!n.hwDecodeEnabled,localStorage.setItem(_.HW_DECODE,String(a.hwDecodeEnabled))),n.powerSaveEnabled!==void 0&&(a.powerSaveEnabled=!!n.powerSaveEnabled,localStorage.setItem(_.POWER_SAVE,String(a.powerSaveEnabled))),n.arrowKeySwitchMode!==void 0&&(a.arrowKeySwitchMode=!!n.arrowKeySwitchMode,localStorage.setItem(_.ARROW_SWITCH_MODE,String(a.arrowKeySwitchMode))),n.lastDirectoryPath!==void 0&&(a.lastDirectoryPath=String(n.lastDirectoryPath||""),localStorage.setItem(_.LAST_DIR_PATH,a.lastDirectoryPath)),n.gestureSensitivity!==void 0){const r=Number(n.gestureSensitivity);a.gestureSensitivity=[.8,1,1.2,1.5].includes(r)?r:1.2,localStorage.setItem(_.GESTURE_SENSITIVITY,String(a.gestureSensitivity))}return n.rememberResumePosition!==void 0&&(a.rememberResumePosition=!!n.rememberResumePosition,localStorage.setItem(_.REMEMBER_RESUME,String(a.rememberResumePosition))),localStorage.setItem(_.SETTINGS,JSON.stringify(a)),a}catch(o){return console.warn("[OmniPlay Storage] Failed to save settings:",o),{...re,...n}}}function ki(){try{return Hn(re.brightness,"factory-reset"),J({...re})}catch{return{...re}}}function Gn(){try{const n=localStorage.getItem(_.RESUME_MAP);if(!n)return{};const o=JSON.parse(n);return o&&typeof o=="object"?o:{}}catch{return{}}}function xi(n){if(!n)return 0;const a=Gn()[n];return!a||typeof a.time!="number"||!Number.isFinite(a.time)?0:Math.max(0,a.time)}function Ln(n,o,a=0){if(!(!n||!Number.isFinite(o)))try{const r=Gn(),t=a>5&&o>=a*.97?0:Math.max(0,Math.round(o*10)/10);r[n]={time:t,duration:Number.isFinite(a)?Math.round(a*10)/10:0,updatedAt:Date.now()},localStorage.setItem(_.RESUME_MAP,JSON.stringify(r))}catch{}}function Di(n,o={}){let a=null,r=null,t=null,d=null,e=null,s=null,c=null,m=null;const p={preset:o.preset||"flat",bass:Number.isFinite(o.bass)?o.bass:0,mid:Number.isFinite(o.mid)?o.mid:0,treble:Number.isFinite(o.treble)?o.treble:0,boost:Number.isFinite(o.boost)?o.boost:1,connected:!1};function h(S){const E=Number(S);return Number.isFinite(E)?Math.max(-12,Math.min(12,Math.round(E*10)/10)):0}function b(S){const E=Number(S);return Number.isFinite(E)?Math.max(.5,Math.min(2,Math.round(E*100)/100)):1}function A(){if(a)return!0;const S=window.AudioContext||window.webkitAudioContext;if(!S)return!1;try{return a=new S,e=a.createBiquadFilter(),e.type="lowshelf",e.frequency.value=100,e.gain.value=p.bass,s=a.createBiquadFilter(),s.type="peaking",s.frequency.value=1e3,s.Q.value=1,s.gain.value=p.mid,c=a.createBiquadFilter(),c.type="highshelf",c.frequency.value=8e3,c.gain.value=p.treble,m=a.createGain(),m.gain.value=p.boost,e.connect(s),s.connect(c),c.connect(m),m.connect(a.destination),!0}catch(E){return console.warn("[OmniPlay EQ] AudioContext creation skipped:",E),!1}}function T(){if(n&&A())try{if(a&&a.state==="suspended"&&a.resume().catch(()=>{}),!n.srcObject&&n.currentSrc&&!r&&(r=a.createMediaElementSource(n),r.connect(e),p.connected=!0),n.srcObject&&r&&d!==n.srcObject){if(t){try{t.disconnect()}catch{}t=null}(typeof n.srcObject.getAudioTracks=="function"?n.srcObject.getAudioTracks():[]).length>0&&(t=a.createMediaStreamSource(n.srcObject),t.connect(e),d=n.srcObject,p.connected=!0)}}catch(S){console.debug("[OmniPlay EQ] Source routing fallback:",(S==null?void 0:S.message)||S)}}function V(){if(!a)return;const S=a.currentTime||0;try{e&&e.gain.setTargetAtTime(p.bass,S,.015),s&&s.gain.setTargetAtTime(p.mid,S,.015),c&&c.gain.setTargetAtTime(p.treble,S,.015),m&&m.gain.setTargetAtTime(p.boost,S,.015)}catch{e&&(e.gain.value=p.bass),s&&(s.gain.value=p.mid),c&&(c.gain.value=p.treble),m&&(m.gain.value=p.boost)}}function L(S){return S&&(p.preset=S.id||"custom",p.bass=h(S.bass??0),p.mid=h(S.mid??0),p.treble=h(S.treble??0),p.boost=b(S.boost??1),A(),T(),V()),y()}function O({preset:S="custom",bass:E,mid:M,treble:F,boost:I}){return p.preset=S,E!==void 0&&(p.bass=h(E)),M!==void 0&&(p.mid=h(M)),F!==void 0&&(p.treble=h(F)),I!==void 0&&(p.boost=b(I)),A(),T(),V(),y()}function C(S,E){const M=h(E);return(S==="bass"||S==="mid"||S==="treble")&&(p[S]=M,p.preset="custom",A(),T(),V()),y()}function x(S){return p.boost=b(S),p.preset="custom",A(),T(),V(),y()}function P(){return O({preset:"flat",bass:0,mid:0,treble:0,boost:1})}function $(){a&&a.state==="suspended"&&a.resume().catch(()=>{})}function y(){return{...p}}function D(){try{t&&t.disconnect(),r&&r.disconnect(),a&&a.state!=="closed"&&a.close().catch(()=>{})}catch{}}return{setPreset:L,setValues:O,setBand:C,setBoost:x,reset:P,syncSource:T,resume:$,getState:y,destroy:D}}const $i=[".mp4",".webm",".mkv",".mov",".avi",".m4v",".ogg",".ogv",".ts",".flv",".wmv"],Ni=[".srt",".vtt"],Oi=new Intl.Collator(void 0,{numeric:!0,sensitivity:"base"});function Un(n,o){return Oi.compare(String(n||""),String(o||""))}function Ke(n=""){const o=String(n).toLowerCase();return $i.some(a=>o.endsWith(a))}function je(n=""){const o=String(n).toLowerCase();return Ni.some(a=>o.endsWith(a))}function Cn(n=""){const o=n.lastIndexOf(".");return o>0?n.slice(0,o):n}function zn(n=0){const o=Number(n)||0;return o<=0?"":`${(o/(1024*1024)).toFixed(2)} MB`}function Fi(n=""){if(!n)return"同目錄資料夾";const o=String(n).replace(/\\/g,"/").replace(/\/+$/,""),a=o.split("/").filter(Boolean);return a[a.length-1]||o||"同目錄資料夾"}async function _i(n,o=""){if(!n||!n.name)return{found:!1,items:[],currentIndex:0};try{const a=new URLSearchParams({name:n.name,size:String(n.size||0),mtime:String(n.lastModified||0)});o&&a.set("dir",o);const r=await fetch(`/api/dir-siblings?${a.toString()}`,{headers:{Accept:"application/json"}});if(!r.ok)return{found:!1,items:[],currentIndex:0};const t=await r.json();if(!t||!t.found||!Array.isArray(t.files)||t.files.length===0)return{found:!1,items:[],currentIndex:0};const d=t.directory||"",e=Fi(d),s=[...t.files].sort((h,b)=>Un(h.name,b.name)),c=s.length;let m=s.findIndex(h=>h.name===n.name&&Number(h.size)===Number(n.size));m===-1&&(m=s.findIndex(h=>h.name.toLowerCase()===n.name.toLowerCase())),m===-1&&(m=0);const p=s.map((h,b)=>{const A=zn(h.size),T=h.streamUrl||`/api/stream-file?path=${encodeURIComponent(h.path||"")}`;return{id:`dir-${d}-${h.name}-${h.size||0}`,title:h.name,subtitle:`📁 ${e} (${b+1}/${c})${A?` • ${A}`:""}`,url:T,streamUrl:T,fullPath:h.path||"",directoryPath:d,directoryName:e,size:h.size||0,mtime:h.mtime||0,aspectLabel:`${b+1}/${c}`,isDemo:!1,isSameDir:!0,dirIndex:b,dirTotal:c}});return{found:!0,directoryPath:d,directoryName:e,total:c,currentIndex:m,items:p}}catch(a){return console.debug("[OmniPlay DirPlaylist] Backend sibling discovery skipped:",a),{found:!1,items:[],currentIndex:0}}}function Wn(n=[],o="",a=""){var h;const r=Array.from(n||[]),t=[],d=[];for(const b of r)!b||!b.name||(je(b.name)?d.push(b):((h=b.type)!=null&&h.startsWith("video/")||Ke(b.name))&&t.push(b));t.sort((b,A)=>Un(b.name,A.name));let e=a||"本機同目錄片單";if(!a&&t.length>0){const b=t[0].webkitRelativePath||"";b&&b.includes("/")&&(e=b.split("/")[0]||e)}const s=new Map;for(const b of d){const A=Cn(b.name).toLowerCase();s.set(A,b)}const c=t.length,m=t.map((b,A)=>{const T=URL.createObjectURL(b),V=zn(b.size),L=Cn(b.name).toLowerCase(),O=s.get(L)||d.find(C=>C.name.toLowerCase().startsWith(`${L}.`))||null;return{id:`local-${e}-${b.name}-${b.size||0}`,title:b.name,subtitle:`📁 ${e} (${A+1}/${c})${V?` • ${V}`:""}`,url:T,file:b,pairedSubtitleFile:O,directoryName:e,directoryPath:e,size:b.size||0,mtime:b.lastModified||0,aspectLabel:`${A+1}/${c}`,isDemo:!1,isSameDir:!0,dirIndex:A,dirTotal:c}});let p=0;if(o){const b=m.findIndex(A=>A.title.toLowerCase()===o.toLowerCase());b!==-1&&(p=b)}return{directoryName:e,total:c,currentIndex:p,items:m,subtitleFiles:d}}async function Hi(){if(typeof window>"u"||typeof window.showDirectoryPicker!="function")return{supported:!1};try{const n=await window.showDirectoryPicker({mode:"read"}),o=[];for await(const[r,t]of n.entries())if(t.kind==="file"&&(Ke(r)||je(r)))try{const d=await t.getFile();o.push(d)}catch{}return{supported:!0,cancelled:!1,...Wn(o,"",n.name||"已選取資料夾")}}catch(n){return n&&n.name==="AbortError"?{supported:!0,cancelled:!0,items:[]}:{supported:!1}}}async function Kn(n,o=2,a=0){if(!n)return[];if(n.isFile)return new Promise(r=>{n.file(t=>r([t]),()=>r([]))});if(n.isDirectory&&a<o){const r=n.createReader(),t=[],d=()=>new Promise(s=>{r.readEntries(async c=>{!c||c.length===0||(t.push(...c),await d()),s()},()=>s())});return await d(),(await Promise.all(t.map(s=>Kn(s,o,a+1)))).flat()}return[]}async function qi(n){if(!n)return{folderName:"",files:[]};const a=Array.from(n.items||[]).map(r=>typeof r.webkitGetAsEntry=="function"?r.webkitGetAsEntry():null).filter(Boolean);if(a.length>0&&a.some(r=>r.isDirectory)){const r=a.find(e=>e.isDirectory),t=r?r.name:"拖曳資料夾",d=await Promise.all(a.map(e=>Kn(e,2,0)));return{folderName:t,files:d.flat()}}return{folderName:"",files:Array.from(n.files||[])}}function ge(n){if(!Number.isFinite(n)||n<0)return"00:00";const o=Math.floor(n),a=Math.floor(o/3600),r=Math.floor(o%3600/60),t=o%60;return a>0?`${a}:${String(r).padStart(2,"0")}:${String(t).padStart(2,"0")}`:`${String(r).padStart(2,"0")}:${String(t).padStart(2,"0")}`}function Vn(n){if(!n||typeof n!="string")return[];const o=[],a=n.replace(/\r\n/g,`
`).replace(/\r/g,`
`).split(/\n\s*\n/),r=/(?:(\d{1,2}):)?(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(?:(\d{1,2}):)?(\d{2}):(\d{2})[.,](\d{3})/;for(const t of a){const d=t.split(`
`).map(h=>h.trim()).filter(Boolean);if(d.length===0||d[0].startsWith("WEBVTT"))continue;let e=-1;for(let h=0;h<Math.min(d.length,3);h++)if(r.test(d[h])){e=h;break}if(e===-1)continue;const s=d[e].match(r);if(!s)continue;const c=Number(s[1]||0)*3600+Number(s[2])*60+Number(s[3])+Number(s[4])/1e3,m=Number(s[5]||0)*3600+Number(s[6])*60+Number(s[7])+Number(s[8])/1e3,p=d.slice(e+1).join(" ").replace(/<[^>]+>/g,"").trim();p&&m>c&&o.push({start:c,end:m,text:p})}return o}function kn(){var Te,Je,et,tt,nt,it,ot,at,rt,st,lt,dt,ct,ut,pt,mt,gt,vt,ft,bt,ht,yt,wt,St,Et,Pt,Bt,Tt,It,At,Mt,Rt,Lt,Ct,Vt,kt,xt,Dt,$t,Nt,Ot,Ft,_t,Ht,qt,Gt,Ut,zt,Wt,Kt,jt,Zt,Xt,Qt,Yt,Jt,en,tn,nn,on,an,rn,sn,ln,dn,cn,un,pn,mn,gn,vn,fn,bn,hn,yn,wn;const n=document.getElementById("app");if(!n)return;try{(Je=(Te=window.AndroidPlayerBridge)==null?void 0:Te.setScreenOrientation)==null||Je.call(Te,"landscape"),typeof screen<"u"&&screen.orientation&&typeof screen.orientation.lock=="function"&&screen.orientation.lock("landscape").catch(()=>{})}catch{}const o=Vi(),a=qn(),r=ze(),t={playlist:[...Pn],currentIndex:0,directoryName:"內建比例測試目錄",directoryPath:"內建 4 組多比例幾何測試串流 (16:9 / 9:16 / 21:9 / 4:3)",brightness:r,brightnessRestored:o,volume:a.volume,muted:a.muted,autoRotate:a.autoRotate,manualRotation:a.manualRotation,simPortrait:!!a.simPortrait,playbackRate:a.playbackRate,loopMode:a.loopMode||"all",showGestureGuide:!!a.showGestureGuide,hwDecodeEnabled:a.hwDecodeEnabled!==!1,powerSaveEnabled:a.powerSaveEnabled!==!1,arrowKeySwitchMode:a.arrowKeySwitchMode!==!1,gestureSensitivity:Number(a.gestureSensitivity)||1.2,rememberResumePosition:a.rememberResumePosition!==!1,lastDirectoryPath:a.lastDirectoryPath||"",eqPreset:a.eqPreset||"flat",eqCustom:{...a.eqCustom},activeDrawer:null,activeModal:null,subtitlesEnabled:!0,customSubtitles:null,customSubtitleName:"",abLoop:{a:null,b:null},isScrubbing:!1,isGestureSwiping:!1},d=t.playlist.findIndex(i=>i.id===a.lastVideoId);d!==-1&&(t.currentIndex=d),n.innerHTML=`
    <div class="vp-app" id="vpApp">
      <!-- Minimalist Cinema Floating Top Bar (Single Row, Auto-Hides in 3s) -->
      <header class="vp-topbar" id="vpTopbar">
        <div class="vp-topbar-left">
          <div class="vp-logo" title="OmniPlay Pro 全螢幕劇院引擎">▶</div>
          <div class="vp-title-group">
            <div class="vp-video-title-row">
              <h1 class="vp-video-title" id="vpVideoTitle">載入中...</h1>
              <span class="vp-aspect-badge" id="vpAspectBadge">1/${t.playlist.length}</span>
            </div>
          </div>
        </div>

        <!-- Hidden Telemetry Nodes (Kept for programmatic state & Settings sync) -->
        <div class="vp-status-bar" aria-hidden="true">
          <div class="vp-status-pill vp-pill-dir vp-dir-pill" data-pill="dir" id="vpDirPill">
            <strong id="vpDirPillVal">1/${t.playlist.length} (${t.directoryName})</strong>
          </div>
          <div class="vp-status-pill vp-pill-brightness" data-pill="brightness" id="vpBrightnessPill">
            <span class="vp-memory-tag" id="vpBrightnessMemoryTag">${t.brightnessRestored?"已還原記憶":"已記憶"}</span>
          </div>
          <div class="vp-status-pill vp-pill-orientation" data-pill="orientation" id="vpOrientationPill">
            <strong id="vpOrientationPillVal">開啟 | 旋轉: 0° | Scale: 1.00x 無損最大化</strong>
          </div>
          <div class="vp-status-pill vp-pill-hw" data-pill="hw-power" id="vpHwPowerPill">
            <strong id="vpHwPowerPillVal">⚡ 硬體解碼 • 🍃 節電中</strong>
          </div>
        </div>

        <!-- Right Side: Only 5 Clean Cinema Action Buttons -->
        <div class="vp-top-actions">
          <button type="button" class="vp-btn vp-btn-primary" id="btnOpenFile" title="開啟本機影片並自動掃描同目錄所有影片">
            <span>📂 開啟</span>
          </button>
          <button type="button" class="vp-btn" id="btnOpenFolder" title="選擇整個資料夾建立同目錄連播片單">
            <span>📁 資料夾</span>
          </button>
          <button type="button" class="vp-btn" id="btnDrawerPlaylist" title="開啟同目錄片單 (${t.playlist.length} 部)">
            <span>🎬 片單</span>
          </button>
          ${Jn()}
          <button type="button" class="vp-btn" id="btnDrawerSettings" title="開啟設定與進階工具中心">
            <span>⚙️ 設定</span>
          </button>
        </div>

        <!-- Hidden File & Folder Inputs -->
        <input type="file" id="inputVideoFile" accept=".mp4,.webm,.ogg,.mov,.mkv,.avi,.m4v,.ts,.flv,.wmv,video/*" multiple style="display:none;" />
        <input type="file" id="inputFolderFiles" webkitdirectory directory multiple style="display:none;" />
        <input type="file" id="inputSubFile" accept=".srt,.vtt,text/vtt" style="display:none;" />
      </header>

      <!-- Main Stage Area -->
      <main class="vp-main">
        <div class="vp-stage-shell ${t.simPortrait?"sim-portrait":""}" id="vpStageShell">
          <div class="vp-stage" id="vpStage">
            <!-- Lossless Scale(1) Rotator Container -->
            <div class="vp-rotator" id="vpRotator">
              <video class="vp-video" id="vpVideo" playsinline webkit-playsinline preload="metadata"></video>
              <div class="vp-subtitle-box" id="vpSubtitleBox"></div>
            </div>

            <!-- GPU-Composited Brightness Veil for Zero-Copy MPO & Deep Dimming -->
            <div class="vp-brightness-veil" id="vpBrightnessVeil"></div>

            <!-- Top-Center Video Switch HUD Toast (.vp-switch-toast) -->
            <div class="vp-switch-toast" id="vpSwitchToast">
              <span class="vp-switch-toast-badge" id="vpSwitchToastBadge">⏭ 下一片 (1/4)</span>
              <span class="vp-switch-toast-title" id="vpSwitchToastTitle">星際地平線</span>
            </div>

            <!-- Stage Geometry & Hardware Status Floating Badge -->
            <div class="vp-stage-badge" id="vpStageBadge">
              <span id="vpStageBadgeText">1280×720 • 旋轉 0° • Scale 1.00x 無損最大化</span>
            </div>

            <!-- Stage Left/Right Edge Floating Prev/Next Buttons (.vp-stage-edge-nav) -->
            <div class="vp-stage-edge-nav">
              <button type="button" class="vp-edge-prev" id="btnEdgePrev" title="同目錄上一片 (快捷鍵: PageUp / P / Shift+← / ←)">
                <span class="vp-edge-icon">⏮</span>
                <div class="vp-edge-preview">
                  <span class="vp-edge-label" id="edgePrevLabel">同目錄上一片</span>
                  <span class="vp-edge-filename" id="edgePrevFilename">上一部影片</span>
                </div>
              </button>

              <button type="button" class="vp-edge-next" id="btnEdgeNext" title="同目錄下一片 (快捷鍵: PageDown / N / Shift+→ / →)">
                <span class="vp-edge-icon">⏭</span>
                <div class="vp-edge-preview">
                  <span class="vp-edge-label" id="edgeNextLabel">同目錄下一片</span>
                  <span class="vp-edge-filename" id="edgeNextFilename">下一部影片</span>
                </div>
              </button>
            </div>

            <!-- 3-Zone Touch & Pointer Gesture Layer (Left 35% | Center 30% | Right 35%) -->
            <div class="vp-gesture-layer ${t.showGestureGuide?"show-guide":""}" id="vpGestureLayer">
              <div class="vp-zone vp-zone-left" id="vpZoneLeft">
                <div class="vp-zone-guide">
                  <span>☀️ 左側上下滑：亮度</span>
                  <span class="vp-zone-guide-sub">目前 <strong id="vpGuideBrightnessVal">${t.brightness}%</strong>（自動記憶上次設定）• 雙擊快退 10 秒</span>
                </div>
              </div>

              <div class="vp-zone vp-zone-center" id="vpZoneCenter">
                <div class="vp-zone-guide">
                  <span>⏯️ 中間點擊：播放 / 暫停</span>
                  <span class="vp-zone-guide-sub">單擊立即切換播放狀態 • 按前後鍵 ⏮/⏭ 同目錄換片</span>
                </div>
              </div>

              <div class="vp-zone vp-zone-right" id="vpZoneRight">
                <div class="vp-zone-guide">
                  <span>🔊 右側上下滑：音量</span>
                  <span class="vp-zone-guide-sub">目前 <strong id="vpGuideVolumeVal">${t.volume}%</strong> • 雙擊快轉 10 秒</span>
                </div>
              </div>
            </div>

            <!-- Left Floating Brightness HUD Meter -->
            <div class="vp-hud-pill vp-hud-brightness" id="vpHudBrightness">
              <span class="vp-hud-icon">☀️</span>
              <span class="vp-hud-label">亮度記憶</span>
              <div class="vp-hud-bar-track">
                <div class="vp-hud-bar-fill" id="vpHudBrightnessFill" style="height: ${t.brightness}%;"></div>
              </div>
              <span class="vp-hud-value" id="vpHudBrightnessVal">${t.brightness}%</span>
            </div>

            <!-- Right Floating Volume HUD Meter -->
            <div class="vp-hud-pill vp-hud-volume" id="vpHudVolume">
              <span class="vp-hud-icon" id="vpHudVolumeIcon">🔊</span>
              <span class="vp-hud-label">音量控制</span>
              <div class="vp-hud-bar-track">
                <div class="vp-hud-bar-fill" id="vpHudVolumeFill" style="height: ${t.muted?0:t.volume}%;"></div>
              </div>
              <span class="vp-hud-value" id="vpHudVolumeVal">${t.muted?"靜音":`${t.volume}%`}</span>
            </div>

            <!-- Center Play / Pause Animated Ripple Feedback -->
            <div class="vp-center-ripple" id="vpCenterRipple">
              <span id="vpCenterRippleIcon">⏯️</span>
              <span class="vp-center-ripple-label" id="vpCenterRippleLabel">播放</span>
            </div>

            <!-- Double-Tap Seek ±10s Indicator -->
            <div class="vp-seek-indicator" id="vpSeekIndicator">⏪ -10s</div>
          </div>
        </div>

        <!-- Side Drawer: Complete System & Player Settings Center (#drawerSettings) -->
        <aside class="vp-drawer" id="drawerSettings" aria-label="系統與播放設定中心">
          <div class="vp-drawer-header">
            <div class="vp-drawer-title">⚙️ 系統與播放設定中心</div>
            <button type="button" class="vp-drawer-close" data-close-drawer>×</button>
          </div>
          <div class="vp-drawer-body">
            <!-- Section 1: Cloud OTA & Version Center (Learned from LIFE Project) -->
            <div class="vp-settings-section vp-eq-band" style="border-color: rgba(56, 189, 248, 0.4); background: linear-gradient(135deg, rgba(15, 23, 42, 0.8), rgba(30, 27, 75, 0.55));">
              <div class="vp-eq-band-row">
                <span class="vp-settings-label" style="font-weight:700; color: var(--accent-cyan-light);">☁️ P2R-OTA 雲端熱更與版本中心</span>
                <span class="vp-badge" id="settings-ota-ver-label">OTA v${ce} (${ve})</span>
              </div>
              <div class="vp-settings-desc" id="settings-ota-layer-label" style="font-size:0.75rem; color: var(--text-secondary);">
                📦 目前載入圖層檢測中...
              </div>
              <div style="display:flex; flex-direction:column; gap:6px; margin-top:4px;">
                <div style="display:flex; gap:6px;">
                  <button type="button" class="vp-btn vp-btn-primary" id="btnSettingsOpenOta" style="flex:1;">
                    ☁️ 開啟雲端更新中心
                  </button>
                  <button type="button" class="vp-btn" id="btnSettingsCheckOta" style="flex:1;">
                    🔄 立即檢查新版本
                  </button>
                </div>
                <button type="button" class="vp-btn" id="btnSettingsUpgradeApk" style="border-color: rgba(16, 185, 129, 0.5); color: var(--accent-emerald);">
                  📦 下載並安裝最新完整版 Android APK (Tier-3)
                </button>
              </div>
            </div>

            <!-- Section 2: Gesture & Control Settings -->
            <div class="vp-settings-section vp-eq-band">
              <div style="font-weight:700; font-size:0.84rem; color: var(--accent-amber-light);">👆 手勢與操控設定</div>

              <div class="vp-settings-row vp-eq-band-row">
                <span class="vp-settings-label">☀️ 畫面亮度記憶 (<strong id="settingsBrightnessVal">${t.brightness}%</strong>)</span>
                <button type="button" class="vp-btn" id="btnSettingsResetBrightness" style="padding:3px 8px; font-size:0.72rem;">重設 85%</button>
              </div>
              <input type="range" class="vp-slider vp-brightness-slider" id="settingsSliderBrightness" min="0" max="100" step="1" value="${t.brightness}" />

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">🔊 預設音量大小 (<strong id="settingsVolumeVal">${t.muted?"靜音":`${t.volume}%`}</strong>)</span>
              </div>
              <input type="range" class="vp-slider vp-volume-slider" id="settingsSliderVolume" min="0" max="100" step="1" value="${t.muted?0:t.volume}" />

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:6px;">
                <div>
                  <div class="vp-settings-label">上下滑動手勢靈敏度</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">調整左亮度 / 右音量垂直滑動反應速度</div>
                </div>
                <div class="vp-seg-group" id="settingsSensitivityGroup" style="display:flex; gap:4px;">
                  ${[.8,1,1.2,1.5].map(i=>`<button type="button" class="vp-btn ${t.gestureSensitivity===i?"is-active":""}" data-sens="${i}" style="padding:4px 7px; font-size:0.72rem;">${i}x</button>`).join("")}
                </div>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <div>
                  <div class="vp-settings-label">⏮/⏭ 鍵盤左右方向鍵 (← / →) 模式</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">開啟時按 ←/→ 直接切換同目錄前後片；關閉時快進退 5 秒</div>
                </div>
                <button type="button" class="vp-btn ${t.arrowKeySwitchMode?"is-active":""}" id="btnSettingsArrowMode">
                  ${t.arrowKeySwitchMode?"同目錄換片":"快轉 ±5秒"}
                </button>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">👆 顯示三區手勢導覽提示層</span>
                <button type="button" class="vp-btn ${t.showGestureGuide?"is-active":""}" id="btnSettingsGestureGuide">
                  ${t.showGestureGuide?"已開啟":"已隱藏"}
                </button>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">⏱️ 自動記憶各影片上次播放進度</span>
                <button type="button" class="vp-btn ${t.rememberResumePosition?"is-active":""}" id="btnSettingsRememberResume">
                  ${t.rememberResumePosition?"已開啟":"已關閉"}
                </button>
              </div>
            </div>

            <!-- Section 3: Orientation & Lossless Scale(1) Maximization -->
            <div class="vp-settings-section vp-eq-band">
              <div style="font-weight:700; font-size:0.84rem; color: var(--primary-light);">🔄 畫面與無損自動轉向 (Scale 1.00x)</div>

              <div class="vp-settings-row vp-eq-band-row">
                <div>
                  <div class="vp-settings-label">智慧偵測比例自動轉向滿版</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">固定 Scale(1) 零裁切、零變形最大化</div>
                </div>
                <button type="button" class="vp-btn ${t.autoRotate?"is-active":""}" id="btnSettingsAutoRotate">
                  ${t.autoRotate?"已開啟":"已關閉"}
                </button>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">手動基準旋轉角度</span>
                <div class="vp-seg-group" id="settingsRotationGroup" style="display:flex; gap:4px;">
                  ${[0,90,180,270].map(i=>`<button type="button" class="vp-btn ${t.manualRotation===i?"is-active":""}" data-rot="${i}" style="padding:4px 8px; font-size:0.72rem;">${i}°</button>`).join("")}
                </div>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">📱 模擬 9:16 手機直向視窗框體</span>
                <button type="button" class="vp-btn ${t.simPortrait?"is-active":""}" id="btnSettingsSimPortrait">
                  ${t.simPortrait?"模擬中 (9:16)":"全寬視窗"}
                </button>
              </div>
            </div>

            <!-- Section 4: Hardware Decoding, Eco Power Saving & Factory Reset -->
            <div class="vp-settings-section vp-eq-band">
              <div style="font-weight:700; font-size:0.84rem; color: var(--accent-emerald);">⚡ 硬體解碼與智慧節電 (預設開啟)</div>

              <div class="vp-settings-row vp-eq-band-row">
                <div>
                  <div class="vp-settings-label">⚡ GPU 硬體解碼加速 (MPO Zero-Copy)</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">優先啟用硬體圖層與零拷貝亮度遮罩</div>
                </div>
                <button type="button" class="vp-btn ${t.hwDecodeEnabled?"is-active":""}" id="btnSettingsHwDecode">
                  ${t.hwDecodeEnabled?"已開啟":"已關閉"}
                </button>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <div>
                  <div class="vp-settings-label">🍃 智慧節省電力模式 (Eco Mode)</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">4Hz UI 輪詢休眠、30FPS Eco 渲染與智慧喚醒鎖</div>
                </div>
                <button type="button" class="vp-btn ${t.powerSaveEnabled?"is-active":""}" id="btnSettingsPowerSave">
                  ${t.powerSaveEnabled?"節電開啟":"全速效能"}
                </button>
              </div>

              <!-- Section 5: Pro Playback Tools & Secondary Actions (Moved from Main Bars for Clean Cinema UI) -->
              <div style="margin-top:10px; padding-top:10px; border-top:1px solid var(--glass-border); display:flex; flex-direction:column; gap:8px;">
                <div style="font-weight:700; font-size:0.82rem; color: var(--accent-cyan-light);">🛠️ 進階工具箱與畫面控制</div>

                <div style="display:flex; flex-wrap:wrap; gap:6px;">
                  <button type="button" class="vp-btn ${t.autoRotate?"is-active":""}" id="btnAutoRotate" title="開啟/關閉自動轉向無損最大化 (快捷鍵 A)">🔄 自動轉向</button>
                  <button type="button" class="vp-btn ${t.simPortrait?"is-active":""}" id="btnSimPortrait" title="模擬手機 9:16 直向視窗框體">📱 手機框</button>
                  <button type="button" class="vp-btn ${t.hwDecodeEnabled?"is-active":""}" id="btnHwDecode" title="切換 GPU 硬體解碼加速">⚡ 硬體解碼</button>
                  <button type="button" class="vp-btn ${t.powerSaveEnabled?"is-active":""}" id="btnPowerSave" title="切換智慧節省電力模式">🍃 節省電力</button>
                  <button type="button" class="vp-btn ${t.showGestureGuide?"is-active":""}" id="btnGestureGuide" title="顯示/隱藏三區手勢導覽格線 (快捷鍵 G)">👆 手勢導覽</button>
                  <button type="button" class="vp-btn ${t.arrowKeySwitchMode?"is-active":""}" id="btnArrowSwitchMode" title="切換鍵盤左右方向鍵模式">⏮/⏭ 方向鍵換片</button>
                </div>

                <div style="display:flex; flex-wrap:wrap; gap:6px;">
                  <button type="button" class="vp-btn" id="btnOpenUrl" title="載入遠端串流或影片網址">🔗 載入網址</button>
                  <button type="button" class="vp-btn" id="btnOpenSub" title="載入 .srt 或 .vtt 外掛字幕檔">💬 載入字幕</button>
                  <button type="button" class="vp-btn ${t.subtitlesEnabled?"is-active":""}" id="btnSubToggle" title="顯示/隱藏字幕">💬 字幕開關</button>
                  <button type="button" class="vp-btn" id="btnScreenshot" title="擷取目前無損畫面並下載 PNG">📸 截圖</button>
                  <button type="button" class="vp-btn" id="btnDrawerEq" title="3 頻段 Web Audio 等化器與增益">🎚️ 音效 EQ</button>
                  <button type="button" class="vp-btn" id="btnDrawerHw" title="硬體解碼與智慧節電監控面板">🔋 硬體/節電</button>
                  <button type="button" class="vp-btn" id="btnModalShortcuts" title="檢視鍵盤與手勢快捷鍵">⌨️ 快捷鍵</button>
                </div>

                <div style="display:flex; flex-wrap:wrap; gap:6px;">
                  <button type="button" class="vp-btn" id="btnSetPointA" title="設定 A-B 循環起點 A (快捷鍵 [)">點 A</button>
                  <button type="button" class="vp-btn" id="btnSetPointB" title="設定 A-B 循環終點 B (快捷鍵 ])">點 B</button>
                  <button type="button" class="vp-btn" id="btnClearAb" title="清除 A-B 區間循環" style="display:none;">清除 A-B</button>
                  <button type="button" class="vp-btn" id="btnStepBack" title="倒退 1 幀">-1幀</button>
                  <button type="button" class="vp-btn" id="btnStepForward" title="前進 1 幀">+1幀</button>
                  <button type="button" class="vp-btn" id="btnLoopMode" title="切換循環播放模式">🔁 循環: 全部</button>
                  <button type="button" class="vp-btn" id="btnPip" title="子母畫面 (Picture-in-Picture)">🖼️ 子母畫面</button>
                </div>

                <!-- Hidden Mirror Sliders for Programmatic Compatibility -->
                <div style="display:none;" aria-hidden="true">
                  <input type="range" id="sliderBrightness" min="0" max="100" step="1" value="${t.brightness}" />
                  <span id="sliderBrightnessVal">${t.brightness}%</span>
                  <input type="range" id="sliderVolume" min="0" max="100" step="1" value="${t.muted?0:t.volume}" />
                  <span id="sliderVolumeVal">${t.muted?"靜音":`${t.volume}%`}</span>
                </div>
              </div>

              <div style="margin-top:8px; padding-top:8px; border-top:1px solid var(--glass-border); display:flex; justify-content:space-between; align-items:center;">
                <span style="font-size:0.75rem; color:var(--text-muted);">重設所有播放器偏好設定</span>
                <button type="button" class="vp-btn" id="btnSettingsFactoryReset" style="border-color: rgba(244, 63, 94, 0.45); color: #fda4af;">
                  🔄 恢復出廠預設設定
                </button>
              </div>
            </div>
          </div>
        </aside>

        <!-- Side Drawer: Same-Directory Playlist -->
        <aside class="vp-drawer" id="drawerPlaylist" aria-label="同目錄播放清單">
          <div class="vp-drawer-header">
            <div class="vp-drawer-title">🎬 同目錄片單 &amp; 比例測試串流</div>
            <button type="button" class="vp-drawer-close" data-close-drawer>×</button>
          </div>
          <div class="vp-drawer-body">
            <!-- Same-Directory Status Banner (.vp-dir-banner) -->
            <div class="vp-dir-banner" id="vpDirBanner">
              <div class="vp-dir-banner-header">
                <span class="vp-dir-title">📁 <span id="vpDirBannerName">${t.directoryName}</span></span>
                <span class="vp-dir-count" id="vpDirBannerCount">1 / ${t.playlist.length} 部</span>
              </div>
              <div class="vp-dir-path" id="vpDirBannerPath">${t.directoryPath}</div>
              <div style="font-size: 0.72rem; color: var(--text-muted); margin-top: 2px;">
                💡 開啟單一影片時會自動掃描同資料夾內所有影片；按 <code>⏮/⏭</code>、<code>PageUp/PageDown</code>、<code>P/N</code>、<code>Shift+←/→</code> 或 <code>←/→</code> 即可直接換片！
              </div>
            </div>

            <div style="display:flex; gap:6px; flex-wrap:wrap;">
              <button type="button" class="vp-btn vp-btn-primary" id="btnDrawerAddFile" style="flex:1;">📂 選取影片 (自動同目錄)</button>
              <button type="button" class="vp-btn" id="btnDrawerOpenFolder" style="flex:1;">📁 開啟資料夾</button>
              <button type="button" class="vp-btn" id="btnDrawerResetDemo" title="載入內建 4 組比例測試串流">🎞️ 內建測試片</button>
            </div>

            <div class="vp-playlist-list" id="vpPlaylistContainer"></div>
          </div>
        </aside>

        <!-- Side Drawer: Equalizer -->
        <aside class="vp-drawer" id="drawerEq" aria-label="音效等化器">
          <div class="vp-drawer-header">
            <div class="vp-drawer-title">🎚️ 3 頻段 Web Audio 等化器</div>
            <button type="button" class="vp-drawer-close" data-close-drawer>×</button>
          </div>
          <div class="vp-drawer-body">
            <div class="vp-eq-presets" id="vpEqPresetsContainer"></div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>低頻 Bass (100 Hz)</span>
                <strong id="eqBassVal">0 dB</strong>
              </div>
              <input type="range" class="vp-slider" id="eqBassSlider" min="-12" max="12" step="0.5" value="0" />
            </div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>中頻人聲 Mid (1000 Hz)</span>
                <strong id="eqMidVal">0 dB</strong>
              </div>
              <input type="range" class="vp-slider" id="eqMidSlider" min="-12" max="12" step="0.5" value="0" />
            </div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>高頻細節 Treble (8000 Hz)</span>
                <strong id="eqTrebleVal">0 dB</strong>
              </div>
              <input type="range" class="vp-slider" id="eqTrebleSlider" min="-12" max="12" step="0.5" value="0" />
            </div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>前級增益 Preamp Boost</span>
                <strong id="eqBoostVal">1.00x</strong>
              </div>
              <input type="range" class="vp-slider" id="eqBoostSlider" min="0.5" max="2.0" step="0.05" value="1.0" />
            </div>

            <button type="button" class="vp-btn" id="btnEqReset">🔄 重設為原音直通 (Flat)</button>
          </div>
        </aside>

        <!-- Side Drawer: Hardware Decoding & Power Saving Telemetry -->
        <aside class="vp-drawer" id="drawerHw" aria-label="硬體解碼與智慧節電引擎">
          <div class="vp-drawer-header">
            <div class="vp-drawer-title">⚡ 硬體解碼 &amp; 🍃 智慧節電引擎</div>
            <button type="button" class="vp-drawer-close" data-close-drawer>×</button>
          </div>
          <div class="vp-drawer-body">
            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>⚡ GPU 硬體解碼加速 (預設開啟)</span>
                <button type="button" class="vp-btn ${t.hwDecodeEnabled?"is-active":""}" id="btnPanelHwToggle">
                  ${t.hwDecodeEnabled?"已開啟 (Prefer-HW)":"已關閉 (軟體)"}
                </button>
              </div>
              <div style="font-size: 0.74rem; color: var(--text-muted);">
                啟用硬體圖層提升與 Zero-Copy MPO 零拷貝亮度遮罩（亮度 ≤ 85% 時免除像素著色器濾鏡耗電）。
              </div>
            </div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>🍃 智慧節省電力模式 (預設開啟)</span>
                <button type="button" class="vp-btn ${t.powerSaveEnabled?"is-active":""}" id="btnPanelPowerToggle">
                  ${t.powerSaveEnabled?"節電開啟 (Eco)":"全速效能"}
                </button>
              </div>
              <div style="font-size: 0.74rem; color: var(--text-muted);">
                自動降低非必要 UI 輪詢至 4Hz (250ms) 讓 CPU 進入深層休眠、背景分頁自動降頻至 5FPS，並智慧管理螢幕喚醒鎖。
              </div>
            </div>

            <div class="vp-eq-band" id="vpHwTelemetryCard">
              <div class="vp-eq-band-row">
                <span>解碼管線路徑</span>
                <strong id="hwDecodePathVal" style="color: var(--accent-emerald);">GPU 硬體加速 (MPO Zero-Copy)</strong>
              </div>
              <div class="vp-eq-band-row">
                <span>節電狀態與預估功耗節省</span>
                <strong id="hwPowerSaveVal" style="color: var(--accent-cyan-light);">節電中 (-42% 功耗)</strong>
              </div>
              <div class="vp-eq-band-row">
                <span>電池 / 電源狀態</span>
                <strong id="hwBatteryVal">電源直供 / 100%</strong>
              </div>
              <div class="vp-eq-band-row">
                <span>UI 更新頻率 / 掉幀率</span>
                <strong id="hwFrameQualityVal">4Hz Eco • 掉幀 0 (0.00%)</strong>
              </div>
            </div>

            <div class="vp-eq-band">
              <div style="font-size: 0.8rem; font-weight: 600; margin-bottom: 4px;">硬體解碼器能力探測 (MediaCapabilities)</div>
              <div id="vpCodecList" style="display:flex; flex-direction:column; gap:6px; font-size:0.76rem;"></div>
            </div>
          </div>
        </aside>

        <!-- Drag & Drop Overlay -->
        <div class="vp-drop-overlay" id="vpDropOverlay">
          <div style="font-size: 2.6rem;">📂</div>
          <div>放開滑鼠以載入本機影片、整個資料夾或字幕檔 (.mp4 / .webm / .mkv / .srt / .vtt)</div>
        </div>
      </main>

      <!-- Minimalist Cinema Floating Bottom Control Bar (Auto-Hides in 3s) -->
      <footer class="vp-controls" id="vpControls">
        <!-- Row 1: Full-Width Slim Timeline Progress Row -->
        <div class="vp-timeline-row">
          <span class="vp-time-display" id="vpCurrentTime">00:00</span>

          <div class="vp-progress-wrap" id="vpProgressWrap">
            <div class="vp-progress-bar" id="vpProgressBar">
              <div class="vp-progress-buffered" id="vpProgressBuffered"></div>
              <div class="vp-ab-range" id="vpAbRange" style="display:none;"></div>
              <div class="vp-ab-marker" id="vpAbMarkerA" data-label="A" style="display:none;"></div>
              <div class="vp-ab-marker" id="vpAbMarkerB" data-label="B" style="display:none;"></div>
              <div class="vp-progress-played" id="vpProgressPlayed"></div>
            </div>
            <div class="vp-time-tooltip" id="vpTimeTooltip">00:00</div>
          </div>

          <span class="vp-time-display" id="vpDuration">02:00</span>
        </div>

        <!-- Row 2: Compact Single-Line Cinema Transport Row -->
        <div class="vp-transport-row">
          <div class="vp-controls-left">
            <button type="button" class="vp-btn" id="btnPrevVideo" title="同目錄上一片 (PageUp / P / ←)">⏮</button>
            <button type="button" class="vp-btn" id="btnSeekBack" title="快退 10 秒">-10s</button>
            <button type="button" class="vp-play-btn" id="btnPlayPause" title="播放 / 暫停 (空白鍵 或 點擊畫面中央)">▶</button>
            <button type="button" class="vp-btn" id="btnSeekForward" title="快轉 10 秒">+10s</button>
            <button type="button" class="vp-btn" id="btnNextVideo" title="同目錄下一片 (PageDown / N / →)">⏭</button>
          </div>

          <div class="vp-controls-right">
            <button type="button" class="vp-btn" id="btnBrightnessReset" title="畫面亮度（左側上下滑動調整，點擊重設 85%）">
              <span>☀️</span>
              <strong id="vpBrightnessPillVal">${t.brightness}%</strong>
            </button>

            <button type="button" class="vp-btn" id="btnMuteToggle" title="音量控制（右側上下滑動調整，點擊靜音 M）">
              <span id="vpVolumePillIcon">${t.muted||t.volume===0?"🔇":"🔊"}</span>
              <strong id="vpVolumePillVal">${t.muted?"靜音":`${t.volume}%`}</strong>
            </button>

            <select class="vp-select" id="selectSpeed" title="播放速度">
              ${ai.map(i=>`<option value="${i}" ${i===t.playbackRate?"selected":""}>${i}x</option>`).join("")}
            </select>

            <button type="button" class="vp-btn" id="btnRotate90" title="順時針旋轉 90° (快捷鍵 R)">
              🔄
            </button>

            <button type="button" class="vp-btn" id="btnFullscreen" title="全螢幕切換 (快捷鍵 F)">
              ⛶
            </button>
          </div>
        </div>
      </footer>

      <!-- Modal: Keyboard & Gesture Shortcuts -->
      <div class="vp-modal-backdrop" id="modalShortcuts">
        <div class="vp-modal">
          <div class="vp-modal-header">
            <div class="vp-modal-title">⌨️ 手勢操作與鍵盤快捷鍵一覽</div>
            <button type="button" class="vp-drawer-close" data-close-modal>×</button>
          </div>
          <div class="vp-modal-body">
            <div class="vp-eq-band" style="border-color: rgba(255, 184, 48, 0.35);">
              <div style="font-weight:700; font-size:0.86rem; color: var(--accent-amber-light);">👆 三區直覺觸控 / 滑鼠拖曳手勢 &amp; 同目錄換片</div>
              <div style="font-size:0.8rem; color: var(--text-secondary); display:grid; gap:4px;">
                <div>• <strong>畫面左側 (0%–35%) 上下滑動</strong>：無段調整畫面亮度 (0%–100%)，自動記憶於 <code>localStorage</code> 與 Android 系統</div>
                <div>• <strong>畫面中央 (35%–65%) 單擊</strong>：立即切換 播放 / 暫停（防垂直滑動誤觸）</div>
                <div>• <strong>畫面右側 (65%–100%) 上下滑動</strong>：無段調整音量大小 (0%–100%)</div>
                <div>• <strong>同目錄按前後鍵換片</strong>：按 <code>PageUp / PageDown</code>、<code>P / N</code>、<code>Shift + ← / →</code>、方向鍵 <code>← / →</code> 或畫面兩側 <code>⏮ / ⏭</code> 按鈕立即切換同資料夾上一部 / 下一部影片</div>
              </div>
            </div>
            <div class="vp-shortcuts-grid">
              ${oi.map(i=>`
                <div class="vp-shortcut-item">
                  <div>
                    <div style="font-weight:600; font-size:0.82rem;">${i.action}</div>
                    <div style="font-size:0.7rem; color:var(--text-muted);">${i.desc}</div>
                  </div>
                  <kbd class="vp-kbd">${i.key}</kbd>
                </div>
              `).join("")}
            </div>
          </div>
        </div>
      </div>

      <!-- Modal: Load Stream / Video URL -->
      <div class="vp-modal-backdrop" id="modalUrl">
        <div class="vp-modal">
          <div class="vp-modal-header">
            <div class="vp-modal-title">🔗 載入影片或串流網址</div>
            <button type="button" class="vp-drawer-close" data-close-modal>×</button>
          </div>
          <div class="vp-modal-body">
            <label style="font-size:0.82rem; color:var(--text-secondary);">請輸入 MP4 / WebM / Ogg 影片直連網址：</label>
            <input type="url" class="vp-input" id="inputStreamUrl" placeholder="https://example.com/video.mp4" />
            <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:6px;">
              <button type="button" class="vp-btn" data-close-modal>取消</button>
              <button type="button" class="vp-btn vp-btn-primary" id="btnConfirmUrl">載入並播放</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Toast Notifications -->
      <div class="vp-toast-container" id="vpToastContainer"></div>
    </div>
  `;const e={app:document.getElementById("vpApp"),stageShell:document.getElementById("vpStageShell"),stage:document.getElementById("vpStage"),rotator:document.getElementById("vpRotator"),video:document.getElementById("vpVideo"),subtitleBox:document.getElementById("vpSubtitleBox"),brightnessVeil:document.getElementById("vpBrightnessVeil"),stageBadgeText:document.getElementById("vpStageBadgeText"),gestureLayer:document.getElementById("vpGestureLayer"),switchToast:document.getElementById("vpSwitchToast"),switchToastBadge:document.getElementById("vpSwitchToastBadge"),switchToastTitle:document.getElementById("vpSwitchToastTitle"),btnEdgePrev:document.getElementById("btnEdgePrev"),btnEdgeNext:document.getElementById("btnEdgeNext"),edgePrevLabel:document.getElementById("edgePrevLabel"),edgePrevFilename:document.getElementById("edgePrevFilename"),edgeNextLabel:document.getElementById("edgeNextLabel"),edgeNextFilename:document.getElementById("edgeNextFilename"),videoTitle:document.getElementById("vpVideoTitle"),aspectBadge:document.getElementById("vpAspectBadge"),dirPill:document.getElementById("vpDirPill"),dirPillVal:document.getElementById("vpDirPillVal"),brightnessPillVal:document.getElementById("vpBrightnessPillVal"),brightnessMemoryTag:document.getElementById("vpBrightnessMemoryTag"),volumePillIcon:document.getElementById("vpVolumePillIcon"),volumePillVal:document.getElementById("vpVolumePillVal"),orientationPillVal:document.getElementById("vpOrientationPillVal"),hwPowerPill:document.getElementById("vpHwPowerPill"),hwPowerPillVal:document.getElementById("vpHwPowerPillVal"),guideBrightnessVal:document.getElementById("vpGuideBrightnessVal"),guideVolumeVal:document.getElementById("vpGuideVolumeVal"),hudBrightness:document.getElementById("vpHudBrightness"),hudBrightnessFill:document.getElementById("vpHudBrightnessFill"),hudBrightnessVal:document.getElementById("vpHudBrightnessVal"),hudVolume:document.getElementById("vpHudVolume"),hudVolumeIcon:document.getElementById("vpHudVolumeIcon"),hudVolumeFill:document.getElementById("vpHudVolumeFill"),hudVolumeVal:document.getElementById("vpHudVolumeVal"),centerRipple:document.getElementById("vpCenterRipple"),centerRippleIcon:document.getElementById("vpCenterRippleIcon"),centerRippleLabel:document.getElementById("vpCenterRippleLabel"),seekIndicator:document.getElementById("vpSeekIndicator"),btnDrawerSettings:document.getElementById("btnDrawerSettings"),btnOpenFile:document.getElementById("btnOpenFile"),btnOpenFolder:document.getElementById("btnOpenFolder"),btnArrowSwitchMode:document.getElementById("btnArrowSwitchMode"),btnAutoRotate:document.getElementById("btnAutoRotate"),btnRotate90:document.getElementById("btnRotate90"),btnSimPortrait:document.getElementById("btnSimPortrait"),btnHwDecode:document.getElementById("btnHwDecode"),btnPowerSave:document.getElementById("btnPowerSave"),btnGestureGuide:document.getElementById("btnGestureGuide"),btnOpenUrl:document.getElementById("btnOpenUrl"),btnOpenSub:document.getElementById("btnOpenSub"),btnScreenshot:document.getElementById("btnScreenshot"),btnDrawerHw:document.getElementById("btnDrawerHw"),btnDrawerEq:document.getElementById("btnDrawerEq"),btnDrawerPlaylist:document.getElementById("btnDrawerPlaylist"),btnModalShortcuts:document.getElementById("btnModalShortcuts"),inputVideoFile:document.getElementById("inputVideoFile"),inputFolderFiles:document.getElementById("inputFolderFiles"),inputSubFile:document.getElementById("inputSubFile"),drawerSettings:document.getElementById("drawerSettings"),drawerPlaylist:document.getElementById("drawerPlaylist"),drawerEq:document.getElementById("drawerEq"),drawerHw:document.getElementById("drawerHw"),btnSettingsOpenOta:document.getElementById("btnSettingsOpenOta"),btnSettingsCheckOta:document.getElementById("btnSettingsCheckOta"),btnSettingsUpgradeApk:document.getElementById("btnSettingsUpgradeApk"),settingsBrightnessVal:document.getElementById("settingsBrightnessVal"),settingsSliderBrightness:document.getElementById("settingsSliderBrightness"),btnSettingsResetBrightness:document.getElementById("btnSettingsResetBrightness"),settingsVolumeVal:document.getElementById("settingsVolumeVal"),settingsSliderVolume:document.getElementById("settingsSliderVolume"),settingsSensitivityGroup:document.getElementById("settingsSensitivityGroup"),btnSettingsArrowMode:document.getElementById("btnSettingsArrowMode"),btnSettingsGestureGuide:document.getElementById("btnSettingsGestureGuide"),btnSettingsRememberResume:document.getElementById("btnSettingsRememberResume"),btnSettingsAutoRotate:document.getElementById("btnSettingsAutoRotate"),settingsRotationGroup:document.getElementById("settingsRotationGroup"),btnSettingsSimPortrait:document.getElementById("btnSettingsSimPortrait"),btnSettingsHwDecode:document.getElementById("btnSettingsHwDecode"),btnSettingsPowerSave:document.getElementById("btnSettingsPowerSave"),btnSettingsFactoryReset:document.getElementById("btnSettingsFactoryReset"),dirBannerName:document.getElementById("vpDirBannerName"),dirBannerCount:document.getElementById("vpDirBannerCount"),dirBannerPath:document.getElementById("vpDirBannerPath"),playlistContainer:document.getElementById("vpPlaylistContainer"),btnDrawerAddFile:document.getElementById("btnDrawerAddFile"),btnDrawerOpenFolder:document.getElementById("btnDrawerOpenFolder"),btnDrawerResetDemo:document.getElementById("btnDrawerResetDemo"),eqPresetsContainer:document.getElementById("vpEqPresetsContainer"),eqBassSlider:document.getElementById("eqBassSlider"),eqMidSlider:document.getElementById("eqMidSlider"),eqTrebleSlider:document.getElementById("eqTrebleSlider"),eqBoostSlider:document.getElementById("eqBoostSlider"),eqBassVal:document.getElementById("eqBassVal"),eqMidVal:document.getElementById("eqMidVal"),eqTrebleVal:document.getElementById("eqTrebleVal"),eqBoostVal:document.getElementById("eqBoostVal"),btnEqReset:document.getElementById("btnEqReset"),btnPanelHwToggle:document.getElementById("btnPanelHwToggle"),btnPanelPowerToggle:document.getElementById("btnPanelPowerToggle"),hwDecodePathVal:document.getElementById("hwDecodePathVal"),hwPowerSaveVal:document.getElementById("hwPowerSaveVal"),hwBatteryVal:document.getElementById("hwBatteryVal"),hwFrameQualityVal:document.getElementById("hwFrameQualityVal"),codecList:document.getElementById("vpCodecList"),dropOverlay:document.getElementById("vpDropOverlay"),currentTime:document.getElementById("vpCurrentTime"),duration:document.getElementById("vpDuration"),progressWrap:document.getElementById("vpProgressWrap"),progressBar:document.getElementById("vpProgressBar"),progressBuffered:document.getElementById("vpProgressBuffered"),progressPlayed:document.getElementById("vpProgressPlayed"),abRange:document.getElementById("vpAbRange"),abMarkerA:document.getElementById("vpAbMarkerA"),abMarkerB:document.getElementById("vpAbMarkerB"),timeTooltip:document.getElementById("vpTimeTooltip"),btnSetPointA:document.getElementById("btnSetPointA"),btnSetPointB:document.getElementById("btnSetPointB"),btnClearAb:document.getElementById("btnClearAb"),btnPlayPause:document.getElementById("btnPlayPause"),btnPrevVideo:document.getElementById("btnPrevVideo"),btnNextVideo:document.getElementById("btnNextVideo"),btnSeekBack:document.getElementById("btnSeekBack"),btnSeekForward:document.getElementById("btnSeekForward"),btnStepBack:document.getElementById("btnStepBack"),btnStepForward:document.getElementById("btnStepForward"),sliderBrightness:document.getElementById("sliderBrightness"),sliderBrightnessVal:document.getElementById("sliderBrightnessVal"),btnBrightnessReset:document.getElementById("btnBrightnessReset"),sliderVolume:document.getElementById("sliderVolume"),sliderVolumeVal:document.getElementById("sliderVolumeVal"),btnMuteToggle:document.getElementById("btnMuteToggle"),selectSpeed:document.getElementById("selectSpeed"),btnLoopMode:document.getElementById("btnLoopMode"),btnSubToggle:document.getElementById("btnSubToggle"),btnPip:document.getElementById("btnPip"),btnFullscreen:document.getElementById("btnFullscreen"),modalShortcuts:document.getElementById("modalShortcuts"),modalUrl:document.getElementById("modalUrl"),inputStreamUrl:document.getElementById("inputStreamUrl"),btnConfirmUrl:document.getElementById("btnConfirmUrl"),toastContainer:document.getElementById("vpToastContainer")};function s(i,l=2200){if(!e.toastContainer)return;const u=document.createElement("div");u.className="vp-toast",u.textContent=i,e.toastContainer.appendChild(u),setTimeout(()=>{u.style.opacity="0",u.style.transition="opacity 0.2s ease",setTimeout(()=>u.remove(),220)},l)}typeof window<"u"&&(window._showOmniPlayToast=s);let c=null;function m(i,l,u=1900){e.switchToast&&(e.switchToastBadge&&(e.switchToastBadge.textContent=i),e.switchToastTitle&&(e.switchToastTitle.textContent=l),e.switchToast.classList.add("is-visible"),c&&clearTimeout(c),c=setTimeout(()=>{e.switchToast.classList.remove("is-visible")},u))}const p=ci({videoEl:e.video,stageEl:e.stage,veilEl:e.brightnessVeil,onStatusChange(i){T(i)}}),h=Di(e.video,{preset:t.eqPreset,...t.eqCustom}),b=Ci({stageEl:e.stage,rotatorEl:e.rotator,videoEl:e.video,autoRotate:t.autoRotate,manualRotation:t.manualRotation,simulateViewport:t.simPortrait?"portrait":"none",onUpdate(i){A(i)}});function A(i){if(!i)return;const l=i.autoRotate?"開啟":"關閉",u=i.effectiveRotation,g=i.isAutoRotated?" (智慧轉向滿版)":"",B=Number(i.scale||1).toFixed(2);if(e.orientationPillVal&&(e.orientationPillVal.textContent=`${l} | 旋轉: ${u}°${g} | Scale: ${B}x 無損最大化`),e.stageBadgeText){const w=p.getTelemetry(),K=w.hwDecodeEnabled?w.mpoZeroCopyActive?"GPU MPO 零拷貝":"GPU 硬體解碼":"軟體解碼";e.stageBadgeText.textContent=`${i.videoWidth}×${i.videoHeight} (${i.videoAspectLabel}) → 視窗適配 ${i.targetWidth}×${i.targetHeight} • 旋轉 ${u}° • Scale ${B}x 無損最大化 • ${K}`}if(e.btnAutoRotate&&e.btnAutoRotate.classList.toggle("is-active",!!i.autoRotate),e.btnSettingsAutoRotate&&(e.btnSettingsAutoRotate.classList.toggle("is-active",!!i.autoRotate),e.btnSettingsAutoRotate.textContent=i.autoRotate?"已開啟":"已關閉"),e.btnSimPortrait&&e.btnSimPortrait.classList.toggle("is-active",i.simulateViewport==="portrait"),e.btnSettingsSimPortrait){const w=i.simulateViewport==="portrait";e.btnSettingsSimPortrait.classList.toggle("is-active",w),e.btnSettingsSimPortrait.textContent=w?"模擬中 (9:16)":"全寬視窗"}e.settingsRotationGroup&&e.settingsRotationGroup.querySelectorAll("[data-rot]").forEach(w=>{w.classList.toggle("is-active",Number(w.getAttribute("data-rot"))===Number(i.manualRotation))})}function T(i){i&&(t.hwDecodeEnabled=i.hwDecodeEnabled,t.powerSaveEnabled=i.powerSaveEnabled,e.hwPowerPillVal&&(e.hwPowerPillVal.textContent=i.topbarBadgeText),e.btnHwDecode&&e.btnHwDecode.classList.toggle("is-active",i.hwDecodeEnabled),e.btnPowerSave&&e.btnPowerSave.classList.toggle("is-active",i.powerSaveEnabled),e.btnPanelHwToggle&&(e.btnPanelHwToggle.classList.toggle("is-active",i.hwDecodeEnabled),e.btnPanelHwToggle.textContent=i.hwDecodeEnabled?"已開啟 (Prefer-HW)":"已關閉 (軟體)"),e.btnSettingsHwDecode&&(e.btnSettingsHwDecode.classList.toggle("is-active",i.hwDecodeEnabled),e.btnSettingsHwDecode.textContent=i.hwDecodeEnabled?"已開啟":"已關閉"),e.btnPanelPowerToggle&&(e.btnPanelPowerToggle.classList.toggle("is-active",i.powerSaveEnabled),e.btnPanelPowerToggle.textContent=i.powerSaveEnabled?"節電開啟 (Eco)":"全速效能"),e.btnSettingsPowerSave&&(e.btnSettingsPowerSave.classList.toggle("is-active",i.powerSaveEnabled),e.btnSettingsPowerSave.textContent=i.powerSaveEnabled?"節電開啟":"全速效能"),e.hwDecodePathVal&&(e.hwDecodePathVal.textContent=i.decodeModeLabel),e.hwPowerSaveVal&&(e.hwPowerSaveVal.textContent=`${i.powerStateLabel} (-${i.estimatedPowerSavingPercent}% 功耗)`),e.hwBatteryVal&&i.battery&&(e.hwBatteryVal.textContent=i.battery.statusLabel),e.hwFrameQualityVal&&(e.hwFrameQualityVal.textContent=`${i.uiTickHz}Hz Tick • 掉幀 ${i.droppedVideoFrames}/${i.totalVideoFrames} (${i.dropRatePercent.toFixed(2)}%)`),e.codecList&&i.codecs&&(e.codecList.innerHTML=Object.values(i.codecs).map(l=>`
          <div style="display:flex; justify-content:space-between; align-items:center; padding:4px 8px; border-radius:6px; background:rgba(255,255,255,0.04);">
            <span>${l.name}</span>
            <span style="font-family:var(--font-mono); color:${l.powerEfficient?"var(--accent-emerald)":"var(--accent-amber-light)"};">
              ${l.supported?l.powerEfficient?"✓ 硬體節電解碼":"✓ 支援解碼":"✗ 未支援"}
            </span>
          </div>
        `).join("")))}function V(i,l={}){var B,w;const u=(l==null?void 0:l.source)||"user",g=Hn(i,u);t.brightness=g;try{(w=(B=window.AndroidPlayerBridge)==null?void 0:B.setScreenBrightness)==null||w.call(B,Number(g))}catch{}return p.applyBrightness(g),e.brightnessPillVal&&(e.brightnessPillVal.textContent=`${g}%`),e.brightnessMemoryTag&&(e.brightnessMemoryTag.textContent=u==="init-restore"&&t.brightnessRestored?"已還原上次設定":"已記憶"),e.sliderBrightness&&Number(e.sliderBrightness.value)!==g&&(e.sliderBrightness.value=String(g)),e.sliderBrightnessVal&&(e.sliderBrightnessVal.textContent=`${g}%`),e.settingsSliderBrightness&&Number(e.settingsSliderBrightness.value)!==g&&(e.settingsSliderBrightness.value=String(g)),e.settingsBrightnessVal&&(e.settingsBrightnessVal.textContent=`${g}%`),e.guideBrightnessVal&&(e.guideBrightnessVal.textContent=`${g}%`),e.hudBrightnessFill&&(e.hudBrightnessFill.style.height=`${g}%`),e.hudBrightnessVal&&(e.hudBrightnessVal.textContent=`${g}%`),g}function L(i,l={}){var K,U;const u=Math.max(0,Math.min(100,Math.round(Number(i)||0)));t.volume=u,u>0&&t.muted&&(l==null?void 0:l.source)!=="init"&&(t.muted=!1);const g=t.muted?0:u;e.video&&(e.video.volume=g/100,e.video.muted=t.muted);try{(U=(K=window.AndroidPlayerBridge)==null?void 0:K.setSystemVolume)==null||U.call(K,Number(g))}catch{}J({volume:t.volume,muted:t.muted});const B=t.muted||g===0?"🔇":g<50?"🔉":"🔊",w=t.muted?"靜音":`${u}%`;return e.volumePillIcon&&(e.volumePillIcon.textContent=B),e.volumePillVal&&(e.volumePillVal.textContent=w),e.btnMuteToggle&&!e.volumePillIcon&&(e.btnMuteToggle.textContent=B),e.sliderVolume&&Number(e.sliderVolume.value)!==g&&(e.sliderVolume.value=String(g)),e.sliderVolumeVal&&(e.sliderVolumeVal.textContent=w),e.settingsSliderVolume&&Number(e.settingsSliderVolume.value)!==g&&(e.settingsSliderVolume.value=String(g)),e.settingsVolumeVal&&(e.settingsVolumeVal.textContent=w),e.guideVolumeVal&&(e.guideVolumeVal.textContent=w),e.hudVolumeIcon&&(e.hudVolumeIcon.textContent=B),e.hudVolumeFill&&(e.hudVolumeFill.style.height=`${g}%`),e.hudVolumeVal&&(e.hudVolumeVal.textContent=w),u}function O(){t.muted=!t.muted,!t.muted&&t.volume===0&&(t.volume=50),L(t.volume,{source:"mute-toggle"}),s(t.muted?"🔇 已靜音":`🔊 音量恢復 ${t.volume}%`,1400)}let C=null;function x(){const i=document.getElementById("ota-modal-backdrop"),l=!!(i&&!i.hasAttribute("hidden"));return!!(t.activeDrawer||t.activeModal||l||t.isScrubbing)}function P(i=3e3){C&&clearTimeout(C),C=setTimeout(()=>{var u;if(x())return;const{paused:l}=y();l||(u=e.app)==null||u.classList.add("controls-hidden")},i)}function $(i=3e3){var l;t.isGestureSwiping||((l=e.app)==null||l.classList.remove("controls-hidden"),P(i))}function y(){var l,u,g;const i=le(e.video);return i?{currentTime:i.getCurrentTime(),duration:i.getDuration(),paused:i.paused}:{currentTime:Number((l=e.video)==null?void 0:l.currentTime)||0,duration:Number.isFinite((u=e.video)==null?void 0:u.duration)?e.video.duration:0,paused:!!((g=e.video)!=null&&g.paused)}}function D(i){const{duration:l}=y(),u=l>0?l:120,g=Math.max(0,Math.min(u,Number(i)||0)),B=le(e.video);return B?B.seek(g):e.video&&(e.video.currentTime=g),W(),g}function S(i){const{currentTime:l}=y();return D(l+i)}function E(i="button"){h.resume();const l=le(e.video);let u=!1;return l?u=l.togglePlay():e.video&&(e.video.paused||e.video.ended?(e.video.play().catch(()=>{}),u=!0):(e.video.pause(),u=!1)),I(u),p.syncWakeLock(),e.centerRippleIcon&&e.centerRippleLabel&&(e.centerRippleIcon.textContent=u?"▶️":"⏸️",e.centerRippleLabel.textContent=u?"播放中":"已暫停"),i!=="center-tap"&&F(),u}let M=null;function F(){e.centerRipple&&(e.centerRipple.classList.add("is-visible"),M&&clearTimeout(M),M=setTimeout(()=>{e.centerRipple.classList.remove("is-visible")},550))}function I(i){var l,u,g;try{(u=(l=window.AndroidPlayerBridge)==null?void 0:l.setKeepScreenOn)==null||u.call(l,!!i)}catch{}i?P(3e3):((g=e.app)==null||g.classList.remove("controls-hidden"),C&&clearTimeout(C)),e.btnPlayPause&&(e.btnPlayPause.textContent=i?"⏸":"▶",e.btnPlayPause.title=i?"暫停 (空白鍵 或 點擊畫面中央)":"播放 (空白鍵 或 點擊畫面中央)")}Ri(e.gestureLayer,{getBrightness:()=>t.brightness,setBrightness:(i,l)=>{V(i,l)},getVolume:()=>t.muted?0:t.volume,setVolume:(i,l)=>{L(i,l)},onTogglePlayPause:i=>{$(3e3),E(i||"center-tap")},onDoubleTapSeek:i=>{S(i)},onGestureHud:(i,l,u)=>{var g,B;if(i==="brightness"&&e.hudBrightness)t.isGestureSwiping=!!l,l&&((g=e.app)==null||g.classList.add("controls-hidden")),e.hudBrightness.classList.toggle("is-active",!!l);else if(i==="volume"&&e.hudVolume)t.isGestureSwiping=!!l,l&&((B=e.app)==null||B.classList.add("controls-hidden")),e.hudVolume.classList.toggle("is-active",!!l);else if(i==="play-pause"&&e.centerRipple)e.centerRipple.classList.toggle("is-visible",!!l);else if(i==="seek"&&e.seekIndicator){if(l){const w=Number(u)>0?`+${u}s ⏩`:`⏪ ${u}s`;e.seekIndicator.textContent=w}e.seekIndicator.classList.toggle("is-visible",!!l)}}});function G(){const i=Math.max(1,t.playlist.length),l=Math.max(0,Math.min(i-1,t.currentIndex)),u=(l-1+i)%i,g=(l+1)%i,B=t.playlist[u],w=t.playlist[g];e.dirPillVal&&(e.dirPillVal.textContent=`${l+1}/${i} (${t.directoryName})`),e.dirBannerName&&(e.dirBannerName.textContent=t.directoryName),e.dirBannerCount&&(e.dirBannerCount.textContent=`${l+1} / ${i} 部`),e.dirBannerPath&&(e.dirBannerPath.textContent=t.directoryPath||t.directoryName),e.edgePrevLabel&&B&&(e.edgePrevLabel.textContent=`⏮ 同目錄上一片 (${u+1}/${i})`),e.edgePrevFilename&&B&&(e.edgePrevFilename.textContent=B.title),e.edgeNextLabel&&w&&(e.edgeNextLabel.textContent=`同目錄下一片 (${g+1}/${i}) ⏭`),e.edgeNextFilename&&w&&(e.edgeNextFilename.textContent=w.title),e.btnPrevVideo&&B&&(e.btnPrevVideo.title=`⏮ 同目錄上一片 (${u+1}/${i})：${B.title} [快捷鍵: PageUp / P / Shift+← / ←]`),e.btnNextVideo&&w&&(e.btnNextVideo.title=`⏭ 同目錄下一片 (${g+1}/${i})：${w.title} [快捷鍵: PageDown / N / Shift+→ / →]`)}function H(i=1,l="button"){const u=t.playlist.length;if(u===0)return;const g=(t.currentIndex+i+u)%u,B=i<0?"prev":"next";j(g,!0,{switchDirection:B})}function z(i){if(i!=null&&i.pairedSubtitleFile){const l=new FileReader;l.onload=()=>{const u=Vn(String(l.result||""));u.length>0&&(t.customSubtitles=u,t.customSubtitleName=i.pairedSubtitleFile.name,W())},l.readAsText(i.pairedSubtitleFile,"utf-8")}else i!=null&&i.isDemo&&(t.customSubtitles=null,t.customSubtitleName="")}function j(i,l=!0,u={}){var X;if(i<0||i>=t.playlist.length)return;const g=t.playlist[t.currentIndex],B=y();t.rememberResumePosition&&g&&B.currentTime>1&&Ln(g.id,B.currentTime,B.duration),t.currentIndex=i;const w=t.playlist[i];J({lastVideoId:w.id}),w.directoryName&&(t.directoryName=w.directoryName),w.directoryPath&&(t.directoryPath=w.directoryPath),v(),V(ze(),{source:"video-switch"}),z(w);const K=t.playlist.length,U=`${i+1}/${K}`;if(e.videoTitle&&(e.videoTitle.textContent=w.title),e.aspectBadge&&(e.aspectBadge.textContent=w.aspectLabel||U),u.switchDirection){const q=u.switchDirection==="prev"?"⏮ 上一片":"⏭ 下一片";m(`${q} (${i+1}/${K})`,`${t.directoryName} • ${w.title}`)}if(w.isDemo){b.setIntrinsicSize(w.width,w.height);const q=wi(e.video,w,{autoPlay:l,onLoadedMetadata:({width:ae,height:pe})=>{b.setIntrinsicSize(ae,pe),b.recalculate()},onTimeUpdate:()=>{W()},onPlayChange:ae=>{I(ae)},onEnded:()=>{Q()}});if(q){q.setPlaybackRate(t.playbackRate),(X=q.setPowerSaveMode)==null||X.call(q,t.powerSaveEnabled);const ae=h.getState();q.setEqGains(ae)}I(l)}else{On(e.video),b.setIntrinsicSize(0,0),e.video.src=w.url,e.video.playbackRate=t.playbackRate,e.video.volume=t.muted?0:t.volume/100,e.video.muted=t.muted,e.video.load();const q=t.rememberResumePosition?xi(w.id):0,ae=()=>{e.video.removeEventListener("loadedmetadata",ae);const pe=e.video.videoWidth||1280,De=e.video.videoHeight||720;w.width=pe,w.height=De,b.recalculate();const jn=b.getState();w.aspectLabel=`${jn.videoAspectLabel} • ${i+1}/${t.playlist.length}`,e.aspectBadge&&(e.aspectBadge.textContent=w.aspectLabel),se(),q>2&&q<(e.video.duration||0)-3&&(e.video.currentTime=q,s(`⏱️ 已從上次進度 ${ge(q)} 接續播放`,1600)),h.syncSource(),l&&e.video.play().catch(()=>{})};e.video.addEventListener("loadedmetadata",ae)}G(),se(),W()}function Q(){if(t.loopMode==="one"){D(0);const i=le(e.video);i?i.play():e.video.play().catch(()=>{})}else t.loopMode==="all"?H(1,"auto-next"):I(!1)}function se(){if(!e.playlistContainer)return;const i=t.playlist.length;e.playlistContainer.innerHTML=t.playlist.map((l,u)=>{const g=u===t.currentIndex;return`
          <div class="vp-playlist-item ${g?"is-active":""}" data-playlist-idx="${u}">
            <span class="vp-playlist-index">${u+1}</span>
            <div class="vp-playlist-meta">
              <div class="vp-playlist-title">${g?"▶ ":""}${l.title}</div>
              <div class="vp-playlist-sub">${l.subtitle||`${l.width||1280}×${l.height||720}`}</div>
            </div>
            <span class="vp-badge">${l.aspectLabel||`${u+1}/${i}`}</span>
          </div>
        `}).join(""),e.playlistContainer.querySelectorAll("[data-playlist-idx]").forEach(l=>{l.addEventListener("click",()=>{const u=Number(l.getAttribute("data-playlist-idx"));j(u,!0,{switchDirection:u<t.currentIndex?"prev":"next"})})})}function te(){const i=h.getState();e.eqPresetsContainer&&(e.eqPresetsContainer.innerHTML=Bn.map(l=>`
          <button type="button" class="vp-eq-preset-btn ${i.preset===l.id?"is-active":""}" data-eq-preset="${l.id}">
            ${l.name}
          </button>
        `).join(""),e.eqPresetsContainer.querySelectorAll("[data-eq-preset]").forEach(l=>{l.addEventListener("click",()=>{var B;const u=l.getAttribute("data-eq-preset"),g=Bn.find(w=>w.id===u);if(g){const w=h.setPreset(g);(B=le(e.video))==null||B.setEqGains(w),J({eqPreset:g.id,eqCustom:{bass:w.bass,mid:w.mid,treble:w.treble,boost:w.boost}}),te(),s(`🎚️ 已套用音效預設：${g.name}`,1500)}})})),e.eqBassSlider&&(e.eqBassSlider.value=String(i.bass)),e.eqMidSlider&&(e.eqMidSlider.value=String(i.mid)),e.eqTrebleSlider&&(e.eqTrebleSlider.value=String(i.treble)),e.eqBoostSlider&&(e.eqBoostSlider.value=String(i.boost)),e.eqBassVal&&(e.eqBassVal.textContent=`${i.bass>0?"+":""}${i.bass} dB`),e.eqMidVal&&(e.eqMidVal.textContent=`${i.mid>0?"+":""}${i.mid} dB`),e.eqTrebleVal&&(e.eqTrebleVal.textContent=`${i.treble>0?"+":""}${i.treble} dB`),e.eqBoostVal&&(e.eqBoostVal.textContent=`${Number(i.boost).toFixed(2)}x`)}function W(){var B,w;const{currentTime:i,duration:l}=y(),u=l>0?l:120;if(t.abLoop.a!==null&&t.abLoop.b!==null&&t.abLoop.b>t.abLoop.a+.2&&i>=t.abLoop.b){D(t.abLoop.a);return}const g=Math.max(0,Math.min(100,i/u*100));if(e.progressPlayed&&(e.progressPlayed.style.width=`${g.toFixed(2)}%`),e.currentTime&&(e.currentTime.textContent=ge(i)),e.duration&&(e.duration.textContent=ge(u)),e.progressBuffered){if(Ae(e.video))e.progressBuffered.style.width="100%";else if(((w=(B=e.video)==null?void 0:B.buffered)==null?void 0:w.length)>0){const K=e.video.buffered.end(e.video.buffered.length-1),U=Math.min(100,K/u*100);e.progressBuffered.style.width=`${U.toFixed(1)}%`}}Y(i)}function Y(i){if(!e.subtitleBox)return;if(!t.subtitlesEnabled){e.subtitleBox.innerHTML="";return}const l=t.customSubtitles&&t.customSubtitles.length>0?t.customSubtitles:Ae(e.video)?ri:[];if(l.length===0){e.subtitleBox.innerHTML="";return}const u=t.customSubtitles&&t.customSubtitles.length>0?i:i%30,g=l.find(B=>u>=B.start&&u<=B.end);g?e.subtitleBox.innerHTML=`<span class="vp-subtitle-text">${g.text}</span>`:e.subtitleBox.innerHTML=""}function R(){var B,w,K,U;const{duration:i}=y(),l=i>0?i:120,{a:u,b:g}=t.abLoop;if(u!==null&&e.abMarkerA?(e.abMarkerA.style.display="block",e.abMarkerA.style.left=`${Math.min(100,u/l*100)}%`,(B=e.btnSetPointA)==null||B.classList.add("is-active")):e.abMarkerA&&(e.abMarkerA.style.display="none",(w=e.btnSetPointA)==null||w.classList.remove("is-active")),g!==null&&e.abMarkerB?(e.abMarkerB.style.display="block",e.abMarkerB.style.left=`${Math.min(100,g/l*100)}%`,(K=e.btnSetPointB)==null||K.classList.add("is-active")):e.abMarkerB&&(e.abMarkerB.style.display="none",(U=e.btnSetPointB)==null||U.classList.remove("is-active")),u!==null&&g!==null&&g>u&&e.abRange){const X=Math.min(100,u/l*100),q=Math.min(100-X,(g-u)/l*100);e.abRange.style.display="block",e.abRange.style.left=`${X}%`,e.abRange.style.width=`${q}%`}else e.abRange&&(e.abRange.style.display="none");e.btnClearAb&&(e.btnClearAb.style.display=u!==null||g!==null?"inline-flex":"none")}function v(){t.abLoop.a=null,t.abLoop.b=null,R()}function k(i){var l,u,g,B,w,K,U,X;t.activeDrawer=t.activeDrawer===i?null:i,(l=e.drawerSettings)==null||l.classList.toggle("is-open",t.activeDrawer==="settings"),(u=e.drawerPlaylist)==null||u.classList.toggle("is-open",t.activeDrawer==="playlist"),(g=e.drawerEq)==null||g.classList.toggle("is-open",t.activeDrawer==="eq"),(B=e.drawerHw)==null||B.classList.toggle("is-open",t.activeDrawer==="hw"),(w=e.btnDrawerSettings)==null||w.classList.toggle("is-active",t.activeDrawer==="settings"),(K=e.btnDrawerPlaylist)==null||K.classList.toggle("is-active",t.activeDrawer==="playlist"),(U=e.btnDrawerEq)==null||U.classList.toggle("is-active",t.activeDrawer==="eq"),(X=e.btnDrawerHw)==null||X.classList.toggle("is-active",t.activeDrawer==="hw"),$(3e3)}function Z(i){var l,u;t.activeModal=i,(l=e.modalShortcuts)==null||l.classList.toggle("is-open",i==="shortcuts"),(u=e.modalUrl)==null||u.classList.toggle("is-open",i==="url"),i==="url"&&setTimeout(()=>{var g;return(g=e.inputStreamUrl)==null?void 0:g.focus()},60),$(3e3)}function ne(){var i,l;t.activeModal=null,(i=e.modalShortcuts)==null||i.classList.remove("is-open"),(l=e.modalUrl)==null||l.classList.remove("is-open"),$(3e3)}async function ie(i,l=""){var K;if(!i||i.length===0)return;const u=Array.from(i),g=u.filter(U=>{var X;return U&&(((X=U.type)==null?void 0:X.startsWith("video/"))||Ke(U.name))}),B=u.filter(U=>U&&je(U.name));if(g.length===0&&B.length>0){const U=B[0],X=new FileReader;X.onload=()=>{var ae;const q=Vn(String(X.result||""));q.length>0&&(t.customSubtitles=q,t.customSubtitleName=U.name,t.subtitlesEnabled=!0,(ae=e.btnSubToggle)==null||ae.classList.add("is-active"),s(`💬 已載入字幕：${U.name} (${q.length} 句)`),W())},X.readAsText(U,"utf-8");return}if(g.length===0)return;const w=Wn(u,g[0].name,l);if(t.playlist=w.items,t.directoryName=w.directoryName,t.directoryPath=l?`${w.directoryName} (共 ${w.total} 部同目錄影片)`:`本機選取檔案 (${w.total} 部)`,j(w.currentIndex,!0),g.length===1){const U=g[0],X=(K=t.playlist[0])==null?void 0:K.url,q=await _i(U,t.lastDirectoryPath);if(q.found&&q.items.length>0){const ae=q.items.map((pe,De)=>De===q.currentIndex&&X?{...pe,url:X,file:U}:pe);if(t.playlist=ae,t.currentIndex=q.currentIndex,t.directoryName=q.directoryName,t.directoryPath=q.directoryPath,J({lastDirectoryPath:q.directoryPath}),e.aspectBadge){const pe=b.getState();e.aspectBadge.textContent=`${pe.videoAspectLabel} • ${t.currentIndex+1}/${ae.length}`}G(),se(),m(`📁 同目錄連播 (${t.currentIndex+1}/${ae.length})`,`已載入「${q.directoryName}」共 ${ae.length} 部影片，可按 ⏮/⏭ 前後鍵換片`)}else s(`📂 已開始播放：${U.title||U.name}`)}else m(`📁 同目錄連播 (1/${w.total})`,`已載入「${w.directoryName}」共 ${w.total} 部影片，可按 ⏮/⏭ 前後鍵換片`)}async function N(){var l;const i=await Hi();if(i.supported){!i.cancelled&&i.items&&i.items.length>0?(t.playlist=i.items,t.directoryName=i.directoryName,t.directoryPath=`${i.directoryName} (同目錄共 ${i.total} 部影片)`,j(i.currentIndex,!0),m(`📁 同目錄連播 (1/${i.total})`,`已載入資料夾「${i.directoryName}」共 ${i.total} 部影片`)):i.cancelled||s("⚠️ 該資料夾內未找到支援的影片檔");return}(l=e.inputFolderFiles)==null||l.click()}function ee(){try{const i=le(e.video);let l="";if(i)l=i.captureFrameDataUrl("image/png");else if(e.video&&e.video.videoWidth>0){const g=document.createElement("canvas");g.width=e.video.videoWidth,g.height=e.video.videoHeight,g.getContext("2d").drawImage(e.video,0,0,g.width,g.height),l=g.toDataURL("image/png")}if(!l){s("⚠️ 目前尚無可擷取的視訊畫面");return}const u=document.createElement("a");u.href=l,u.download=`OmniPlay_Frame_${Date.now()}.png`,document.body.appendChild(u),u.click(),u.remove(),s("📸 已擷取無損畫面並下載 PNG")}catch{s("⚠️ 截圖失敗（跨網域視訊受 CORS 保護）")}}(et=e.dirPill)==null||et.addEventListener("click",()=>k("playlist")),(tt=e.btnDrawerSettings)==null||tt.addEventListener("click",()=>k("settings"));const de=()=>{var i;t.arrowKeySwitchMode=!t.arrowKeySwitchMode,(i=e.btnArrowSwitchMode)==null||i.classList.toggle("is-active",t.arrowKeySwitchMode),e.btnSettingsArrowMode&&(e.btnSettingsArrowMode.classList.toggle("is-active",t.arrowKeySwitchMode),e.btnSettingsArrowMode.textContent=t.arrowKeySwitchMode?"同目錄換片":"快轉 ±5秒"),J({arrowKeySwitchMode:t.arrowKeySwitchMode}),s(t.arrowKeySwitchMode?fe==null?void 0:fe.arrowKeySwitchOnTip:fe==null?void 0:fe.arrowKeySwitchOffTip,2400)};(nt=e.btnArrowSwitchMode)==null||nt.addEventListener("click",de),(it=e.btnSettingsArrowMode)==null||it.addEventListener("click",de);const ye=()=>{const i=b.toggleAutoRotate();t.autoRotate=i.autoRotate,J({autoRotate:t.autoRotate}),s(t.autoRotate?"🔄 自動轉向無損最大化：已開啟 (Scale 1.00x)":"🔄 自動轉向：已關閉（維持手動角度）")};(ot=e.btnAutoRotate)==null||ot.addEventListener("click",ye),(at=e.btnSettingsAutoRotate)==null||at.addEventListener("click",ye),(rt=e.btnRotate90)==null||rt.addEventListener("click",()=>{const i=b.rotateBy(90);t.manualRotation=i.manualRotation,J({manualRotation:t.manualRotation}),s(`↪️ 旋轉角度：${i.effectiveRotation}° (Scale 1.00x 無損最大化)`,1500)}),e.settingsRotationGroup&&e.settingsRotationGroup.querySelectorAll("[data-rot]").forEach(i=>{i.addEventListener("click",()=>{const l=Number(i.getAttribute("data-rot"))||0,u=b.setManualRotation(l);t.manualRotation=u.manualRotation,J({manualRotation:t.manualRotation}),s(`↪️ 已設定基準角度：${l}°`)})});const me=()=>{t.simPortrait=!t.simPortrait,J({simPortrait:t.simPortrait});const i=t.simPortrait?"portrait":"none",l=b.setSimulateViewport(i);s(t.simPortrait?`📱 已切換至 9:16 直向手機框（自動旋轉: ${l.effectiveRotation}°）`:"🖥️ 已恢復 100% 滿版寬螢幕視窗")};(st=e.btnSimPortrait)==null||st.addEventListener("click",me),(lt=e.btnSettingsSimPortrait)==null||lt.addEventListener("click",me);const ue=()=>{const i=p.toggleHwDecode();J({hwDecodeEnabled:i}),b.recalculate(),s(i?"⚡ GPU 硬體解碼已開啟 (Zero-Copy MPO 優先)":"🖥️ 已切換為軟體解碼模式")};(dt=e.btnHwDecode)==null||dt.addEventListener("click",ue),(ct=e.btnPanelHwToggle)==null||ct.addEventListener("click",ue),(ut=e.btnSettingsHwDecode)==null||ut.addEventListener("click",ue);const Pe=()=>{var l,u;const i=p.togglePowerSave();(u=(l=le(e.video))==null?void 0:l.setPowerSaveMode)==null||u.call(l,i),J({powerSaveEnabled:i}),s(i?"🍃 智慧節省電力模式已開啟 (4Hz UI Tick • CPU 深度節電)":"🔥 已切換為全速效能模式 (60Hz)")};(pt=e.btnPowerSave)==null||pt.addEventListener("click",Pe),(mt=e.btnPanelPowerToggle)==null||mt.addEventListener("click",Pe),(gt=e.btnSettingsPowerSave)==null||gt.addEventListener("click",Pe),(vt=e.hwPowerPill)==null||vt.addEventListener("click",()=>k("hw")),(ft=e.btnDrawerHw)==null||ft.addEventListener("click",()=>k("hw")),(bt=e.btnDrawerEq)==null||bt.addEventListener("click",()=>k("eq")),(ht=e.btnDrawerPlaylist)==null||ht.addEventListener("click",()=>k("playlist")),document.querySelectorAll("[data-close-drawer]").forEach(i=>{i.addEventListener("click",()=>k(null))});const Ze=()=>{var i,l;t.showGestureGuide=!t.showGestureGuide,(i=e.gestureLayer)==null||i.classList.toggle("show-guide",t.showGestureGuide),(l=e.btnGestureGuide)==null||l.classList.toggle("is-active",t.showGestureGuide),e.btnSettingsGestureGuide&&(e.btnSettingsGestureGuide.classList.toggle("is-active",t.showGestureGuide),e.btnSettingsGestureGuide.textContent=t.showGestureGuide?"已開啟":"已隱藏"),J({showGestureGuide:t.showGestureGuide})};(yt=e.btnGestureGuide)==null||yt.addEventListener("click",Ze),(wt=e.btnSettingsGestureGuide)==null||wt.addEventListener("click",Ze),(St=e.btnSettingsOpenOta)==null||St.addEventListener("click",()=>Re()),(Et=e.btnSettingsCheckOta)==null||Et.addEventListener("click",()=>Ee(!1)),(Pt=e.btnSettingsUpgradeApk)==null||Pt.addEventListener("click",()=>{Re(),We()}),(Bt=e.settingsSliderBrightness)==null||Bt.addEventListener("input",i=>{V(Number(i.target.value),{source:"settings-slider"})}),(Tt=e.btnSettingsResetBrightness)==null||Tt.addEventListener("click",()=>{V(85,{source:"settings-reset"}),s("☀️ 亮度已重設為標準 85%（並已記憶）",1400)}),(It=e.settingsSliderVolume)==null||It.addEventListener("input",i=>{L(Number(i.target.value),{source:"settings-slider"})}),e.settingsSensitivityGroup&&e.settingsSensitivityGroup.querySelectorAll("[data-sens]").forEach(i=>{i.addEventListener("click",()=>{const l=Number(i.getAttribute("data-sens"))||1.2;t.gestureSensitivity=l,J({gestureSensitivity:l}),e.settingsSensitivityGroup.querySelectorAll("[data-sens]").forEach(u=>{u.classList.toggle("is-active",Number(u.getAttribute("data-sens"))===l)}),s(`👆 手勢垂直滑動靈敏度已設為 ${l}x`)})}),(At=e.btnSettingsRememberResume)==null||At.addEventListener("click",()=>{t.rememberResumePosition=!t.rememberResumePosition,e.btnSettingsRememberResume.classList.toggle("is-active",t.rememberResumePosition),e.btnSettingsRememberResume.textContent=t.rememberResumePosition?"已開啟":"已關閉",J({rememberResumePosition:t.rememberResumePosition}),s(t.rememberResumePosition?"⏱️ 自動記憶播放進度：已開啟":"⏱️ 自動記憶播放進度：已關閉")}),(Mt=e.btnSettingsFactoryReset)==null||Mt.addEventListener("click",()=>{var l,u,g;const i=ki();V(i.brightness,{source:"factory-reset"}),L(i.volume,{source:"factory-reset"}),t.autoRotate=i.autoRotate,t.manualRotation=i.manualRotation,t.simPortrait=i.simPortrait,t.arrowKeySwitchMode=i.arrowKeySwitchMode,t.showGestureGuide=i.showGestureGuide,t.rememberResumePosition=i.rememberResumePosition,b.setAutoRotate(t.autoRotate),b.setManualRotation(t.manualRotation),b.setSimulateViewport(t.simPortrait?"portrait":"none"),p.setHwDecodeEnabled(i.hwDecodeEnabled),p.setPowerSaveEnabled(i.powerSaveEnabled),(l=e.gestureLayer)==null||l.classList.toggle("show-guide",t.showGestureGuide),(u=e.btnGestureGuide)==null||u.classList.toggle("is-active",t.showGestureGuide),(g=e.btnArrowSwitchMode)==null||g.classList.toggle("is-active",t.arrowKeySwitchMode),e.btnSettingsArrowMode&&(e.btnSettingsArrowMode.classList.toggle("is-active",t.arrowKeySwitchMode),e.btnSettingsArrowMode.textContent="同目錄換片"),h.reset(),te(),s("✅ 已恢復所有出廠預設設定（亮度 85% / 硬體解碼開啟 / 節電開啟）")}),(Rt=e.btnOpenFile)==null||Rt.addEventListener("click",()=>{var i;return(i=e.inputVideoFile)==null?void 0:i.click()}),(Lt=e.btnDrawerAddFile)==null||Lt.addEventListener("click",()=>{var i;return(i=e.inputVideoFile)==null?void 0:i.click()}),(Ct=e.inputVideoFile)==null||Ct.addEventListener("change",i=>{ie(i.target.files),i.target.value=""}),(Vt=e.btnOpenFolder)==null||Vt.addEventListener("click",N),(kt=e.btnDrawerOpenFolder)==null||kt.addEventListener("click",N),(xt=e.inputFolderFiles)==null||xt.addEventListener("change",i=>{ie(i.target.files),i.target.value=""}),(Dt=e.btnDrawerResetDemo)==null||Dt.addEventListener("click",()=>{t.playlist=[...Pn],t.directoryName="內建比例測試目錄",t.directoryPath="內建 4 組多比例幾何測試串流 (16:9 / 9:16 / 21:9 / 4:3)",j(0,!0),s("🎞️ 已切換回內建 4 組多比例測試串流")}),($t=e.btnOpenSub)==null||$t.addEventListener("click",()=>{var i;return(i=e.inputSubFile)==null?void 0:i.click()}),(Nt=e.inputSubFile)==null||Nt.addEventListener("change",i=>{ie(i.target.files),i.target.value=""}),(Ot=e.btnOpenUrl)==null||Ot.addEventListener("click",()=>Z("url")),(Ft=e.btnModalShortcuts)==null||Ft.addEventListener("click",()=>Z("shortcuts")),document.querySelectorAll("[data-close-modal]").forEach(i=>{i.addEventListener("click",ne)}),(_t=e.btnConfirmUrl)==null||_t.addEventListener("click",()=>{var u,g;const i=(g=(u=e.inputStreamUrl)==null?void 0:u.value)==null?void 0:g.trim();if(!i)return;const l={id:`url-${Date.now()}`,title:i.split("/").pop()||"遠端串流影片",subtitle:i,url:i,aspectLabel:"Stream",isDemo:!1};t.playlist.push(l),ne(),j(t.playlist.length-1,!0),s("🔗 已載入遠端串流網址")}),(Ht=e.btnScreenshot)==null||Ht.addEventListener("click",ee);const Be=()=>{var w,K,U,X,q;const i=Number(((w=e.eqBassSlider)==null?void 0:w.value)||0),l=Number(((K=e.eqMidSlider)==null?void 0:K.value)||0),u=Number(((U=e.eqTrebleSlider)==null?void 0:U.value)||0),g=Number(((X=e.eqBoostSlider)==null?void 0:X.value)||1),B=h.setValues({preset:"custom",bass:i,mid:l,treble:u,boost:g});(q=le(e.video))==null||q.setEqGains(B),J({eqPreset:"custom",eqCustom:{bass:B.bass,mid:B.mid,treble:B.treble,boost:B.boost}}),te()};(qt=e.eqBassSlider)==null||qt.addEventListener("input",Be),(Gt=e.eqMidSlider)==null||Gt.addEventListener("input",Be),(Ut=e.eqTrebleSlider)==null||Ut.addEventListener("input",Be),(zt=e.eqBoostSlider)==null||zt.addEventListener("input",Be),(Wt=e.btnEqReset)==null||Wt.addEventListener("click",()=>{var l;const i=h.reset();(l=le(e.video))==null||l.setEqGains(i),J({eqPreset:"flat",eqCustom:{bass:0,mid:0,treble:0,boost:1}}),te(),s("🎚️ 已重設為原音直通 (Flat)")}),(Kt=e.btnPlayPause)==null||Kt.addEventListener("click",()=>E("control-bar")),(jt=e.btnPrevVideo)==null||jt.addEventListener("click",()=>H(-1,"control-prev")),(Zt=e.btnNextVideo)==null||Zt.addEventListener("click",()=>H(1,"control-next")),(Xt=e.btnEdgePrev)==null||Xt.addEventListener("click",i=>{i.stopPropagation(),H(-1,"edge-prev")}),(Qt=e.btnEdgeNext)==null||Qt.addEventListener("click",i=>{i.stopPropagation(),H(1,"edge-next")}),(Yt=e.btnSeekBack)==null||Yt.addEventListener("click",()=>S(-10)),(Jt=e.btnSeekForward)==null||Jt.addEventListener("click",()=>S(10)),(en=e.btnStepBack)==null||en.addEventListener("click",()=>{const i=le(e.video);i?(i.pause(),i.stepFrame(-1)):e.video&&(e.video.pause(),S(-1/60)),I(!1)}),(tn=e.btnStepForward)==null||tn.addEventListener("click",()=>{const i=le(e.video);i?(i.pause(),i.stepFrame(1)):e.video&&(e.video.pause(),S(1/60)),I(!1)}),(nn=e.sliderBrightness)==null||nn.addEventListener("input",i=>{V(Number(i.target.value),{source:"slider"})}),(on=e.btnBrightnessReset)==null||on.addEventListener("click",()=>{V(85,{source:"reset"}),s("☀️ 亮度已重設為標準 85%（並已記憶）",1400)}),(an=e.sliderVolume)==null||an.addEventListener("input",i=>{L(Number(i.target.value),{source:"slider"})}),(rn=e.btnMuteToggle)==null||rn.addEventListener("click",O),(sn=e.selectSpeed)==null||sn.addEventListener("change",i=>{var u;const l=Number(i.target.value)||1;t.playbackRate=l,e.video&&(e.video.playbackRate=l),(u=le(e.video))==null||u.setPlaybackRate(l),J({playbackRate:l}),s(`⏩ 播放速度：${l}x`,1300)});const Xe=()=>{if(!e.btnLoopMode)return;const i={all:"🔁 循環: 全部",one:"🔂 循環: 單曲",off:"➡️ 循環: 關閉"};e.btnLoopMode.textContent=i[t.loopMode]||i.all};Xe(),(ln=e.btnLoopMode)==null||ln.addEventListener("click",()=>{const i=["all","one","off"],l=(i.indexOf(t.loopMode)+1)%i.length;t.loopMode=i[l],J({loopMode:t.loopMode}),Xe()}),(dn=e.btnSubToggle)==null||dn.addEventListener("click",()=>{t.subtitlesEnabled=!t.subtitlesEnabled,e.btnSubToggle.classList.toggle("is-active",t.subtitlesEnabled),W(),s(t.subtitlesEnabled?"💬 字幕顯示：已開啟":"💬 字幕顯示：已隱藏",1300)}),(cn=e.btnPip)==null||cn.addEventListener("click",async()=>{var i;try{document.pictureInPictureElement?await document.exitPictureInPicture():(i=e.video)!=null&&i.requestPictureInPicture?await e.video.requestPictureInPicture():s("⚠️ 瀏覽器不支援子母畫面")}catch{s("⚠️ 無法進入子母畫面模式")}});const Qe=async()=>{var i,l,u,g,B;try{document.fullscreenElement?await((B=document.exitFullscreen)==null?void 0:B.call(document)):await(((l=(i=e.app)==null?void 0:i.requestFullscreen)==null?void 0:l.call(i))||((g=(u=document.documentElement).requestFullscreen)==null?void 0:g.call(u)))}catch{}};if((un=e.btnFullscreen)==null||un.addEventListener("click",Qe),(pn=e.btnSetPointA)==null||pn.addEventListener("click",()=>{const{currentTime:i}=y();t.abLoop.a=i,t.abLoop.b!==null&&t.abLoop.b<=t.abLoop.a&&(t.abLoop.b=null),R(),s(`🅰️ 已設定 A 點起點：${ge(i)}`,1400)}),(mn=e.btnSetPointB)==null||mn.addEventListener("click",()=>{const{currentTime:i}=y();t.abLoop.a===null&&(t.abLoop.a=0),i>t.abLoop.a+.3?(t.abLoop.b=i,R(),s(`🅱️ 已啟動 A-B 區間循環：${ge(t.abLoop.a)} → ${ge(t.abLoop.b)}`,1600)):s("⚠️ B 點必須大於 A 點時間",1400)}),(gn=e.btnClearAb)==null||gn.addEventListener("click",()=>{v(),s("已清除 A-B 區間循環",1300)}),e.progressWrap){const i=u=>{const g=e.progressWrap.getBoundingClientRect(),B=Math.max(0,Math.min(1,(u-g.left)/Math.max(1,g.width))),{duration:w}=y(),K=w>0?w:120;return{ratio:B,targetSec:B*K}};e.progressWrap.addEventListener("pointermove",u=>{const{ratio:g,targetSec:B}=i(u.clientX);e.timeTooltip&&(e.timeTooltip.style.left=`${(g*100).toFixed(1)}%`,e.timeTooltip.textContent=ge(B)),t.isScrubbing&&D(B)}),e.progressWrap.addEventListener("pointerdown",u=>{var B,w;t.isScrubbing=!0,(w=(B=e.progressWrap).setPointerCapture)==null||w.call(B,u.pointerId);const{targetSec:g}=i(u.clientX);D(g)});const l=u=>{var g,B;if(t.isScrubbing){t.isScrubbing=!1;try{(B=(g=e.progressWrap).releasePointerCapture)==null||B.call(g,u.pointerId)}catch{}}};e.progressWrap.addEventListener("pointerup",l),e.progressWrap.addEventListener("pointercancel",l)}(vn=e.video)==null||vn.addEventListener("timeupdate",()=>{Ae(e.video)||W()}),(fn=e.video)==null||fn.addEventListener("play",()=>I(!0)),(bn=e.video)==null||bn.addEventListener("pause",()=>I(!1)),(hn=e.video)==null||hn.addEventListener("ended",()=>{Ae(e.video)||Q()}),window.addEventListener("dragover",i=>{var l;i.preventDefault(),(l=e.dropOverlay)==null||l.classList.add("is-active")}),window.addEventListener("dragleave",i=>{var l;i.relatedTarget||(l=e.dropOverlay)==null||l.classList.remove("is-active")}),window.addEventListener("drop",async i=>{var l;if(i.preventDefault(),(l=e.dropOverlay)==null||l.classList.remove("is-active"),i.dataTransfer){const u=await qi(i.dataTransfer);u.files.length>0&&ie(u.files,u.folderName)}}),(yn=e.app)==null||yn.addEventListener("pointermove",()=>{t.isGestureSwiping||$(3e3)},{passive:!0}),(wn=e.app)==null||wn.addEventListener("touchstart",()=>{t.isGestureSwiping||$(3e3)},{passive:!0}),window.addEventListener("storage",i=>{i.key==="vp_brightness"&&i.newValue!==null&&V(Number(i.newValue),{source:"storage-sync"})}),window.addEventListener("keydown",i=>{var l,u,g,B,w;if(i.target&&(i.target.tagName==="INPUT"||i.target.tagName==="TEXTAREA"||i.target.tagName==="SELECT")){i.key==="Escape"&&ne();return}switch(i.key){case" ":case"k":case"K":i.preventDefault(),E("keyboard");break;case"PageUp":case"p":case"P":case"MediaTrackPrevious":i.preventDefault(),H(-1,"keyboard-prev");break;case"PageDown":case"n":case"N":case"MediaTrackNext":i.preventDefault(),H(1,"keyboard-next");break;case"ArrowLeft":i.preventDefault(),i.shiftKey||t.arrowKeySwitchMode?H(-1,"keyboard-arrow-prev"):S(-5);break;case"ArrowRight":i.preventDefault(),i.shiftKey||t.arrowKeySwitchMode?H(1,"keyboard-arrow-next"):S(5);break;case"ArrowUp":i.preventDefault(),L(t.volume+5,{source:"keyboard"});break;case"ArrowDown":i.preventDefault(),L(t.volume-5,{source:"keyboard"});break;case"w":case"W":i.preventDefault(),V(t.brightness+5,{source:"keyboard"});break;case"s":case"S":i.preventDefault(),V(t.brightness-5,{source:"keyboard"});break;case"r":case"R":i.preventDefault(),(l=e.btnRotate90)==null||l.click();break;case"a":case"A":i.preventDefault(),(u=e.btnAutoRotate)==null||u.click();break;case"m":case"M":i.preventDefault(),O();break;case"f":case"F":i.preventDefault(),Qe();break;case"g":case"G":i.preventDefault(),(g=e.btnGestureGuide)==null||g.click();break;case"e":case"E":i.preventDefault(),Pe();break;case",":case"o":case"O":i.preventDefault(),k("settings");break;case"u":case"U":i.preventDefault(),Re();break;case"[":i.preventDefault(),(B=e.btnSetPointA)==null||B.click();break;case"]":i.preventDefault(),(w=e.btnSetPointB)==null||w.click();break;case"Escape":ne(),k(null);break}});let xe=null;function Ye(){xe&&clearTimeout(xe);const i=p.getEcoTickInterval(!0);xe=setTimeout(()=>{T(p.getTelemetry());const l=t.playlist[t.currentIndex],{currentTime:u,duration:g,paused:B}=y();t.rememberResumePosition&&l&&!B&&u>1&&Ln(l.id,u,g),Ye()},i)}try{V(t.brightness,{source:"init-restore"}),L(t.volume,{source:"init"}),te(),T(p.getTelemetry()),ii(),j(t.currentIndex,!0),P(3e3),Ye()}catch(i){console.error("[OmniPlay Boot] Safe boot recovery:",i)}}try{document.readyState==="loading"?document.addEventListener("DOMContentLoaded",kn):kn()}catch(n){console.error("[OmniPlay Entry] Fatal protection caught:",n)}
