(function(){const i=document.createElement("link").relList;if(i&&i.supports&&i.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))r(n);new MutationObserver(n=>{for(const c of n)if(c.type==="childList")for(const e of c.addedNodes)e.tagName==="LINK"&&e.rel==="modulepreload"&&r(e)}).observe(document,{childList:!0,subtree:!0});function a(n){const c={};return n.integrity&&(c.integrity=n.integrity),n.referrerPolicy&&(c.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?c.credentials="include":n.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function r(n){if(n.ep)return;n.ep=!0;const c=a(n);fetch(n.href,c)}})();const ue=2,be="v0.1.2",xe="2026-11-15",qn="https://terryfantpe.github.io/tstock-data/videoplayer/app_manifest.json",Gn="https://raw.githubusercontent.com/terryfantpe/tstock-data/main/videoplayer/app_manifest.json",zn="v0.1.2 全面根除 Android 啟動閃退 (setContentView 時序與 Java 17 編譯校準)、新增完整系統設定中心與 P2R-OTA 雲端差分熱更新 / Tier-3 APK 原生自升級引擎";let Ne=null;function Oe(){try{if(typeof window<"u"){const t=window.OmniPlayOTA||window.GroundOTA||window.ZiweiOTA;if(t&&typeof t.getOtaInfo=="function"){const i=t.getOtaInfo();if(i)return typeof i=="string"?JSON.parse(i):i}if(Ne)return Ne}}catch(t){console.warn("[OmniPlayOTA] Failed to read native OTA info:",t)}return null}async function In(){var t,i,a;try{if(typeof window<"u"){const r=window.OmniPlayOTA||window.GroundOTA||window.ZiweiOTA;if(r&&typeof r.getOtaInfo=="function"){const c=r.getOtaInfo();if(c)return typeof c=="string"?JSON.parse(c):c}const n=((t=window.__TAURI_INTERNALS__)==null?void 0:t.invoke)||((a=(i=window.__TAURI__)==null?void 0:i.core)==null?void 0:a.invoke);if(typeof n=="function"){const c=await n("ota_get_info");if(c&&typeof c=="object")return Ne=c,c}}}catch(r){console.warn("[OmniPlayOTA] Failed to refresh async OTA info:",r)}return Oe()}const f={nativeInfo:null,checking:!1,remoteManifest:null,fetchError:null,updating:!1,progressPct:0,progressMsg:"",confirmRollback:!1,apkUpgradeInProgress:!1,apkRetryQueue:[]};let mn=!1,gn=0;function Un(t){return String(t??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function he(){return typeof window>"u"?null:window.OmniPlayOTA||window.GroundOTA||window.ZiweiOTA||null}function fe(t){typeof window<"u"&&typeof window._showOmniPlayToast=="function"&&window._showOmniPlayToast(t)}function Ve(t){return typeof t!="number"||!Number.isFinite(t)||t<=0?"--":t>=1024*1024?`${(t/(1024*1024)).toFixed(2)} MB`:`${(t/1024).toFixed(2)} KB`}function Se(){var t;return Math.max(ue,Number((t=f.nativeInfo)==null?void 0:t.effectiveVersion)||0)}function Wn(){var s,l;const t=Se(),i=typeof((s=f.remoteManifest)==null?void 0:s.version)=="number"?f.remoteManifest.version:null,a=f.nativeInfo,r=typeof((l=f.remoteManifest)==null?void 0:l.min_apk_version)=="number"?f.remoteManifest.min_apk_version:1,n=!!a&&i!==null&&(a.apkVersionCode||1)<r,c=i!==null&&i>t&&!n,e=c?`✨ 新版 OTA v${i} 可升級`:`OTA v${t} · ${be}`;return`
    <div class="ota-nav-controls">
      <span
        class="version-badge${c?" has-update":""}"
        id="header-version-badge"
        role="button"
        tabindex="0"
        onclick="window.openOtaModal && window.openOtaModal()"
        onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();window.openOtaModal&&window.openOtaModal();}"
        title="點擊開啟 P2R-OTA 雲端熱更新與 APK 升級中心"
      >${Un(e)}</span>
      <button
        type="button"
        class="header-ota-direct-btn ota-header-btn${c?" has-update":""}"
        id="btn-header-ota-direct"
        onclick="window.openOtaModal && window.openOtaModal()"
        title="雲端線上熱更新 (P2R-OTA) 與原生 APK 升級"
      >
        <span id="ota-header-btn-label">☁️ 線上更新</span>
        <span class="ota-dot" id="ota-header-direct-dot"${c?"":" hidden"}></span>
      </button>
    </div>
  `}function Mn(){var i,a,r,n,c,e;if(typeof document>"u"||!document.body)return null;let t=document.getElementById("ota-modal-backdrop");return t||(t=document.createElement("div"),t.className="ota-modal-backdrop",t.id="ota-modal-backdrop",t.setAttribute("role","dialog"),t.setAttribute("aria-modal","true"),t.setAttribute("aria-labelledby","ota-modal-title"),t.setAttribute("hidden",""),t.innerHTML=`
      <div class="ota-modal-card" id="ota-modal-card">
        <div class="ota-modal-header">
          <div class="ota-title-wrap">
            <span class="ota-cloud-icon" aria-hidden="true">☁️</span>
            <div>
              <h2 class="ota-title-main" id="ota-modal-title">OmniPlay Pro · 雲端 OTA 熱更新中心</h2>
              <p class="ota-title-sub" id="ota-modal-subtitle">P2R-OTA 差分前端熱重載 ＆ Tier-3 原生 APK 自升級系統</p>
            </div>
          </div>
          <button type="button" class="ota-close-btn" id="btn-close-ota-modal">✕ 關閉</button>
        </div>

        <!-- Data Isolation Safety Banner -->
        <div class="ota-safety-banner">
          <span class="ota-safety-icon" aria-hidden="true">🛡️</span>
          <div>
            <strong id="ota-safety-title">亮度記憶與播放設定 100% 安全保留：</strong>
            <span id="ota-safety-desc">雲端熱更新僅更新前端介面與核心邏輯，您的亮度記憶、音量、硬體解碼與播放進度均完整保留。</span>
          </div>
        </div>

        <!-- Local Telemetry Box -->
        <div class="ota-telemetry-box">
          <div class="ota-telemetry-row">
            <span class="ota-label" id="ota-lbl-local-ver">目前運作版本</span>
            <strong class="ota-val" id="ota-local-ver-text">OTA v${ue} (${be} · ${xe})</strong>
          </div>
          <div class="ota-telemetry-row">
            <span class="ota-label" id="ota-lbl-base-core">底層核心基座</span>
            <strong class="ota-val" id="ota-base-core-text">Web Runtime</strong>
          </div>
          <div class="ota-telemetry-row">
            <span class="ota-label" id="ota-lbl-engine-layer">目前載入圖層</span>
            <strong class="ota-val ota-engine-tag" id="ota-engine-layer-text">Web 瀏覽器直連模式</strong>
          </div>
          <div class="ota-telemetry-row" id="ota-local-hash-row" hidden>
            <span class="ota-label" id="ota-lbl-local-hash">本地套件雜湊 (SHA-256)</span>
            <code class="ota-code" id="ota-local-hash-text">--</code>
          </div>
        </div>

        <!-- Remote Cloud Node Box -->
        <div class="ota-remote-box" id="ota-remote-box">
          <div class="ota-remote-header">
            <span class="ota-remote-title" id="ota-remote-node-title">🌐 GitHub 雲端發佈節點 (tstock-data/videoplayer)</span>
            <button type="button" class="ota-refresh-btn" id="btn-ota-check-manifest">🔄 重新檢查</button>
          </div>

          <div class="ota-status-hint" id="ota-checking-hint" hidden>
            ⏳ 正在連線 GitHub 雲端節點檢查最新清單...
          </div>

          <div class="ota-error-hint" id="ota-error-hint" hidden></div>

          <div class="ota-manifest-details" id="ota-manifest-details" hidden>
            <div class="ota-telemetry-row">
              <span class="ota-label" id="ota-lbl-remote-ver">雲端最新版本</span>
              <strong class="ota-val" id="ota-remote-ver-text">--</strong>
            </div>
            <div class="ota-telemetry-row">
              <span class="ota-label" id="ota-lbl-remote-size">熱更套件大小</span>
              <span class="ota-val" id="ota-remote-size-text">--</span>
            </div>
            <div class="ota-telemetry-row" id="ota-remote-delta-row" hidden>
              <span class="ota-label" id="ota-lbl-remote-delta">差異更新檔案</span>
              <span class="ota-val" id="ota-remote-delta-text" style="color: #38bdf8;">--</span>
            </div>
            <div class="ota-telemetry-row">
              <span class="ota-label" id="ota-lbl-remote-time">雲端發佈時間</span>
              <span class="ota-val" id="ota-remote-time-text">--</span>
            </div>
            <div class="ota-telemetry-row">
              <span class="ota-label" id="ota-lbl-remote-hash">雲端 SHA-256 校驗碼</span>
              <code class="ota-code" id="ota-remote-hash-text">--</code>
            </div>
            <div class="ota-changelog-box">
              <div class="ota-changelog-title" id="ota-lbl-changelog">📋 版本更新日誌 (Changelog)</div>
              <div id="ota-remote-changelog-text">--</div>
            </div>
          </div>

          <div class="ota-apk-old-warn" id="ota-apk-old-warn" hidden></div>
        </div>

        <!-- Live Progress Bar -->
        <div class="ota-progress-wrap" id="ota-progress-wrap" hidden>
          <div class="ota-progress-meta">
            <span id="ota-progress-msg">正在同步雲端更新套件...</span>
            <strong id="ota-progress-pct">0%</strong>
          </div>
          <div class="ota-progress-track">
            <div class="ota-progress-fill" id="ota-progress-fill" style="width: 0%;"></div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="ota-actions-col">
          <button type="button" class="ota-btn-primary" id="btn-ota-start-update">
            ⚡ 立即強制同步雲端最新版本
          </button>
          <button
            type="button"
            class="ota-btn-apk-tier3"
            id="btn-ota-upgrade-apk"
            hidden
          >
            📦 下載並安裝最新完整版 APK (Tier-3 原生自升級)
          </button>
          <button
            type="button"
            class="ota-btn-apk-browser"
            id="btn-ota-browser-apk"
            hidden
          >
            🌐 使用系統瀏覽器直接下載最新 APK
          </button>
          <button type="button" class="ota-btn-rollback" id="btn-ota-rollback" hidden>
            ⏪ 還原為 APK 內建出廠版本 (v${ue})
          </button>
        </div>
      </div>
    `,document.body.appendChild(t),t.addEventListener("click",s=>{s.target&&s.target.id==="ota-modal-backdrop"&&Ie()}),(i=document.getElementById("btn-close-ota-modal"))==null||i.addEventListener("click",Ie),(a=document.getElementById("btn-ota-check-manifest"))==null||a.addEventListener("click",()=>{Ee(!1)}),(r=document.getElementById("btn-ota-start-update"))==null||r.addEventListener("click",()=>{Kn()}),(n=document.getElementById("btn-ota-upgrade-apk"))==null||n.addEventListener("click",()=>{Ge()}),(c=document.getElementById("btn-ota-browser-apk"))==null||c.addEventListener("click",()=>{Me()}),(e=document.getElementById("btn-ota-rollback"))==null||e.addEventListener("click",()=>{Zn()})),!mn&&typeof document<"u"&&(mn=!0,document.addEventListener("keydown",s=>{if(s.key==="Escape"){const l=document.getElementById("ota-modal-backdrop");l&&!l.hasAttribute("hidden")&&Ie()}})),t}function ie(){var O,Z,ae,re;if(typeof document>"u")return;const t=document.getElementById("ota-modal-card"),i=document.getElementById("ota-remote-box"),a=document.getElementById("ota-local-ver-text"),r=document.getElementById("ota-base-core-text"),n=document.getElementById("ota-engine-layer-text"),c=document.getElementById("ota-local-hash-row"),e=document.getElementById("ota-local-hash-text"),s=document.getElementById("btn-ota-check-manifest"),l=document.getElementById("btn-close-ota-modal"),m=document.getElementById("ota-checking-hint"),p=document.getElementById("ota-error-hint"),h=document.getElementById("ota-manifest-details"),g=document.getElementById("ota-remote-ver-text"),y=document.getElementById("ota-remote-size-text"),T=document.getElementById("ota-remote-time-text"),k=document.getElementById("ota-remote-hash-text"),C=document.getElementById("ota-remote-changelog-text"),N=document.getElementById("ota-apk-old-warn"),R=document.getElementById("ota-progress-wrap"),V=document.getElementById("ota-progress-msg"),w=document.getElementById("ota-progress-pct"),D=document.getElementById("ota-progress-fill"),B=document.getElementById("btn-ota-start-update"),$=document.getElementById("btn-ota-upgrade-apk"),S=document.getElementById("btn-ota-browser-apk"),E=document.getElementById("btn-ota-rollback"),M=document.getElementById("ota-header-direct-dot"),F=document.getElementById("btn-header-ota-direct"),I=f.nativeInfo,G=!!I,W=he(),H=!!(W&&typeof W.downloadAndInstallApk=="function"),K=Se(),J=typeof((O=f.remoteManifest)==null?void 0:O.version)=="number"?f.remoteManifest.version:null,se=typeof((Z=f.remoteManifest)==null?void 0:Z.min_apk_version)=="number"?f.remoteManifest.min_apk_version:1,le=G&&J!==null&&(I.apkVersionCode||1)<se,U=J!==null&&J>K&&!le;M&&(M.hidden=!U,U?M.removeAttribute("hidden"):M.setAttribute("hidden","")),F&&F.classList.toggle("has-update",U);const Y=document.getElementById("header-version-badge");Y&&(Y.textContent=U?`✨ 新版 OTA v${J} 可升級`:`OTA v${K} · ${be}`,Y.classList.toggle("has-update",U));const L=document.getElementById("settings-ota-ver-label");L&&(L.textContent=`OTA v${K} (${be} · ${xe})`);const b=document.getElementById("settings-ota-layer-label");if(b&&(G?b.textContent=I.isOtaActive?`🟢 雲端熱更圖層 (web_live v${I.localOtaVersion||K})`:`📦 APK 內建出廠圖層 (v${I.apkVersionCode||ue})`:b.textContent="🌐 Web 瀏覽器直連執行環境"),t&&t.classList.toggle("has-update",U),i&&i.classList.toggle("has-update",U),l&&(l.hidden=f.updating),a&&(a.textContent=`OTA v${K} (${be} · ${xe})`),r)if(G){const x=String(I.apkVersionName||be).replace(/^v/i,"");r.textContent=`Android APK Core #${I.apkVersionCode||ue} (v${x})`}else r.textContent="Web Runtime (Vite ES Module)";if(n&&(G?I.isOtaActive?(n.textContent=`🟢 雲端熱更圖層啟用中 (web_live v${I.localOtaVersion||K})`,n.style.color="#2ecc71"):(n.textContent=`📦 APK 內建資產圖層 (v${I.apkVersionCode||ue})`,n.style.color="#f6c050"):(n.textContent="🌐 Web 瀏覽器直連模式",n.style.color="#38bdf8")),c&&e&&(I!=null&&I.bundleHash&&I.isOtaActive?(c.hidden=!1,c.removeAttribute("hidden"),e.textContent=`${String(I.bundleHash).slice(0,16)}...`):(c.hidden=!0,c.setAttribute("hidden",""))),s&&(s.disabled=f.checking||f.updating,s.textContent=f.checking?"⏳ 檢查中...":"🔄 重新檢查"),m){const x=f.checking&&!f.remoteManifest;m.hidden=!x,x?m.removeAttribute("hidden"):m.setAttribute("hidden","")}if(p&&(f.fetchError?(p.hidden=!1,p.removeAttribute("hidden"),p.textContent=`⚠️ ${f.fetchError}`):(p.hidden=!0,p.setAttribute("hidden",""))),h){const x=f.remoteManifest;if(x){if(h.hidden=!1,h.removeAttribute("hidden"),g){const X=x.display_version||x.version_name||`v0.1.${x.version}`;g.textContent=`OTA v${x.version} (${X}) ${U?" — ✨ 發現新版本可升級！":" — ✓ 已是最新同步狀態"}`,g.style.color=U?"#4ade80":"#f6c050"}y&&(y.textContent=Ve(x.bundle_size)),T&&(T.textContent=x.published_at||"--"),k&&(k.textContent=x.bundle_hash?`${String(x.bundle_hash).slice(0,16)}...`:"--"),C&&(C.textContent=x.changelog||zn)}else h.hidden=!0,h.setAttribute("hidden","")}if(N&&(le?(N.hidden=!1,N.removeAttribute("hidden"),N.textContent=`⚠️ 此雲端熱更新需要底層 APK 版本 ≥ v${se}，請點擊下方綠色按鈕直接升級完整 APK！`):(N.hidden=!0,N.setAttribute("hidden",""))),R&&V&&w&&D&&(f.updating||f.progressMsg?(R.hidden=!1,R.removeAttribute("hidden"),V.textContent=f.progressMsg||"正在同步雲端更新套件...",w.textContent=f.updating?`${f.progressPct}%`:"100%",D.style.width=`${f.updating?f.progressPct:100}%`):(R.hidden=!0,R.setAttribute("hidden",""))),B&&(B.disabled=f.updating||le,B.classList.toggle("has-update",U),f.updating?B.textContent="⏳ 正在下載並套用雲端熱更新...":U?B.textContent=`🚀 立即熱更新至 OTA v${J} (${Ve((ae=f.remoteManifest)==null?void 0:ae.bundle_size)})`:G?B.textContent=`⚡ 強制重新同步雲端熱更套件${J?` (v${J})`:""}`:B.textContent="🔄 重新整理並清除快取載入最新版"),$)if(H){$.hidden=!1,$.removeAttribute("hidden"),$.disabled=f.updating;const X=Number((re=f.remoteManifest)==null?void 0:re.apk_size)||0,de=X>0?` (${Ve(X)})`:"";$.textContent=`📦 下載並安裝最新完整版 APK${de}`}else $.hidden=!0,$.setAttribute("hidden","");if(S&&(S.hidden=!1,S.removeAttribute("hidden"),S.disabled=!1,S.textContent="🌐 直接下載最新 Android APK 安裝包 (Videoplayer.apk)"),E)if(G&&(I!=null&&I.isOtaActive)){const x=I.apkVersionCode||ue;E.hidden=!1,E.removeAttribute("hidden"),E.disabled=f.updating,E.classList.toggle("is-confirming",f.confirmRollback),E.textContent=f.confirmRollback?`⚠️ 確定要清除雲端熱更並還原至出廠 v${x} 嗎？（再次點擊確認）`:`⏪ 還原為 APK 內建出廠版本 (v${x})`}else E.hidden=!0,E.setAttribute("hidden","")}async function Ee(t=!1){const i=typeof t=="object"?!!(t!=null&&t.silent):!!t;if(f.checking=!0,f.fetchError=null,ie(),typeof fetch!="function")return f.checking=!1,ie(),null;const a=[`${qn}?t=${Date.now()}`,`${Gn}?t=${Date.now()}`];let r=null;for(const n of a){const c=typeof AbortController<"u"?new AbortController:null,e=c?setTimeout(()=>c.abort(),6e3):null;try{const s=await fetch(n,{cache:"no-store",signal:c?c.signal:void 0});if(e&&clearTimeout(e),!s.ok)throw new Error(`HTTP ${s.status}`);const l=await s.json();f.remoteManifest=l,f.fetchError=null;const m=Se(),p=typeof(l==null?void 0:l.min_apk_version)=="number"?l.min_apk_version:1,h=!!f.nativeInfo&&(f.nativeInfo.apkVersionCode||1)<p;return i&&typeof(l==null?void 0:l.version)=="number"&&l.version>m&&!h?fe(`☁️ 發現新版雲端熱更 OTA v${l.version}，可點擊右上角「線上更新」升級！`):i||fe(`✅ 已取得雲端最新版本資訊 (OTA v${(l==null?void 0:l.version)||ue})`),f.checking=!1,ie(),l}catch(s){e&&clearTimeout(e),r=s}}return f.checking=!1,f.fetchError=(r==null?void 0:r.name)==="AbortError"?"連線雲端更新節點逾時，請檢查網路連線":`無法連線至雲端更新節點 (${(r==null?void 0:r.message)||"Network Error"})`,ie(),null}async function Ae(){Mn(),f.confirmRollback=!1;const t=document.getElementById("ota-modal-backdrop");t&&(t.hidden=!1,t.removeAttribute("hidden"),t.classList.add("is-open")),f.nativeInfo=await In(),ie(),Ee(!1)}function Ie(){if(f.updating)return;f.confirmRollback=!1;const t=document.getElementById("ota-modal-backdrop");t&&(t.hidden=!0,t.setAttribute("hidden",""),t.classList.remove("is-open"))}async function Kn(){var c,e;if(f.updating)return;const t=Se(),i=typeof((c=f.remoteManifest)==null?void 0:c.version)=="number"?f.remoteManifest.version:null,r=!(i!==null&&i>t),n=he();if(n&&typeof n.triggerHotUpdate=="function"){f.updating=!0,f.progressPct=5,f.progressMsg="正在啟動 Android P2R-OTA 雲端差分熱更新引擎...",ie();try{n.triggerHotUpdate(!!r)}catch(s){f.updating=!1,f.progressMsg=`啟動熱更新失敗：${(s==null?void 0:s.message)||s}`,ie()}return}if(fe("🔄 正在重新載入最新前端版本..."),typeof window<"u"&&((e=window.location)!=null&&e.href)){const s=new URL(window.location.href);s.searchParams.set("ota_t",String(Date.now())),window.location.replace(s.toString())}}function jn(t){const i=t||{},a=i.version||ue,r=`https://raw.githubusercontent.com/terryfantpe/tstock-data/main/videoplayer/Videoplayer.apk?v=${a}`,n=i.apk_pages_url||i.apk_url||`https://terryfantpe.github.io/tstock-data/videoplayer/Videoplayer.apk?v=${a}`,c=`https://github.com/terryfantpe/tstock-data/raw/main/videoplayer/Videoplayer.apk?v=${a}`,e=String(i.apk_hash||"").trim();return[{step:1,url:r,hash:e},{step:2,url:n,hash:""},{step:3,url:c,hash:""}]}function Me(){const i=(f.remoteManifest||{}).version||ue,a=`https://raw.githubusercontent.com/terryfantpe/tstock-data/main/videoplayer/Videoplayer.apk?v=${i}&t=${Date.now()}`,r=he();f.updating=!1,f.apkUpgradeInProgress=!1,f.apkRetryQueue=[],f.progressPct=100,f.progressMsg="已開啟外部下載連結以取得最新 Videoplayer.apk",ie(),fe("🌐 正在開啟最新 Videoplayer.apk 下載連結...");try{if(r&&typeof r.openExternalUrl=="function"&&r.openExternalUrl(a))return}catch{}if(typeof document<"u"&&document.body){const n=document.createElement("a");n.href=a,n.target="_blank",n.rel="noopener noreferrer",n.setAttribute("download",`OmniPlay_Pro_v0.1.${i}.apk`),document.body.appendChild(n),n.click(),n.remove()}else typeof window<"u"&&typeof window.open=="function"&&window.open(a,"_blank")}async function Ge(){if(f.updating)return;const t=he();if(!t||typeof t.downloadAndInstallApk!="function"){Me();return}!f.remoteManifest&&!f.checking&&await Ee(!0);const i=jn(f.remoteManifest),a=i.shift();f.apkUpgradeInProgress=!0,f.apkRetryQueue=i,f.updating=!0,f.progressPct=4,f.progressMsg="正在從雲端下載最新完整版 Videoplayer.apk...",ie();try{t.downloadAndInstallApk(a.url,a.hash)}catch(r){f.updating=!1,f.apkUpgradeInProgress=!1,f.apkRetryQueue=[],f.progressMsg=`APK 下載啟動失敗：${(r==null?void 0:r.message)||r}`,ie()}}async function Zn(){if(f.updating||!f.nativeInfo)return;if(!f.confirmRollback){f.confirmRollback=!0,ie();return}const t=he();t&&typeof t.resetToBuiltinAssets=="function"&&(f.updating=!0,f.progressPct=50,f.progressMsg="正在清除 web_live 熱更圖層並還原 APK 內建版本...",ie(),t.resetToBuiltinAssets())}function Qn(){try{if(Mn(),f.nativeInfo=Oe(),typeof window<"u"){window.openOtaModal=Ae,window.closeOtaModal=Ie,window.triggerTier3ApkUpgrade=Ge;const t=(a,r)=>{f.updating=!0,f.progressPct=typeof a=="number"?Math.max(0,Math.min(100,Math.round(a))):0,f.progressMsg=r||"正在同步雲端更新套件...",ie()},i=(a,r,n)=>{const c=Date.now();if(c-gn<350)return;gn=c;const e=typeof r=="number",s=e?n:typeof r=="string"?r:n;if(!a&&f.apkUpgradeInProgress){const l=he();if(f.apkRetryQueue.length>0&&l&&typeof l.downloadAndInstallApk=="function"){const m=f.apkRetryQueue.shift();f.updating=!0,f.progressPct=8,f.progressMsg=`正在切換備援鏡像節點 (#${m.step}) 下載 APK...`,ie(),setTimeout(()=>{try{l.downloadAndInstallApk(m.url,m.hash)}catch{Me()}},450);return}f.apkUpgradeInProgress=!1,f.apkRetryQueue=[],Me();return}if(f.apkUpgradeInProgress=!1,f.apkRetryQueue=[],f.updating=!1,f.nativeInfo=Oe(),a){const l=e?r:Se();f.progressPct=100,f.progressMsg=s||`✅ 已成功熱更新至 OTA v${l}，即將重新載入...`,fe(f.progressMsg)}else f.progressMsg=s||"目前已在最新版本狀態",s&&fe(s);ie()};window.__onOmniPlayOtaProgress=t,window.__onOmniPlayOtaComplete=i,window.__onOmniPlayOtaDone=i,window.__onGroundOtaProgress=t,window.__onGroundOtaComplete=i,window.__onGroundOtaDone=i,window.__onZiweiOtaProgress=t,window.__onZiweiOtaComplete=i,window.__onZiweiOtaDone=i}ie(),In().then(t=>{f.nativeInfo=t,ie(),setTimeout(()=>{Ee(!0)},1500)})}catch(t){console.warn("[OmniPlayOTA] initOtaSystem warning:",t)}}const vn=[{id:"demo-cinema-16-9",title:"星際地平線：16:9 劇院寬螢幕測試",subtitle:"1280×720 • 60FPS • 16:9 橫向標準",width:1280,height:720,aspectLabel:"16:9",orientation:"landscape",sceneType:"cosmos",duration:120,fps:60,isDemo:!0,badge:"16:9 橫向劇院",description:"用於測試標準 16:9 劇院比例在橫向視窗滿版播放，以及切換至手機直向視窗時自動旋轉 90° 無損放大。"},{id:"demo-shorts-9-16",title:"霓虹賽博直式短片：9:16 自動轉向測試",subtitle:"720×1280 • 60FPS • 9:16 直向滿版",width:720,height:1280,aspectLabel:"9:16",orientation:"portrait",sceneType:"neon-vertical",duration:90,fps:60,isDemo:!0,badge:"9:16 直向短片",description:"用於測試 9:16 直向影片在橫向螢幕自動轉向 90° 以達成不改變 scale(1) 的最大可視面積。"},{id:"demo-ultra-21-9",title:"極光流體實驗：21:9 超寬電影測試",subtitle:"1260×540 • 60FPS • 21:9 超寬比例",width:1260,height:540,aspectLabel:"21:9",orientation:"landscape",sceneType:"aurora",duration:150,fps:60,isDemo:!0,badge:"21:9 電影超寬",description:"用於測試 21:9 電影寬銀幕在各種視窗比例下的幾何中心對齊與四角零裁切校準。"},{id:"demo-classic-4-3",title:"復古膠片校準圖卡：4:3 無損比例測試",subtitle:"960×720 • 60FPS • 4:3 經典比例",width:960,height:720,aspectLabel:"4:3",orientation:"landscape",sceneType:"calibration",duration:60,fps:60,isDemo:!0,badge:"4:3 經典校準",description:"內建四角準星與正圓幾何圖卡，可直觀驗證旋轉與最大化時 0% 畫面裁切、1:1 等比無變形。"}],bn=[{id:"flat",name:"原音直通 (Flat)",bass:0,mid:0,treble:0,boost:1},{id:"cinema",name:"劇院震撼 (Cinema)",bass:6,mid:2,treble:4,boost:1.15},{id:"vocal",name:"人聲清晰 (Vocal)",bass:-2,mid:6,treble:3,boost:1.1},{id:"bass",name:"重低音增強 (Bass)",bass:9,mid:0,treble:1,boost:1.1},{id:"night",name:"夜間柔化 (Night)",bass:-5,mid:3,treble:-2,boost:.9}],Yn=[{key:"Space",action:"播放 / 暫停",desc:"切換影片播放或暫停狀態（等同點擊畫面中央區域）"},{key:"PageUp / P / Shift+←",action:"同目錄上一片 (⏮)",desc:"立即切換至同資料夾 / 播放清單的上一部影片（亦可使用畫面左側 ⏮ 按鈕）"},{key:"PageDown / N / Shift+→",action:"同目錄下一片 (⏭)",desc:"立即切換至同資料夾 / 播放清單的下一部影片（亦可使用畫面右側 ⏭ 按鈕）"},{key:"← / →",action:"快退 / 快轉 或 前後換片",desc:"預設前後跳轉 ±5 秒；開啟「方向鍵換片」模式後可直接按 ← / → 切換同目錄前後片"},{key:"↑ / ↓",action:"調整音量 (±5%)",desc:"提高或降低音量（等同右側區域上下滑動）"},{key:"W / S",action:"調整亮度 (±5%)",desc:"提高或降低畫面亮度並自動記憶（等同左側區域上下滑動）"},{key:"R",action:"手動旋轉 90°",desc:"順時針旋轉影片 90°（0° → 90° → 180° → 270°）"},{key:"A",action:"切換自動轉向",desc:"開啟或關閉智慧偵測長寬比自動轉向無損最大化"},{key:"M",action:"靜音切換",desc:"一鍵切換靜音與恢復原音量"},{key:"F",action:"全螢幕切換",desc:"進入或退出劇院全螢幕模式"},{key:"G",action:"手勢導覽格線",desc:"顯示或隱藏左亮度 / 中播放 / 右音量三區手勢提示層"},{key:"E",action:"硬體解碼 / 節電模式",desc:"切換 GPU 硬體解碼 (MPO Zero-Copy) 與智慧省電模式"},{key:"O / ,",action:"⚙️ 設定中心",desc:"開啟整合式設定抽屜（亮度、自動轉向、前後鍵換片、硬體解碼、省電與恢復預設）"},{key:"U",action:"☁️ 線上更新 (P2R-OTA)",desc:"開啟 P2R-OTA 雲端熱更新與 APK 原生升級面板，檢查 GitHub 最新版本"},{key:"[ / ]",action:"A-B 區間循環",desc:"設定 A 點起點、B 點終點進行片段無限循環播放"}],te={openFileBtn:"開啟本機影片",openFolderBtn:"📂 開啟資料夾",sameDirBadgePrefix:"📁 同目錄連播",arrowKeySwitchToggle:"方向鍵換片",arrowKeySwitchOnTip:"已開啟「方向鍵換片」：按 ← / → 直接切換同目錄上一片 / 下一片",arrowKeySwitchOffTip:"已關閉「方向鍵換片」：按 ← / → 快退 / 快轉 5 秒（換片請按 PageUp/PageDown、P/N 或 Shift+←/→）"},Xn=[.5,.75,1,1.25,1.5,2],Jn=[{start:0,end:5,text:"💡 試試在畫面【左側上下滑動】調整亮度（自動記憶上次設定）"},{start:5,end:10,text:"🔊 在畫面【右側上下滑動】可即時無段調整音量大小"},{start:10,end:15,text:"⏯️ 點擊畫面【正中央區域】可快速切換播放與暫停"},{start:15,end:22,text:"⏮️⏭️ 同目錄可按前後鍵（PageUp/PageDown、P/N、Shift+←/→ 或兩側按鈕）直接換片！"},{start:22,end:30,text:"🔄 切換「9:16 直式短片」或點擊「模擬直向視窗」體驗不改變 Scale(1) 的自動轉向最大化！"}],Fe="vp_hw_decode",_e="vp_power_save",ei=[{id:"h264",name:"H.264 / AVC",contentType:'video/mp4; codecs="avc1.640028"',webCodec:"avc1.640028"},{id:"hevc",name:"HEVC / H.265",contentType:'video/mp4; codecs="hev1.1.6.L120.90"',webCodec:"hev1.1.6.L120.90"},{id:"vp9",name:"VP9 Profile 0",contentType:'video/webm; codecs="vp09.00.50.08"',webCodec:"vp09.00.50.08"},{id:"av1",name:"AV1 Main 10",contentType:'video/mp4; codecs="av01.0.08M.08"',webCodec:"av01.0.08M.08"}];function ti(){try{const t=localStorage.getItem(Fe);return t===null?(localStorage.setItem(Fe,"true"),!0):t!=="false"&&t!=="0"}catch{return!0}}function fn(t){const i=!!t;try{localStorage.setItem(Fe,String(i))}catch{}return i}function Rn(){try{const t=localStorage.getItem(_e);return t===null?(localStorage.setItem(_e,"true"),!0):t!=="false"&&t!=="0"}catch{return!0}}function hn(t){const i=!!t;try{localStorage.setItem(_e,String(i))}catch{}return i}function He(t=!0,i=!1){const a=!!(i||typeof document<"u"&&document.hidden);return t&&a?5:t?30:60}function Ln(t=!0){return{alpha:!1,desynchronized:!!t,willReadFrequently:!1}}function De(t=!0,i=!0){return t||!i?250:16}async function ni(){var r,n,c;const t={};for(const e of ei){let s={id:e.id,name:e.name,supported:e.id==="h264"||e.id==="vp9",smooth:!0,powerEfficient:!0};try{if(typeof navigator<"u"&&((r=navigator.mediaCapabilities)!=null&&r.decodingInfo)){const l=await navigator.mediaCapabilities.decodingInfo({type:"file",video:{contentType:e.contentType,width:1920,height:1080,bitrate:8e6,framerate:60}});s={id:e.id,name:e.name,supported:!!l.supported,smooth:!!l.smooth,powerEfficient:!!l.powerEfficient}}}catch{}t[e.id]=s}let i={supported:!1,hardwareAcceleration:"prefer-hardware"};try{if(typeof window<"u"&&typeof((n=window.VideoDecoder)==null?void 0:n.isConfigSupported)=="function"){const e=await window.VideoDecoder.isConfigSupported({codec:"avc1.640028",width:1920,height:1080,hardwareAcceleration:"prefer-hardware"});i={supported:!!(e!=null&&e.supported),hardwareAcceleration:((c=e==null?void 0:e.config)==null?void 0:c.hardwareAcceleration)||"prefer-hardware"}}}catch{}const a=Object.values(t).some(e=>e.supported&&e.powerEfficient)||i.supported;return{codecs:t,webCodecsHw:i,hardwareAcceleratedAvailable:a,probedAt:Date.now()}}function yn(t,{videoEl:i,veilEl:a,hwDecodeEnabled:r=!0,powerSaveEnabled:n=!0}={}){const c=Math.max(0,Math.min(100,Number.isFinite(Number(t))?Number(t):85)),e=!!(r&&n&&c<=85);let s="none",l=0;if(c<=85){const m=(85-c)/85;e?(s="none",l=Number((m*.92).toFixed(2))):(s=`brightness(${Number((.15+c/85*.85).toFixed(2))})`,l=Number((m*.45).toFixed(2)))}else{const m=(c-85)/15,p=Number((1+m*.35).toFixed(2)),h=Number((1+m*.04).toFixed(2));s=`brightness(${p}) contrast(${h})`,l=0}return i&&i.style&&(i.style.filter=s==="none"?"":s,i.dataset.mpoZeroCopy=e?"true":"false"),a&&a.style&&(a.style.opacity=String(l)),{brightness:c,mpoZeroCopyActive:e,videoFilter:s,veilOpacity:l}}function ii({videoEl:t=null,stageEl:i=null,veilEl:a=null,onStatusChange:r=null}={}){let n=t,c=i,e=a,s=ti(),l=Rn();fn(s),hn(l);let m=85,p=!!(s&&l&&m<=85),h=!0,g=!1,y={codecs:{h264:{id:"h264",name:"H.264 / AVC",supported:!0,smooth:!0,powerEfficient:!0},hevc:{id:"hevc",name:"HEVC / H.265",supported:!0,smooth:!0,powerEfficient:!0},vp9:{id:"vp9",name:"VP9 Profile 0",supported:!0,smooth:!0,powerEfficient:!0},av1:{id:"av1",name:"AV1 Main 10",supported:!0,smooth:!0,powerEfficient:!0}},webCodecsHw:{supported:!0,hardwareAcceleration:"prefer-hardware"},hardwareAcceleratedAvailable:!0,probedAt:0},T=null,k={supported:!1,levelPercent:100,charging:!0,statusLabel:"電源直供 / 智慧節電待命"},C=null,N=!1;function R(){if(typeof r=="function")try{r(I())}catch{}}function V(){if(!n)return;n.playsInline=!0,n.setAttribute("playsinline",""),n.setAttribute("webkit-playsinline",""),"disableRemotePlayback"in n&&(n.disableRemotePlayback=!!s),s?(n.dataset.hwDecode="prefer-hardware",n.setAttribute("decoding","async"),n.style.transform="translateZ(0)",n.style.backfaceVisibility="hidden",n.style.willChange="transform"):(n.dataset.hwDecode="software",n.style.transform="",n.style.backfaceVisibility="",n.style.willChange="auto"),c&&(c.classList.toggle("is-hw-decode",!!s),c.classList.toggle("is-power-save",!!l),c.classList.toggle("is-bg-throttled",!!g)),p=yn(m,{videoEl:n,veilEl:e,hwDecodeEnabled:s,powerSaveEnabled:l}).mpoZeroCopyActive}async function w(){var O;const b=!!(n&&!n.paused&&!n.ended&&n.readyState>=1&&typeof document<"u"&&!document.hidden);if(b&&!C)try{typeof navigator<"u"&&((O=navigator.wakeLock)!=null&&O.request)&&(C=await navigator.wakeLock.request("screen"),N=!0,C.addEventListener("release",()=>{C=null,N=!1,R()}),R())}catch{C=null,N=!1}else if(!b&&C){try{await C.release()}catch{}C=null,N=!1,R()}}function D(L){if(!L)return;const b=Number.isFinite(L.level)?L.level*100:100,O=Number(b.toFixed(0)),Z=!!L.charging;k={supported:!0,levelPercent:O,charging:Z,statusLabel:`${Z?"⚡ 充電中":"🔋 電池供電"} ${O}%`},R()}const B=()=>{D(T)};async function $(){var L,b;try{typeof navigator<"u"&&typeof navigator.getBattery=="function"&&(T=await navigator.getBattery(),D(T),(L=T.addEventListener)==null||L.call(T,"chargingchange",B),(b=T.addEventListener)==null||b.call(T,"levelchange",B))}catch{}}const S=()=>{g=!!(typeof document<"u"&&!!document.hidden&&l),c&&c.classList.toggle("is-bg-throttled",g),w(),R()},E=()=>{w(),R()};function M(L){L&&(L.addEventListener("play",E),L.addEventListener("playing",E),L.addEventListener("pause",E),L.addEventListener("ended",E))}function F(L){L&&(L.removeEventListener("play",E),L.removeEventListener("playing",E),L.removeEventListener("pause",E),L.removeEventListener("ended",E))}function I(){let L=0,b=0;if(n&&typeof n.getVideoPlaybackQuality=="function")try{const me=n.getVideoPlaybackQuality();L=Number((me==null?void 0:me.totalVideoFrames)||0),b=Number((me==null?void 0:me.droppedVideoFrames)||0)}catch{}else n&&(L=Number(n.webkitDecodedFrameCount||0),b=Number(n.webkitDroppedFrameCount||0));const O=L>0?b/L*100:0,Z=Number(O.toFixed(2)),ae=s?p?"GPU 硬體加速 (MPO Zero-Copy)":"GPU 硬體加速 (Prefer-HW)":"軟體解碼 (CPU Shader)",re=l?g?"背景深度節電 (5FPS • HUD 休眠)":"節電中 • CPU 休眠優化":"全速效能模式 (60Hz)",x=`${s?"⚡ 硬體解碼":"🖥️ 軟體解碼"} • ${l?"🍃 節電中":"🔥 效能"}`,X=De(l,h),de=X>=250?4:60,ye=He(l,typeof document<"u"&&document.hidden);let pe=0;return s&&l?pe=p?42:34:s?pe=24:l&&(pe=18),{hwDecodeEnabled:s,powerSaveEnabled:l,mpoZeroCopyActive:p,decodeModeLabel:ae,powerStateLabel:re,topbarBadgeText:x,targetDemoFps:ye,uiTickIntervalMs:X,uiTickHz:de,totalVideoFrames:L,droppedVideoFrames:b,dropRatePercent:Z,wakeLockActive:N,isBackgroundThrottled:g,estimatedPowerSavingPercent:pe,brightness:m,battery:{...k},codecs:{...y.codecs},webCodecsHw:{...y.webCodecsHw},hardwareAcceleratedAvailable:y.hardwareAcceleratedAvailable}}function G(L){return s=fn(!!L),V(),R(),s}function W(){return G(!s)}function H(L){return l=hn(!!L),g=!!(typeof document<"u"&&document.hidden&&l),V(),R(),l}function K(){return H(!l)}function J(L){m=Math.max(0,Math.min(100,Number.isFinite(Number(L))?Number(L):85));const b=yn(m,{videoEl:n,veilEl:e,hwDecodeEnabled:s,powerSaveEnabled:l});return p=b.mpoZeroCopyActive,R(),b}function se(L){return h=!!L,De(l,h)}function le({videoEl:L,stageEl:b,veilEl:O}={}){L&&L!==n&&(F(n),n=L,M(n)),b&&(c=b),O&&(e=O),V(),R()}async function U(){return y=await ni(),R(),y}function Y(){var L,b;F(n),typeof document<"u"&&document.removeEventListener("visibilitychange",S),T&&((L=T.removeEventListener)==null||L.call(T,"chargingchange",B),(b=T.removeEventListener)==null||b.call(T,"levelchange",B)),C&&(C.release().catch(()=>{}),C=null,N=!1)}return M(n),V(),typeof document<"u"&&document.addEventListener("visibilitychange",S),$(),U(),{get isHwDecodeEnabled(){return s},get isPowerSaveEnabled(){return l},setHwDecodeEnabled:G,toggleHwDecode:W,setPowerSaveEnabled:H,togglePowerSave:K,applyBrightness:J,setControlsVisible:se,bindElements:le,probeHardwareCapabilities:U,getEcoTickInterval:(L=h)=>De(l,L),getTargetDemoFps:()=>He(l,typeof document<"u"&&document.hidden),getEcoCanvasContextAttributes:()=>Ln(l),getTelemetry:I,syncWakeLock:w,destroy:Y}}const Re=new WeakMap;let Pe=null;function oi(){if(typeof window>"u")return!1;if(window.AndroidPlayerBridge||window.GroundOTA||window.ZiweiOTA||window.OmniPlayOTA)return!0;const t=typeof navigator<"u"&&navigator.userAgent||"";return/Android/i.test(t)&&/wv|Version\/\d+\.\d+/i.test(t)}function ai(){if(typeof window>"u")return null;const t=window.AudioContext||window.webkitAudioContext;if(!t)return null;if(!Pe||Pe.state==="closed")try{Pe=new t}catch{return null}return Pe}function Le(t,i,a){return Math.max(i,Math.min(a,t))}function wn(t,i=60){const a=Math.max(0,Number.isFinite(t)?t:0),r=Math.floor(a/60),n=Math.floor(a%60),c=Math.floor((a-Math.floor(a))*i);return`${String(r).padStart(2,"0")}:${String(n).padStart(2,"0")}.${String(c).padStart(2,"0")}`}function Sn(t="cosmos"){const i=ai();if(!i)return null;try{const a=typeof i.createMediaStreamDestination=="function"?i.createMediaStreamDestination():null,r={cosmos:[110,164.81,220,277.18],"neon-vertical":[130.81,196,246.94,293.66],aurora:[146.83,220,261.63,329.63],calibration:[123.47,185,246.94,308.68]},n=String(t||"cosmos").trim(),c=r[n]||r.cosmos,e=i.createBiquadFilter();e.type="lowshelf",e.frequency.value=120,e.gain.value=0;const s=i.createBiquadFilter();s.type="peaking",s.frequency.value=1e3,s.Q.value=1,s.gain.value=0;const l=i.createBiquadFilter();l.type="highshelf",l.frequency.value=6e3,l.gain.value=0;const m=i.createBiquadFilter();m.type="lowpass",m.frequency.value=1400,m.Q.value=.7;const p=i.createOscillator(),h=i.createGain();p.type="sine",p.frequency.value=.22,h.gain.value=450,p.connect(h),h.connect(m.frequency),p.start();const g=i.createGain();if(g.gain.value=0,m.connect(e),e.connect(s),s.connect(l),l.connect(g),g.connect(i.destination),a){const T=i.createGain();T.gain.value=1e-4,g.connect(T),T.connect(a)}const y=c.map((T,k)=>{const C=i.createOscillator(),N=i.createGain();return C.type=k%2===0?"sine":"triangle",C.frequency.value=T,C.detune.value=(k-1.5)*4,N.gain.value=k===0?.32:.16,C.connect(N),N.connect(m),C.start(),{osc:C,oscGain:N}});return{ctx:i,stream:a?a.stream:null,masterGain:g,bassFilter:e,midFilter:s,trebleFilter:l,UpdateVolume(T,k=.8,C=!1,N=1){try{i.state==="suspended"&&T&&!C&&k>0&&i.resume().catch(()=>{});const R=!T||C?0:Math.pow(Le(k,0,1),1.4)*.14*Le(N,.5,2);g.gain.setTargetAtTime(R,i.currentTime,.04)}catch{try{g.gain.value=0}catch{}}},setEq({bass:T=0,mid:k=0,treble:C=0}={}){try{e.gain.setTargetAtTime(T,i.currentTime,.05),s.gain.setTargetAtTime(k,i.currentTime,.05),l.gain.setTargetAtTime(C,i.currentTime,.05)}catch{}},destroy(){try{g.gain.value=0,p.stop(),p.disconnect(),y.forEach(({osc:T,oscGain:k})=>{try{T.stop(),T.disconnect(),k.disconnect()}catch{}}),g.disconnect()}catch{}}}}catch{return null}}function ri(t,i,a,r,n,c,e=30,s=!0){const l=String((c==null?void 0:c.sceneType)||"cosmos").trim(),m=(c==null?void 0:c.title)||"OmniPlay Pro 內建測試串流",p=(c==null?void 0:c.aspectLabel)||`${i}:${a}`,h=r;t.save(),t.clearRect(0,0,i,a),l==="neon-vertical"?li(t,i,a,h):l==="aurora"?di(t,i,a,h):l==="calibration"?ci(t,i,a,h):si(t,i,a,h),ui(t,i,a,h,n,m,p,e,s),t.restore()}function si(t,i,a,r){const n=i*.5,c=a*.5,e=Math.min(i,a),s=t.createRadialGradient(n,c,e*.04,n,c,Math.max(i,a)*.75);s.addColorStop(0,"#1e1238"),s.addColorStop(.45,"#0b0e22"),s.addColorStop(1,"#04050c"),t.fillStyle=s,t.fillRect(0,0,i,a);for(let m=0;m<70;m++){const h=(m*9301+49297)%233280/233280,g=.025+m%4*.015,y=((h*i+r*g*i*(m%2===0?1:-.6))%i+i)%i,T=m*4177%1e3/1e3*a,k=.8+m%3*.85,C=.35+.55*Math.abs(Math.sin(r*2.1+m));t.fillStyle=m%5===0?`rgba(56, 189, 248, ${C})`:`rgba(255, 255, 255, ${C})`,t.beginPath(),t.arc(y,T,k,0,Math.PI*2),t.fill()}t.save(),t.translate(n,c);for(let m=1;m<=4;m++){const p=e*(.12+m*.075);t.strokeStyle=m%2===0?"rgba(139, 92, 246, 0.35)":"rgba(56, 189, 248, 0.32)",t.lineWidth=1.6,t.beginPath(),t.arc(0,0,p,0,Math.PI*2),t.stroke();const h=r*(.9-m*.16)*(m%2===0?1:-1)+m*1.3,g=Math.cos(h)*p,y=Math.sin(h)*p;t.fillStyle=m%2===0?"#a855f7":"#38bdf8",t.beginPath(),t.arc(g,y,5.5,0,Math.PI*2),t.fill()}const l=t.createRadialGradient(0,0,e*.03,0,0,e*.16);l.addColorStop(0,"#ffffff"),l.addColorStop(.3,"#38bdf8"),l.addColorStop(.7,"rgba(139, 92, 246, 0.45)"),l.addColorStop(1,"rgba(139, 92, 246, 0)"),t.fillStyle=l,t.beginPath(),t.arc(0,0,e*.16,0,Math.PI*2),t.fill(),t.restore()}function li(t,i,a,r){const n=i*.5,c=a*.5,e=Math.min(i,a),s=t.createLinearGradient(0,0,0,a);s.addColorStop(0,"#090418"),s.addColorStop(.5,"#170930"),s.addColorStop(1,"#061527"),t.fillStyle=s,t.fillRect(0,0,i,a),t.strokeStyle="rgba(236, 72, 153, 0.28)",t.lineWidth=1.2;const l=12,m=r*60%(a/l);for(let p=m;p<a;p+=a/l)t.beginPath(),t.moveTo(0,p),t.lineTo(i,p),t.stroke();for(let p=0;p<=i;p+=i/8)t.strokeStyle="rgba(34, 211, 238, 0.2)",t.beginPath(),t.moveTo(p,0),t.lineTo(p,a),t.stroke();for(let p=0;p<3;p++){const h=a*(.25+p*.25),g=1+.08*Math.sin(r*3+p*1.5),y=e*.22*g;t.strokeStyle=p===1?"#22d3ee":"#f472b6",t.lineWidth=3,t.beginPath(),t.arc(n,h,y,0,Math.PI*2),t.stroke()}for(let p=0;p<24;p++){const h=(p+.5)/24*i,g=Math.abs(Math.sin(r*2.8+p*.55))*(a*.14)+12;t.fillStyle=p%2===0?"rgba(34, 211, 238, 0.45)":"rgba(244, 114, 182, 0.45)",t.fillRect(h-6,c-g/2,12,g)}}function di(t,i,a,r){const n=t.createLinearGradient(0,0,i,a);n.addColorStop(0,"#03131f"),n.addColorStop(.5,"#07222c"),n.addColorStop(1,"#0c1026"),t.fillStyle=n,t.fillRect(0,0,i,a),[{color:"rgba(16, 185, 129, 0.34)",amp:a*.15,freq:.0045,speed:1.4,yBase:a*.36},{color:"rgba(56, 189, 248, 0.30)",amp:a*.12,freq:.006,speed:-1.1,yBase:a*.52},{color:"rgba(168, 85, 247, 0.26)",amp:a*.1,freq:.005,speed:1.8,yBase:a*.65}].forEach(s=>{t.fillStyle=s.color,t.beginPath(),t.moveTo(0,a);for(let l=0;l<=i;l+=18){const m=s.yBase+Math.sin(l*s.freq+r*s.speed)*s.amp+Math.cos(l*s.freq*.5-r*.8)*(s.amp*.45);t.lineTo(l,m)}t.lineTo(i,a),t.closePath(),t.fill()});const e=Math.min(i,a);t.strokeStyle="rgba(52, 211, 153, 0.55)",t.lineWidth=2,t.beginPath(),t.arc(i*.5,a*.5,e*.32,0,Math.PI*2),t.stroke()}function ci(t,i,a,r){const n=i*.5,c=a*.5,e=Math.min(i,a);t.fillStyle="#0e1118",t.fillRect(0,0,i,a);const s=Math.round(e/12);t.strokeStyle="rgba(255, 255, 255, 0.12)",t.lineWidth=1;for(let y=n%s;y<i;y+=s)t.beginPath(),t.moveTo(y,0),t.lineTo(y,a),t.stroke();for(let y=c%s;y<a;y+=s)t.beginPath(),t.moveTo(0,y),t.lineTo(i,y),t.stroke();const l=["#e2e8f0","#facc15","#22d3ee","#4ade80","#e879f9","#f87171","#3b82f6"],m=i*.56/l.length,p=n-i*.56/2,h=c-e*.26;l.forEach((y,T)=>{t.fillStyle=y,t.globalAlpha=.78,t.fillRect(p+T*m,h,m-2,e*.11)}),t.globalAlpha=1,t.strokeStyle="#facc15",t.lineWidth=3,t.beginPath(),t.arc(n,c,e*.36,0,Math.PI*2),t.stroke();const g=r*1.5;t.strokeStyle="#38bdf8",t.lineWidth=2.5,t.beginPath(),t.moveTo(n,c),t.lineTo(n+Math.cos(g)*e*.36,c+Math.sin(g)*e*.36),t.stroke()}function ui(t,i,a,r,n,c,e,s=30,l=!0){const m=i*.5,p=a*.5,h=Math.min(i,a);t.strokeStyle="rgba(56, 189, 248, 0.65)",t.lineWidth=2,t.strokeRect(2,2,i-4,a-4);const g=Math.max(26,Math.round(h*.075)),y=10;t.strokeStyle="#facc15",t.lineWidth=4,t.beginPath(),t.moveTo(y,y+g),t.lineTo(y,y),t.lineTo(y+g,y),t.moveTo(i-y-g,y),t.lineTo(i-y,y),t.lineTo(i-y,y+g),t.moveTo(y,a-y-g),t.lineTo(y,a-y),t.lineTo(y+g,a-y),t.moveTo(i-y-g,a-y),t.lineTo(i-y,a-y),t.lineTo(i-y,a-y-g),t.stroke(),t.strokeStyle="rgba(255, 255, 255, 0.25)",t.lineWidth=1.5,t.beginPath(),t.arc(m,p,h*.22,0,Math.PI*2),t.moveTo(m-24,p),t.lineTo(m+24,p),t.moveTo(m,p-24),t.lineTo(m,p+24),t.stroke();const T=Math.min(i-48,460),k=74;t.fillStyle="rgba(8, 10, 20, 0.72)",t.fillRect(24,24,T,k),t.strokeStyle="rgba(255, 255, 255, 0.16)",t.lineWidth=1,t.strokeRect(24,24,T,k),t.fillStyle="#f8fafc",t.font='600 18px "Noto Sans TC", "Outfit", sans-serif',t.textBaseline="top",t.fillText(c,36,34),t.fillStyle="#38bdf8",t.font='500 13px "JetBrains Mono", monospace';const C=wn(r,s),N=wn(n,s),R=l?`ECO ${s}FPS`:`PERF ${s}FPS`;t.fillText(`${i}×${a} (${e}) • 1:1 • ${R} • ${C} / ${N}`,36,64)}function pi(t=null,i={}){let a=typeof(i==null?void 0:i.powerSaveEnabled)=="boolean"?i.powerSaveEnabled:Rn();const r=document.createElement("canvas");r.className="vp-demo-canvas",r.style.cssText="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;pointer-events:none;z-index:2;display:block;";let n=null;try{n=r.getContext("2d",Ln(a))}catch{n=null}if(!n)try{n=r.getContext("2d")}catch{n=null}let c=t||{id:"demo-cinema-16-9",title:"星際地平線：16:9 劇院寬螢幕測試",width:1280,height:720,aspectLabel:"16:9",sceneType:"cosmos",duration:120},e=Number(c.width)||1280,s=Number(c.height)||720,l=Number(c.duration)||120,m=0,p=1,h=(i==null?void 0:i.autoPlay)!==!1,g=null,y=null,T=0,k=0,C=!1,N=null,R=null,V=null;r.width=e,r.height=s;function w(){const b=typeof document<"u"&&!!document.hidden;return He(a,b)}function D(){var O;if(!V||!r)return;const b=((O=V.style)==null?void 0:O.filter)||"";r.style.filter!==b&&(r.style.filter=b)}function B(){if(!n)return;D();const b=w();ri(n,e,s,m,l,c,b,a)}function $(){if(!R)return;const b=V?V.volume:.8,O=V?V.muted:!1;R.UpdateVolume(h&&!C,b,O,1)}function S(b){if(V)try{V.dispatchEvent(new Event(b))}catch{}}function E(b){var re,x,X;if(C)return;y===null&&(y=b);const O=Math.min(.1,Math.max(0,(b-y)/1e3));y=b;const Z=w(),ae=1e3/Math.max(1,Z)-1.5;if(h){m+=O*p,m>=l&&((V?V.loop!==!1:!0)?m=m%l:(m=l,h=!1,$(),S("ended"),(re=i==null?void 0:i.onPlayChange)==null||re.call(i,!1),(x=i==null?void 0:i.onEnded)==null||x.call(i)));const de=a?200:80;b-k>=de&&(k=b,S("timeupdate"),(X=i==null?void 0:i.onTimeUpdate)==null||X.call(i,m,l))}b-T>=ae&&(T=b,B()),g=requestAnimationFrame(E)}function M(){g!==null||C||(y=performance.now(),B(),g=requestAnimationFrame(E))}function F(){g!==null&&(cancelAnimationFrame(g),g=null),y=null}function I(b){var Z;return m=Le(Number(b)||0,0,l),B(),S("seeking"),S("seeked"),S("timeupdate"),(Z=i==null?void 0:i.onTimeUpdate)==null||Z.call(i,m,l),m}function G(b=1){const O=Number(c==null?void 0:c.fps)||60;return I(m+b/O)}function W(){var b;if(h=!0,y=performance.now(),M(),$(),(b=i==null?void 0:i.onPlayChange)==null||b.call(i,!0),V&&V.srcObject&&V.paused)try{const O=V.play();O&&typeof O.catch=="function"&&O.catch(()=>{})}catch{}}function H(){var b;if(h=!1,$(),B(),(b=i==null?void 0:i.onPlayChange)==null||b.call(i,!1),V&&V.srcObject&&!V.paused)try{V.pause()}catch{}}function K(){return h?H():W(),h}function J(b){return p=Le(Number(b)||1,.25,4),p}function se(b){return a=!!b,B(),a}function le(b){var O,Z;b&&(c=b,e=Number(c.width)||1280,s=Number(c.height)||720,l=Number(c.duration)||120,m=0,r.width=e,r.height=s,R&&R.destroy(),R=Sn(c.sceneType),B(),$(),S("durationchange"),S("loadedmetadata"),S("timeupdate"),(O=i==null?void 0:i.onMetadata)==null||O.call(i,{width:e,height:s,duration:l,demoItem:c}),(Z=i==null?void 0:i.onLoadedMetadata)==null||Z.call(i,{width:e,height:s,duration:l,demoItem:c}))}function U(b){V=b,B();try{b.parentElement&&(b.parentElement.querySelectorAll(".vp-demo-canvas").forEach(X=>{X!==r&&X.remove()}),b.insertAdjacentElement("afterend",r))}catch{}if(R=Sn(c.sceneType),!oi()&&typeof r.captureStream=="function")try{if(N=r.captureStream(30),R!=null&&R.stream){const x=R.stream.getAudioTracks();x.length>0&&N.addTrack(x[0])}b.srcObject=N}catch{N=null}try{b.dataset.isDemo="true",b.dataset.demoId=c.id||"demo",b.dataset.demoWidth=String(e),b.dataset.demoHeight=String(s)}catch{}try{Object.defineProperty(b,"duration",{configurable:!0,get(){return l}}),Object.defineProperty(b,"currentTime",{configurable:!0,get(){return m},set(x){I(x)}})}catch{}const O=()=>{var x;h=!0,y=performance.now(),$(),(x=i==null?void 0:i.onPlayChange)==null||x.call(i,!0)},Z=()=>{var x;h=!1,$(),(x=i==null?void 0:i.onPlayChange)==null||x.call(i,!1)},ae=()=>{$()},re=()=>{Number.isFinite(b.playbackRate)&&b.playbackRate>0&&(p=b.playbackRate)};if(b.addEventListener("play",O),b.addEventListener("pause",Z),b.addEventListener("volumechange",ae),b.addEventListener("ratechange",re),b.__demoCleanupListeners=()=>{b.removeEventListener("play",O),b.removeEventListener("pause",Z),b.removeEventListener("volumechange",ae),b.removeEventListener("ratechange",re)},M(),$(),queueMicrotask(()=>{var x,X,de;C||(S("durationchange"),S("loadedmetadata"),S("canplay"),(x=i==null?void 0:i.onMetadata)==null||x.call(i,{width:e,height:s,duration:l,demoItem:c}),(X=i==null?void 0:i.onLoadedMetadata)==null||X.call(i,{width:e,height:s,duration:l,demoItem:c}),(de=i==null?void 0:i.onPlayChange)==null||de.call(i,h))}),(i==null?void 0:i.autoPlay)!==!1&&(h=!0,$(),b.srcObject))try{const x=b.play();x&&typeof x.catch=="function"&&x.catch(()=>{})}catch{}}function Y(){if(!C){C=!0,F();try{r.remove()}catch{r.parentNode&&r.parentNode.removeChild(r)}if(R&&(R.destroy(),R=null),N){try{N.getTracks().forEach(b=>b.stop())}catch{}N=null}if(V){if(typeof V.__demoCleanupListeners=="function"){try{V.__demoCleanupListeners()}catch{}delete V.__demoCleanupListeners}try{delete V.duration,delete V.currentTime}catch{}try{delete V.dataset.isDemo,delete V.dataset.demoId,delete V.dataset.demoWidth,delete V.dataset.demoHeight,delete V.__demoController}catch{}try{V.srcObject&&(V.srcObject=null)}catch{}V=null}}}return B(),{canvas:r,get stream(){return N},get currentTime(){return m},set currentTime(b){I(b)},get duration(){return l},get width(){return e},get height(){return s},get paused(){return!h},get playbackRate(){return p},set playbackRate(b){J(b)},get powerSaveEnabled(){return a},get targetFps(){return w()},get demoItem(){return c},getCurrentTime:()=>m,getDuration:()=>l,getDimensions:()=>({width:e,height:s}),getTargetFps:w,getCanvas:()=>r,seek:I,stepFrame:G,play:W,pause:H,togglePlay:K,setPlaybackRate:J,setPowerSaveMode:se,setEqGains:b=>{var O;return(O=R==null?void 0:R.setEq)==null?void 0:O.call(R,b)},loadDemo:le,bindToVideoElement:U,captureFrameDataUrl:(b="image/png")=>(B(),r.toDataURL(b)),destroy:Y,detach:Y}}function mi(t,i,a={}){if(!t)return null;Cn(t);try{t.getAttribute("src")&&(t.pause(),t.removeAttribute("src"),t.load())}catch{}const r=pi(i,a);return r.bindToVideoElement(t),Re.set(t,r),t.__demoController=r,r}function Cn(t){if(!t)return;const i=Re.get(t)||t.__demoController;i&&(i.destroy(),Re.delete(t));try{t.parentElement&&t.parentElement.querySelectorAll(".vp-demo-canvas").forEach(a=>a.remove())}catch{}}function ce(t){return t&&(Re.get(t)||t.__demoController)||null}function Be(t){return!!ce(t)}const gi=.35,vi=.65,bi=6,fi=8,hi=6,yi=1.2,En=5,wi=280,Si=40,Te=700;function we(t){const i=Number(t);return Number.isFinite(i)?Math.max(0,Math.min(100,Math.round(i))):0}function Ei(t,i={}){if(!t)return{destroy(){},getZoneAt(){return"center"}};const a=new Map;let r=null,n={zone:null,time:0,x:0,y:0};function c(w){const D=a.get(w);D&&(clearTimeout(D),a.delete(w))}function e(w,D,B={},$=0){var S;if(c(w),(S=i.onGestureHud)==null||S.call(i,w,!0,D,B),$>0){const E=setTimeout(()=>{var M;a.delete(w),(M=i.onGestureHud)==null||M.call(i,w,!1,D,{...B,ended:!0})},$);a.set(w,E)}}function s(){return t.getBoundingClientRect()}function l(w){const D=s(),B=Math.max(1,D.width),$=(w-D.left)/B;return $<gi?"left":$>vi?"right":"center"}function m(w,D){const $={left:".vp-zone-left",center:".vp-zone-center",right:".vp-zone-right"}[w];if(!$)return;const S=t.querySelector($);S&&S.classList.toggle("is-active",!!D)}function p(){t.querySelectorAll(".vp-zone-left, .vp-zone-center, .vp-zone-right").forEach(D=>D.classList.remove("is-active"))}function h(){var D;const w=(D=i.getBrightness)==null?void 0:D.call(i);return Number.isFinite(Number(w))?we(w):85}function g(){var D;const w=(D=i.getVolume)==null?void 0:D.call(i);return Number.isFinite(Number(w))?we(w):80}function y(w){if(w.pointerType==="mouse"&&w.button!==0||w.target&&typeof w.target.closest=="function"&&w.target.closest("button, input, a, select, textarea"))return;const D=s(),B=l(w.clientX),$=B==="left"?h():B==="right"?g():null;r={pointerId:w.pointerId,pointerType:w.pointerType,zone:B,startX:w.clientX,startY:w.clientY,lastX:w.clientX,lastY:w.clientY,stageHeight:Math.max(160,D.height),startValue:$,currentValue:$,isDragging:!1,maxDistance:0,downTime:performance.now()},m(B,!0)}function T(w){var S,E,M;if(!r||w.pointerId!==r.pointerId)return;const D=w.clientX-r.startX,B=w.clientY-r.startY,$=Math.hypot(D,B);if($>r.maxDistance&&(r.maxDistance=$),r.lastX=w.clientX,r.lastY=w.clientY,r.zone==="left"||r.zone==="right"){if(!r.isDragging){const F=Math.abs(D),I=Math.abs(B);if(I>=bi&&I>=F*.75){r.isDragging=!0;try{(S=t.setPointerCapture)==null||S.call(t,w.pointerId)}catch{}}}if(r.isDragging){w.cancelable&&w.preventDefault();const F=s(),I=Math.max(160,F.height||r.stageHeight),G=-B/I*100*yi,W=we(r.startValue+G);if(r.currentValue=W,r.zone==="left"){const H={source:"gesture-left-swipe",zone:"left",deltaPct:Number(G.toFixed(2)),dy:B,dragging:!0};(E=i.setBrightness)==null||E.call(i,W,H),e("brightness",W,H,0)}else{const H={source:"gesture-right-swipe",zone:"right",deltaPct:Number(G.toFixed(2)),dy:B,dragging:!0};(M=i.setVolume)==null||M.call(i,W,H),e("volume",W,H,0)}}}}function k(w,D=!1){var E,M,F;if(!r||w.pointerId!==r.pointerId)return;const B=r;r=null,m(B.zone,!1);try{(E=t.hasPointerCapture)!=null&&E.call(t,w.pointerId)&&t.releasePointerCapture(w.pointerId)}catch{}if(D){if(B.isDragging){const I=B.zone==="left"?"brightness":"volume";e(I,B.currentValue,{zone:B.zone,dragging:!1},Te)}return}if(B.isDragging){const I=B.zone==="left"?"brightness":"volume",G=B.zone==="left"?h():g();e(I,G,{zone:B.zone,source:B.zone==="left"?"gesture-left-swipe":"gesture-right-swipe",dragging:!1},Te);return}const $=Math.hypot(w.clientX-B.startX,w.clientY-B.startY),S=Math.max($,B.maxDistance);if(B.zone==="center"&&S<fi){(M=i.onTogglePlayPause)==null||M.call(i,"center-tap"),e("play-pause",null,{zone:"center",source:"center-tap"},550);return}if((B.zone==="left"||B.zone==="right")&&S<hi){const I=performance.now(),G=I-n.time,W=Math.hypot(w.clientX-n.x,w.clientY-n.y);if(n.zone===B.zone&&G>0&&G<=wi&&W<=Si){const H=B.zone==="left"?-10:10;n={zone:null,time:0,x:0,y:0},(F=i.onDoubleTapSeek)==null||F.call(i,H,B.zone),e("seek",H,{zone:B.zone,side:B.zone,deltaSec:H},650)}else n={zone:B.zone,time:I,x:w.clientX,y:w.clientY}}}function C(w){k(w,!1)}function N(w){k(w,!0)}function R(w){var $,S;const D=l(w.clientX);if(D!=="left"&&D!=="right")return;w.cancelable&&w.preventDefault();const B=w.deltaY<0?En:-En;if(D==="left"){const E=we(h()+B),M={source:"wheel-left",zone:"left",step:B};($=i.setBrightness)==null||$.call(i,E,M),e("brightness",E,M,Te)}else if(D==="right"){const E=we(g()+B),M={source:"wheel-right",zone:"right",step:B};(S=i.setVolume)==null||S.call(i,E,M),e("volume",E,M,Te)}}function V(w){r!=null&&r.isDragging&&w.preventDefault()}return t.addEventListener("pointerdown",y),t.addEventListener("pointermove",T),t.addEventListener("pointerup",C),t.addEventListener("pointercancel",N),t.addEventListener("wheel",R,{passive:!1}),t.addEventListener("contextmenu",V),{getZoneAt:l,destroy(){a.forEach(w=>clearTimeout(w)),a.clear(),p(),t.removeEventListener("pointerdown",y),t.removeEventListener("pointermove",T),t.removeEventListener("pointerup",C),t.removeEventListener("pointercancel",N),t.removeEventListener("wheel",R),t.removeEventListener("contextmenu",V)}}}function $e(t){const i=Number(t);return Number.isFinite(i)?(Math.round(i/90)*90%360+360)%360:0}function Pi(t,i){if(!t||!i)return"16:9";const a=t/i;return Math.abs(a-16/9)<.08?"16:9":Math.abs(a-9/16)<.05?"9:16":Math.abs(a-21/9)<.12?"21:9":Math.abs(a-4/3)<.06?"4:3":Math.abs(a-3/4)<.06?"3:4":Math.abs(a-1)<.05?"1:1":`${a.toFixed(2)}:1`}function Bi(t={}){const{stageEl:i,rotatorEl:a,videoEl:r,onUpdate:n}=t,c=t.initialAutoRotate!==void 0?!!t.initialAutoRotate:t.autoRotate!==void 0?!!t.autoRotate:!0,e=$e(t.initialManualRotation!==void 0?t.initialManualRotation:t.manualRotation!==void 0?t.manualRotation:0);let s={width:0,height:0,preferOverride:!1},l={autoRotate:c,manualRotation:e,effectiveRotation:e,rotation:e,isAutoRotated:!1,isQuarterTurn:e===90||e===270,scale:1,stageWidth:1280,stageHeight:720,videoWidth:1280,videoHeight:720,targetWidth:1280,targetHeight:720,fitW0:1280,fitH0:720,area0:1280*720,fitW90:405,fitH90:720,area90:405*720,areaGainRatio:1,coveragePercent:100,simulateViewport:t.simulateViewport||"none",videoAspectLabel:"16:9",stageOrientation:"landscape"},m=null,p=[];function h(){p.forEach(E=>clearTimeout(E)),p=[]}function g(){const E=Number(r==null?void 0:r.videoWidth)||0,M=Number(r==null?void 0:r.videoHeight)||0;return s.preferOverride&&s.width>0&&s.height>0?{vw:s.width,vh:s.height}:E>0&&M>0?{vw:E,vh:M}:s.width>0&&s.height>0?{vw:s.width,vh:s.height}:{vw:1280,vh:720}}function y(){if(!i)return{W:1280,H:720};let E=i.clientWidth,M=i.clientHeight;if(!E||!M){const F=i.getBoundingClientRect();E=Math.round(F.width),M=Math.round(F.height)}return{W:Math.max(1,E||1280),H:Math.max(1,M||720)}}function T(){const{W:E,H:M}=y(),{vw:F,vh:I}=g(),G=Math.min(E/F,M/I),W=Math.max(1,Math.floor(F*G)),H=Math.max(1,Math.floor(I*G)),K=W*H,J=Math.min(M/F,E/I),se=Math.max(1,Math.floor(F*J)),le=Math.max(1,Math.floor(I*J)),U=se*le;let Y=l.manualRotation,L=!1;l.autoRotate&&(U>K*1.04?(Y=(l.manualRotation+90)%360,L=!0):Y=l.manualRotation);const b=Y===90||Y===270,O=b?se:W,Z=b?le:H,ae=O*Z,re=Math.max(1,E*M);return a&&(a.style.width=`${O}px`,a.style.height=`${Z}px`,a.style.transform=`rotate(${Y}deg) scale(1)`,a.dataset.rotation=String(Y),a.dataset.autoRotated=String(L),a.dataset.scale="1"),l={...l,effectiveRotation:Y,rotation:Y,isAutoRotated:L,isQuarterTurn:b,scale:1,stageWidth:E,stageHeight:M,videoWidth:F,videoHeight:I,targetWidth:O,targetHeight:Z,fitW0:W,fitH0:H,area0:K,fitW90:se,fitH90:le,area90:U,areaGainRatio:K>0?Number((ae/K).toFixed(2)):1,coveragePercent:Number(Math.min(100,ae/re*100).toFixed(1)),videoAspectLabel:Pi(F,I),stageOrientation:E>=M?"landscape":"portrait"},n==null||n({...l}),{...l}}function k(){m!==null&&cancelAnimationFrame(m),m=requestAnimationFrame(()=>{m=null,T()})}function C(E){return l.autoRotate=!!E,T()}function N(){return l.autoRotate=!l.autoRotate,T()}function R(E){return l.manualRotation=$e(E),T()}function V(E=90){return l.manualRotation=$e(l.manualRotation+Number(E||0)),T()}function w(E,M){const F=Number(E)||0,I=Number(M)||0;return F>0&&I>0?s={width:Math.round(F),height:Math.round(I),preferOverride:!0}:s={width:0,height:0,preferOverride:!1},T()}function D(E="none"){const M=E==="portrait"||E==="landscape"?E:"none";l.simulateViewport=M;const F=i==null?void 0:i.parentElement;F&&(F.classList.toggle("sim-portrait",M==="portrait"),F.classList.toggle("sim-landscape",M==="landscape"));const I=T();return h(),p.push(setTimeout(()=>T(),60),setTimeout(()=>T(),180),setTimeout(()=>T(),320)),I}function B(){const E=Number(r==null?void 0:r.videoWidth)||0,M=Number(r==null?void 0:r.videoHeight)||0;E>0&&M>0&&(s={width:E,height:M,preferOverride:!1}),T()}function $(){var F,I,G,W,H,K;const{vw:E,vh:M}=g();if(document.fullscreenElement&&l.autoRotate){const J=E>=M?"landscape":"portrait";try{(W=(G=(I=(F=screen.orientation)==null?void 0:F.lock)==null?void 0:I.call(F,J))==null?void 0:G.catch)==null||W.call(G,()=>{})}catch{}}else if(!document.fullscreenElement)try{(K=(H=screen.orientation)==null?void 0:H.unlock)==null||K.call(H)}catch{}k(),h(),p.push(setTimeout(()=>T(),120))}let S=null;return typeof ResizeObserver<"u"&&i&&(S=new ResizeObserver(()=>{k()}),S.observe(i),i.parentElement&&S.observe(i.parentElement)),window.addEventListener("resize",k),window.addEventListener("orientationchange",k),document.addEventListener("fullscreenchange",$),r&&(r.addEventListener("loadedmetadata",B),r.addEventListener("resize",B)),T(),{recalculate:T,setAutoRotate:C,toggleAutoRotate:N,setManualRotation:R,rotateBy:V,setIntrinsicSize:w,setSimulateViewport:D,getState(){return{...l}},destroy(){m!==null&&(cancelAnimationFrame(m),m=null),h(),S&&(S.disconnect(),S=null),window.removeEventListener("resize",k),window.removeEventListener("orientationchange",k),document.removeEventListener("fullscreenchange",$),r&&(r.removeEventListener("loadedmetadata",B),r.removeEventListener("resize",B))}}}const _={BRIGHTNESS:"vp_brightness",BRIGHTNESS_META:"vp_brightness_meta",HW_DECODE:"vp_hw_decode",POWER_SAVE:"vp_power_save",ARROW_SWITCH_MODE:"vp_arrow_switch_mode",LAST_DIR_PATH:"vp_last_dir_path",GESTURE_SENSITIVITY:"vp_gesture_sensitivity",REMEMBER_RESUME:"vp_remember_resume",SETTINGS:"vp_settings_v1",RESUME_MAP:"vp_resume_map"},ne={brightness:85,volume:80,muted:!1,autoRotate:!0,manualRotation:0,playbackRate:1,eqPreset:"flat",eqCustom:{bass:0,mid:0,treble:0,boost:1},showGestureGuide:!0,loopMode:"all",simPortrait:!1,hwDecodeEnabled:!0,powerSaveEnabled:!0,arrowKeySwitchMode:!0,gestureSensitivity:1.2,rememberResumePosition:!0,lastDirectoryPath:"",lastVideoId:"demo-cinema-16-9"};function kn(t){const i=Number(t);return Number.isFinite(i)?Math.max(0,Math.min(100,Math.round(i))):ne.brightness}function Vn(t){const i=Number(t);return Number.isFinite(i)?Math.max(0,Math.min(100,Math.round(i))):ne.volume}function qe(){try{const t=localStorage.getItem(_.BRIGHTNESS);if(t!==null&&t.trim()!==""){const a=Number(t);if(Number.isFinite(a)&&a>=0&&a<=100)return Math.round(a)}if(typeof window<"u"&&window.AndroidPlayerBridge&&typeof window.AndroidPlayerBridge.getSavedBrightness=="function"){const a=Number(window.AndroidPlayerBridge.getSavedBrightness());if(Number.isFinite(a)&&a>=0&&a<=100){const r=Math.round(a);return localStorage.setItem(_.BRIGHTNESS,String(r)),r}}const i=localStorage.getItem(_.SETTINGS);if(i){const a=JSON.parse(i);if(a&&typeof a.brightness=="number"&&Number.isFinite(a.brightness)&&a.brightness>=0&&a.brightness<=100){const r=Math.round(a.brightness);return localStorage.setItem(_.BRIGHTNESS,String(r)),r}}}catch(t){console.warn("[OmniPlay Storage] Failed to read saved brightness:",t)}try{localStorage.setItem(_.BRIGHTNESS,String(ne.brightness))}catch{}return ne.brightness}function Ti(){try{const t=localStorage.getItem(_.BRIGHTNESS);if(t===null||t.trim()==="")return!1;const i=Number(t);return Number.isFinite(i)&&i>=0&&i<=100}catch{return!1}}function Dn(t,i="user"){const a=kn(t);try{localStorage.setItem(_.BRIGHTNESS,String(a)),localStorage.setItem(_.BRIGHTNESS_META,JSON.stringify({value:a,source:i,updatedAt:new Date().toISOString()}));const r=localStorage.getItem(_.SETTINGS),n=r?JSON.parse(r):{...ne};n.brightness=a,localStorage.setItem(_.SETTINGS,JSON.stringify(n)),typeof window<"u"&&window.AndroidPlayerBridge&&typeof window.AndroidPlayerBridge.setScreenBrightness=="function"&&window.AndroidPlayerBridge.setScreenBrightness(a)}catch(r){console.warn("[OmniPlay Storage] Failed to save brightness:",r)}return a}function $n(){const t=qe();try{const i=localStorage.getItem(_.SETTINGS);if(!i){const n={...ne,brightness:t};return localStorage.setItem(_.SETTINGS,JSON.stringify(n)),n}const a=JSON.parse(i);return{...ne,...a,brightness:t,volume:Vn((a==null?void 0:a.volume)??ne.volume),muted:!!((a==null?void 0:a.muted)??ne.muted),autoRotate:typeof(a==null?void 0:a.autoRotate)=="boolean"?a.autoRotate:ne.autoRotate,manualRotation:[0,90,180,270].includes(Number(a==null?void 0:a.manualRotation))?Number(a.manualRotation):0,playbackRate:Number.isFinite(Number(a==null?void 0:a.playbackRate))&&Number(a.playbackRate)>=.25&&Number(a.playbackRate)<=4?Number(a.playbackRate):1,eqPreset:typeof(a==null?void 0:a.eqPreset)=="string"?a.eqPreset:"flat",eqCustom:{...ne.eqCustom,...(a==null?void 0:a.eqCustom)||{}},showGestureGuide:typeof(a==null?void 0:a.showGestureGuide)=="boolean"?a.showGestureGuide:ne.showGestureGuide,hwDecodeEnabled:localStorage.getItem(_.HW_DECODE)!==null?localStorage.getItem(_.HW_DECODE)!=="false":typeof(a==null?void 0:a.hwDecodeEnabled)=="boolean"?a.hwDecodeEnabled:!0,powerSaveEnabled:localStorage.getItem(_.POWER_SAVE)!==null?localStorage.getItem(_.POWER_SAVE)!=="false":typeof(a==null?void 0:a.powerSaveEnabled)=="boolean"?a.powerSaveEnabled:!0,arrowKeySwitchMode:localStorage.getItem(_.ARROW_SWITCH_MODE)!==null?localStorage.getItem(_.ARROW_SWITCH_MODE)!=="false":typeof(a==null?void 0:a.arrowKeySwitchMode)=="boolean"?a.arrowKeySwitchMode:!0,lastDirectoryPath:localStorage.getItem(_.LAST_DIR_PATH)||(typeof(a==null?void 0:a.lastDirectoryPath)=="string"?a.lastDirectoryPath:""),gestureSensitivity:[.8,1,1.2,1.5].includes(Number(localStorage.getItem(_.GESTURE_SENSITIVITY)??(a==null?void 0:a.gestureSensitivity)))?Number(localStorage.getItem(_.GESTURE_SENSITIVITY)??(a==null?void 0:a.gestureSensitivity)):1.2,rememberResumePosition:localStorage.getItem(_.REMEMBER_RESUME)!==null?localStorage.getItem(_.REMEMBER_RESUME)!=="false":typeof(a==null?void 0:a.rememberResumePosition)=="boolean"?a.rememberResumePosition:!0}}catch(i){return console.warn("[OmniPlay Storage] Failed to load settings, using defaults:",i),{...ne,brightness:t}}}function ee(t={}){try{const a={...$n(),...t};if(t.brightness!==void 0&&(a.brightness=kn(t.brightness),localStorage.setItem(_.BRIGHTNESS,String(a.brightness))),t.volume!==void 0&&(a.volume=Vn(t.volume)),t.hwDecodeEnabled!==void 0&&(a.hwDecodeEnabled=!!t.hwDecodeEnabled,localStorage.setItem(_.HW_DECODE,String(a.hwDecodeEnabled))),t.powerSaveEnabled!==void 0&&(a.powerSaveEnabled=!!t.powerSaveEnabled,localStorage.setItem(_.POWER_SAVE,String(a.powerSaveEnabled))),t.arrowKeySwitchMode!==void 0&&(a.arrowKeySwitchMode=!!t.arrowKeySwitchMode,localStorage.setItem(_.ARROW_SWITCH_MODE,String(a.arrowKeySwitchMode))),t.lastDirectoryPath!==void 0&&(a.lastDirectoryPath=String(t.lastDirectoryPath||""),localStorage.setItem(_.LAST_DIR_PATH,a.lastDirectoryPath)),t.gestureSensitivity!==void 0){const r=Number(t.gestureSensitivity);a.gestureSensitivity=[.8,1,1.2,1.5].includes(r)?r:1.2,localStorage.setItem(_.GESTURE_SENSITIVITY,String(a.gestureSensitivity))}return t.rememberResumePosition!==void 0&&(a.rememberResumePosition=!!t.rememberResumePosition,localStorage.setItem(_.REMEMBER_RESUME,String(a.rememberResumePosition))),localStorage.setItem(_.SETTINGS,JSON.stringify(a)),a}catch(i){return console.warn("[OmniPlay Storage] Failed to save settings:",i),{...ne,...t}}}function Ai(){try{return Dn(ne.brightness,"factory-reset"),ee({...ne})}catch{return{...ne}}}function xn(){try{const t=localStorage.getItem(_.RESUME_MAP);if(!t)return{};const i=JSON.parse(t);return i&&typeof i=="object"?i:{}}catch{return{}}}function Ii(t){if(!t)return 0;const a=xn()[t];return!a||typeof a.time!="number"||!Number.isFinite(a.time)?0:Math.max(0,a.time)}function Pn(t,i,a=0){if(!(!t||!Number.isFinite(i)))try{const r=xn(),n=a>5&&i>=a*.97?0:Math.max(0,Math.round(i*10)/10);r[t]={time:n,duration:Number.isFinite(a)?Math.round(a*10)/10:0,updatedAt:Date.now()},localStorage.setItem(_.RESUME_MAP,JSON.stringify(r))}catch{}}function Mi(t,i={}){let a=null,r=null,n=null,c=null,e=null,s=null,l=null,m=null;const p={preset:i.preset||"flat",bass:Number.isFinite(i.bass)?i.bass:0,mid:Number.isFinite(i.mid)?i.mid:0,treble:Number.isFinite(i.treble)?i.treble:0,boost:Number.isFinite(i.boost)?i.boost:1,connected:!1};function h(S){const E=Number(S);return Number.isFinite(E)?Math.max(-12,Math.min(12,Math.round(E*10)/10)):0}function g(S){const E=Number(S);return Number.isFinite(E)?Math.max(.5,Math.min(2,Math.round(E*100)/100)):1}function y(){if(a)return!0;const S=window.AudioContext||window.webkitAudioContext;if(!S)return!1;try{return a=new S,e=a.createBiquadFilter(),e.type="lowshelf",e.frequency.value=100,e.gain.value=p.bass,s=a.createBiquadFilter(),s.type="peaking",s.frequency.value=1e3,s.Q.value=1,s.gain.value=p.mid,l=a.createBiquadFilter(),l.type="highshelf",l.frequency.value=8e3,l.gain.value=p.treble,m=a.createGain(),m.gain.value=p.boost,e.connect(s),s.connect(l),l.connect(m),m.connect(a.destination),!0}catch(E){return console.warn("[OmniPlay EQ] AudioContext creation skipped:",E),!1}}function T(){if(t&&y())try{if(a&&a.state==="suspended"&&a.resume().catch(()=>{}),!t.srcObject&&t.currentSrc&&!r&&(r=a.createMediaElementSource(t),r.connect(e),p.connected=!0),t.srcObject&&r&&c!==t.srcObject){if(n){try{n.disconnect()}catch{}n=null}(typeof t.srcObject.getAudioTracks=="function"?t.srcObject.getAudioTracks():[]).length>0&&(n=a.createMediaStreamSource(t.srcObject),n.connect(e),c=t.srcObject,p.connected=!0)}}catch(S){console.debug("[OmniPlay EQ] Source routing fallback:",(S==null?void 0:S.message)||S)}}function k(){if(!a)return;const S=a.currentTime||0;try{e&&e.gain.setTargetAtTime(p.bass,S,.015),s&&s.gain.setTargetAtTime(p.mid,S,.015),l&&l.gain.setTargetAtTime(p.treble,S,.015),m&&m.gain.setTargetAtTime(p.boost,S,.015)}catch{e&&(e.gain.value=p.bass),s&&(s.gain.value=p.mid),l&&(l.gain.value=p.treble),m&&(m.gain.value=p.boost)}}function C(S){return S&&(p.preset=S.id||"custom",p.bass=h(S.bass??0),p.mid=h(S.mid??0),p.treble=h(S.treble??0),p.boost=g(S.boost??1),y(),T(),k()),B()}function N({preset:S="custom",bass:E,mid:M,treble:F,boost:I}){return p.preset=S,E!==void 0&&(p.bass=h(E)),M!==void 0&&(p.mid=h(M)),F!==void 0&&(p.treble=h(F)),I!==void 0&&(p.boost=g(I)),y(),T(),k(),B()}function R(S,E){const M=h(E);return(S==="bass"||S==="mid"||S==="treble")&&(p[S]=M,p.preset="custom",y(),T(),k()),B()}function V(S){return p.boost=g(S),p.preset="custom",y(),T(),k(),B()}function w(){return N({preset:"flat",bass:0,mid:0,treble:0,boost:1})}function D(){a&&a.state==="suspended"&&a.resume().catch(()=>{})}function B(){return{...p}}function $(){try{n&&n.disconnect(),r&&r.disconnect(),a&&a.state!=="closed"&&a.close().catch(()=>{})}catch{}}return{setPreset:C,setValues:N,setBand:R,setBoost:V,reset:w,syncSource:T,resume:D,getState:B,destroy:$}}const Ri=[".mp4",".webm",".mkv",".mov",".avi",".m4v",".ogg",".ogv",".ts",".flv",".wmv"],Li=[".srt",".vtt"],Ci=new Intl.Collator(void 0,{numeric:!0,sensitivity:"base"});function Nn(t,i){return Ci.compare(String(t||""),String(i||""))}function ze(t=""){const i=String(t).toLowerCase();return Ri.some(a=>i.endsWith(a))}function Ue(t=""){const i=String(t).toLowerCase();return Li.some(a=>i.endsWith(a))}function Bn(t=""){const i=t.lastIndexOf(".");return i>0?t.slice(0,i):t}function On(t=0){const i=Number(t)||0;return i<=0?"":`${(i/(1024*1024)).toFixed(2)} MB`}function ki(t=""){if(!t)return"同目錄資料夾";const i=String(t).replace(/\\/g,"/").replace(/\/+$/,""),a=i.split("/").filter(Boolean);return a[a.length-1]||i||"同目錄資料夾"}async function Vi(t,i=""){if(!t||!t.name)return{found:!1,items:[],currentIndex:0};try{const a=new URLSearchParams({name:t.name,size:String(t.size||0),mtime:String(t.lastModified||0)});i&&a.set("dir",i);const r=await fetch(`/api/dir-siblings?${a.toString()}`,{headers:{Accept:"application/json"}});if(!r.ok)return{found:!1,items:[],currentIndex:0};const n=await r.json();if(!n||!n.found||!Array.isArray(n.files)||n.files.length===0)return{found:!1,items:[],currentIndex:0};const c=n.directory||"",e=ki(c),s=[...n.files].sort((h,g)=>Nn(h.name,g.name)),l=s.length;let m=s.findIndex(h=>h.name===t.name&&Number(h.size)===Number(t.size));m===-1&&(m=s.findIndex(h=>h.name.toLowerCase()===t.name.toLowerCase())),m===-1&&(m=0);const p=s.map((h,g)=>{const y=On(h.size),T=h.streamUrl||`/api/stream-file?path=${encodeURIComponent(h.path||"")}`;return{id:`dir-${c}-${h.name}-${h.size||0}`,title:h.name,subtitle:`📁 ${e} (${g+1}/${l})${y?` • ${y}`:""}`,url:T,streamUrl:T,fullPath:h.path||"",directoryPath:c,directoryName:e,size:h.size||0,mtime:h.mtime||0,aspectLabel:`${g+1}/${l}`,isDemo:!1,isSameDir:!0,dirIndex:g,dirTotal:l}});return{found:!0,directoryPath:c,directoryName:e,total:l,currentIndex:m,items:p}}catch(a){return console.debug("[OmniPlay DirPlaylist] Backend sibling discovery skipped:",a),{found:!1,items:[],currentIndex:0}}}function Fn(t=[],i="",a=""){var h;const r=Array.from(t||[]),n=[],c=[];for(const g of r)!g||!g.name||(Ue(g.name)?c.push(g):((h=g.type)!=null&&h.startsWith("video/")||ze(g.name))&&n.push(g));n.sort((g,y)=>Nn(g.name,y.name));let e=a||"本機同目錄片單";if(!a&&n.length>0){const g=n[0].webkitRelativePath||"";g&&g.includes("/")&&(e=g.split("/")[0]||e)}const s=new Map;for(const g of c){const y=Bn(g.name).toLowerCase();s.set(y,g)}const l=n.length,m=n.map((g,y)=>{const T=URL.createObjectURL(g),k=On(g.size),C=Bn(g.name).toLowerCase(),N=s.get(C)||c.find(R=>R.name.toLowerCase().startsWith(`${C}.`))||null;return{id:`local-${e}-${g.name}-${g.size||0}`,title:g.name,subtitle:`📁 ${e} (${y+1}/${l})${k?` • ${k}`:""}`,url:T,file:g,pairedSubtitleFile:N,directoryName:e,directoryPath:e,size:g.size||0,mtime:g.lastModified||0,aspectLabel:`${y+1}/${l}`,isDemo:!1,isSameDir:!0,dirIndex:y,dirTotal:l}});let p=0;if(i){const g=m.findIndex(y=>y.title.toLowerCase()===i.toLowerCase());g!==-1&&(p=g)}return{directoryName:e,total:l,currentIndex:p,items:m,subtitleFiles:c}}async function Di(){if(typeof window>"u"||typeof window.showDirectoryPicker!="function")return{supported:!1};try{const t=await window.showDirectoryPicker({mode:"read"}),i=[];for await(const[r,n]of t.entries())if(n.kind==="file"&&(ze(r)||Ue(r)))try{const c=await n.getFile();i.push(c)}catch{}return{supported:!0,cancelled:!1,...Fn(i,"",t.name||"已選取資料夾")}}catch(t){return t&&t.name==="AbortError"?{supported:!0,cancelled:!0,items:[]}:{supported:!1}}}async function _n(t,i=2,a=0){if(!t)return[];if(t.isFile)return new Promise(r=>{t.file(n=>r([n]),()=>r([]))});if(t.isDirectory&&a<i){const r=t.createReader(),n=[],c=()=>new Promise(s=>{r.readEntries(async l=>{!l||l.length===0||(n.push(...l),await c()),s()},()=>s())});return await c(),(await Promise.all(n.map(s=>_n(s,i,a+1)))).flat()}return[]}async function $i(t){if(!t)return{folderName:"",files:[]};const a=Array.from(t.items||[]).map(r=>typeof r.webkitGetAsEntry=="function"?r.webkitGetAsEntry():null).filter(Boolean);if(a.length>0&&a.some(r=>r.isDirectory)){const r=a.find(e=>e.isDirectory),n=r?r.name:"拖曳資料夾",c=await Promise.all(a.map(e=>_n(e,2,0)));return{folderName:n,files:c.flat()}}return{folderName:"",files:Array.from(t.files||[])}}function ve(t){if(!Number.isFinite(t)||t<0)return"00:00";const i=Math.floor(t),a=Math.floor(i/3600),r=Math.floor(i%3600/60),n=i%60;return a>0?`${a}:${String(r).padStart(2,"0")}:${String(n).padStart(2,"0")}`:`${String(r).padStart(2,"0")}:${String(n).padStart(2,"0")}`}function Tn(t){if(!t||typeof t!="string")return[];const i=[],a=t.replace(/\r\n/g,`
`).replace(/\r/g,`
`).split(/\n\s*\n/),r=/(?:(\d{1,2}):)?(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(?:(\d{1,2}):)?(\d{2}):(\d{2})[.,](\d{3})/;for(const n of a){const c=n.split(`
`).map(h=>h.trim()).filter(Boolean);if(c.length===0||c[0].startsWith("WEBVTT"))continue;let e=-1;for(let h=0;h<Math.min(c.length,3);h++)if(r.test(c[h])){e=h;break}if(e===-1)continue;const s=c[e].match(r);if(!s)continue;const l=Number(s[1]||0)*3600+Number(s[2])*60+Number(s[3])+Number(s[4])/1e3,m=Number(s[5]||0)*3600+Number(s[6])*60+Number(s[7])+Number(s[8])/1e3,p=c.slice(e+1).join(" ").replace(/<[^>]+>/g,"").trim();p&&m>l&&i.push({start:l,end:m,text:p})}return i}function An(){var je,Ze,Qe,Ye,Xe,Je,et,tt,nt,it,ot,at,rt,st,lt,dt,ct,ut,pt,mt,gt,vt,bt,ft,ht,yt,wt,St,Et,Pt,Bt,Tt,At,It,Mt,Rt,Lt,Ct,kt,Vt,Dt,$t,xt,Nt,Ot,Ft,_t,Ht,qt,Gt,zt,Ut,Wt,Kt,jt,Zt,Qt,Yt,Xt,Jt,en,tn,nn,on,an,rn,sn,ln,dn,cn,un,pn;const t=document.getElementById("app");if(!t)return;const i=Ti(),a=$n(),r=qe(),n={playlist:[...vn],currentIndex:0,directoryName:"內建比例測試目錄",directoryPath:"內建 4 組多比例幾何測試串流 (16:9 / 9:16 / 21:9 / 4:3)",brightness:r,brightnessRestored:i,volume:a.volume,muted:a.muted,autoRotate:a.autoRotate,manualRotation:a.manualRotation,simPortrait:!!a.simPortrait,playbackRate:a.playbackRate,loopMode:a.loopMode||"all",showGestureGuide:a.showGestureGuide,hwDecodeEnabled:a.hwDecodeEnabled!==!1,powerSaveEnabled:a.powerSaveEnabled!==!1,arrowKeySwitchMode:a.arrowKeySwitchMode!==!1,gestureSensitivity:Number(a.gestureSensitivity)||1.2,rememberResumePosition:a.rememberResumePosition!==!1,lastDirectoryPath:a.lastDirectoryPath||"",eqPreset:a.eqPreset||"flat",eqCustom:{...a.eqCustom},activeDrawer:null,activeModal:null,subtitlesEnabled:!0,customSubtitles:null,customSubtitleName:"",abLoop:{a:null,b:null},isScrubbing:!1},c=n.playlist.findIndex(o=>o.id===a.lastVideoId);c!==-1&&(n.currentIndex=c),t.innerHTML=`
    <div class="vp-app" id="vpApp">
      <!-- Top Navigation & Telemetry Bar -->
      <header class="vp-topbar">
        <div class="vp-topbar-left">
          <div class="vp-logo" title="OmniPlay Pro 旗艦影音引擎">▶</div>
          <div class="vp-title-group">
            <div class="vp-brand-name">OmniPlay Pro • Lossless Scale(1) &amp; Hardware Eco Engine</div>
            <div class="vp-video-title-row">
              <h1 class="vp-video-title" id="vpVideoTitle">載入中...</h1>
              <span class="vp-aspect-badge" id="vpAspectBadge">16:9</span>
            </div>
          </div>
        </div>

        <!-- Live Telemetry Pills -->
        <div class="vp-status-bar">
          <div class="vp-status-pill vp-pill-dir vp-dir-pill" data-pill="dir" id="vpDirPill" title="點擊開啟同目錄片單（可按 ⏮/⏭、PageUp/PageDown、P/N 或 ←/→ 前後鍵換片）" style="cursor:pointer;">
            <span>${te==null?void 0:te.sameDirBadgePrefix}:</span>
            <strong id="vpDirPillVal">1/${n.playlist.length} (${n.directoryName})</strong>
          </div>

          <div class="vp-status-pill vp-pill-brightness" data-pill="brightness" id="vpBrightnessPill" title="左側上下滑動調整亮度（自動記憶於 localStorage）">
            <span>☀️ 亮度:</span>
            <strong id="vpBrightnessPillVal">${n.brightness}%</strong>
            <span class="vp-memory-tag" id="vpBrightnessMemoryTag">${n.brightnessRestored?"已還原記憶":"已記憶"}</span>
          </div>

          <div class="vp-status-pill vp-pill-volume" data-pill="volume" id="vpVolumePill" title="右側上下滑動調整音量">
            <span id="vpVolumePillIcon">🔊</span>
            <span>音量:</span>
            <strong id="vpVolumePillVal">${n.muted?"靜音":`${n.volume}%`}</strong>
          </div>

          <div class="vp-status-pill vp-pill-orientation" data-pill="orientation" id="vpOrientationPill" title="自動偵測視窗與影片比例，旋轉最大化且固定 Scale(1) 零裁切">
            <span>🔄 自動轉向:</span>
            <strong id="vpOrientationPillVal">開啟 | 旋轉: 0° | Scale: 1.00x 無損最大化</strong>
          </div>

          <div class="vp-status-pill vp-pill-hw" data-pill="hw-power" id="vpHwPowerPill" title="硬體解碼與智慧節電狀態（點擊開啟詳細面板）" style="cursor:pointer;">
            <strong id="vpHwPowerPillVal">⚡ 硬體解碼 • 🍃 節電中</strong>
          </div>
        </div>

        <!-- Quick Action Buttons + LIFE-Style P2R-OTA Controls -->
        <div class="vp-top-actions">
          ${Wn()}

          <button type="button" class="vp-btn vp-btn-primary" id="btnDrawerSettings" title="開啟系統與播放設定中心 (含 P2R-OTA 雲端熱更新、手勢、轉向與硬體節電設定)">
            <span>⚙️ 設定</span>
          </button>
          <button type="button" class="vp-btn vp-btn-primary" id="btnOpenFile" title="開啟單一或多部本機影片檔，並自動掃描同目錄所有影片以供前後鍵換片！">
            <span>📂 ${te==null?void 0:te.openFileBtn}</span>
          </button>
          <button type="button" class="vp-btn" id="btnOpenFolder" title="選擇整個資料夾，自動依檔名自然排序 (1, 2...10) 建立同目錄連播清單">
            <span>${te==null?void 0:te.openFolderBtn}</span>
          </button>
          <button type="button" class="vp-btn ${n.arrowKeySwitchMode?"is-active":""}" id="btnArrowSwitchMode" title="開啟後可直接按鍵盤 ← / → 左右方向鍵切換同目錄上一片 / 下一片">
            <span>⏮/⏭ ${te==null?void 0:te.arrowKeySwitchToggle}</span>
          </button>
          <button type="button" class="vp-btn ${n.autoRotate?"is-active":""}" id="btnAutoRotate" title="開啟/關閉自動轉向無損最大化 (快捷鍵 A)">
            <span>🔄 自動轉向</span>
          </button>
          <button type="button" class="vp-btn" id="btnRotate90" title="手動順時針旋轉 90° (快捷鍵 R)">
            <span>↪️ 旋轉 90°</span>
          </button>
          <button type="button" class="vp-btn ${n.simPortrait?"is-active":""}" id="btnSimPortrait" title="模擬手機 9:16 直向視窗框體，立即測試 16:9 影片自動旋轉 90° 無損滿版！">
            <span>📱 模擬直向視窗</span>
          </button>
          <button type="button" class="vp-btn ${n.hwDecodeEnabled?"is-active":""}" id="btnHwDecode" title="切換 GPU 硬體解碼加速 (預設開啟)">
            <span>⚡ 硬體解碼</span>
          </button>
          <button type="button" class="vp-btn ${n.powerSaveEnabled?"is-active":""}" id="btnPowerSave" title="切換智慧節省電力模式 (預設開啟)">
            <span>🍃 節省電力</span>
          </button>
          <button type="button" class="vp-btn ${n.showGestureGuide?"is-active":""}" id="btnGestureGuide" title="顯示/隱藏三區手勢導覽格線 (快捷鍵 G)">
            <span>👆 手勢導覽</span>
          </button>
          <button type="button" class="vp-btn" id="btnOpenUrl" title="載入遠端串流或影片網址">
            <span>🔗 載入網址</span>
          </button>
          <button type="button" class="vp-btn" id="btnOpenSub" title="載入 .srt 或 .vtt 外掛字幕檔">
            <span>💬 載入字幕</span>
          </button>
          <button type="button" class="vp-btn" id="btnScreenshot" title="擷取目前無損畫面並下載 PNG">
            <span>📸 截圖</span>
          </button>
          <button type="button" class="vp-btn" id="btnDrawerHw" title="硬體解碼與智慧節電監控面板">
            <span>🔋 硬體/節電</span>
          </button>
          <button type="button" class="vp-btn" id="btnDrawerEq" title="3 頻段 Web Audio 等化器與增益">
            <span>🎚️ 音效 EQ</span>
          </button>
          <button type="button" class="vp-btn" id="btnDrawerPlaylist" title="切換同目錄影片與內建多比例測試串流 (16:9 / 9:16 / 21:9 / 4:3)">
            <span>🎬 同目錄片單</span>
          </button>
          <button type="button" class="vp-btn" id="btnModalShortcuts" title="檢視鍵盤與手勢快捷鍵">
            <span>⌨️ 快捷鍵</span>
          </button>
        </div>

        <!-- Hidden File & Folder Inputs -->
        <input type="file" id="inputVideoFile" accept=".mp4,.webm,.ogg,.mov,.mkv,.avi,.m4v,.ts,.flv,.wmv,video/*" multiple style="display:none;" />
        <input type="file" id="inputFolderFiles" webkitdirectory directory multiple style="display:none;" />
        <input type="file" id="inputSubFile" accept=".srt,.vtt,text/vtt" style="display:none;" />
      </header>

      <!-- Main Stage Area -->
      <main class="vp-main">
        <div class="vp-stage-shell ${n.simPortrait?"sim-portrait":""}" id="vpStageShell">
          <div class="vp-stage" id="vpStage">
            <!-- Lossless Scale(1) Rotator Container -->
            <div class="vp-rotator" id="vpRotator">
              <video class="vp-video" id="vpVideo" playsinline webkit-playsinline preload="metadata"></video>
              <div class="vp-subtitle-box" id="vpSubtitleBox"></div>
            </div>

            <!-- GPU-Composited Brightness Veil for Zero-Copy MPO & Deep Dimming -->
            <div class="vp-brightness-veil" id="vpBrightnessVeil"></div>

            <!-- Top-Center Video Switch HUD Toast (.vp-switch-toast) -->
            <div class="vp-switch-toast" id="vpSwitchToast">
              <span class="vp-switch-toast-badge" id="vpSwitchToastBadge">⏭ 下一片 (1/4)</span>
              <span class="vp-switch-toast-title" id="vpSwitchToastTitle">星際地平線</span>
            </div>

            <!-- Stage Geometry & Hardware Status Floating Badge -->
            <div class="vp-stage-badge" id="vpStageBadge">
              <span id="vpStageBadgeText">1280×720 • 旋轉 0° • Scale 1.00x 無損最大化</span>
            </div>

            <!-- Stage Left/Right Edge Floating Prev/Next Buttons (.vp-stage-edge-nav) -->
            <div class="vp-stage-edge-nav">
              <button type="button" class="vp-edge-prev" id="btnEdgePrev" title="同目錄上一片 (快捷鍵: PageUp / P / Shift+← / ←)">
                <span class="vp-edge-icon">⏮</span>
                <div class="vp-edge-preview">
                  <span class="vp-edge-label" id="edgePrevLabel">同目錄上一片</span>
                  <span class="vp-edge-filename" id="edgePrevFilename">上一部影片</span>
                </div>
              </button>

              <button type="button" class="vp-edge-next" id="btnEdgeNext" title="同目錄下一片 (快捷鍵: PageDown / N / Shift+→ / →)">
                <span class="vp-edge-icon">⏭</span>
                <div class="vp-edge-preview">
                  <span class="vp-edge-label" id="edgeNextLabel">同目錄下一片</span>
                  <span class="vp-edge-filename" id="edgeNextFilename">下一部影片</span>
                </div>
              </button>
            </div>

            <!-- 3-Zone Touch & Pointer Gesture Layer (Left 35% | Center 30% | Right 35%) -->
            <div class="vp-gesture-layer ${n.showGestureGuide?"show-guide":""}" id="vpGestureLayer">
              <div class="vp-zone vp-zone-left" id="vpZoneLeft">
                <div class="vp-zone-guide">
                  <span>☀️ 左側上下滑：亮度</span>
                  <span class="vp-zone-guide-sub">目前 <strong id="vpGuideBrightnessVal">${n.brightness}%</strong>（自動記憶上次設定）• 雙擊快退 10 秒</span>
                </div>
              </div>

              <div class="vp-zone vp-zone-center" id="vpZoneCenter">
                <div class="vp-zone-guide">
                  <span>⏯️ 中間點擊：播放 / 暫停</span>
                  <span class="vp-zone-guide-sub">單擊立即切換播放狀態 • 按前後鍵 ⏮/⏭ 同目錄換片</span>
                </div>
              </div>

              <div class="vp-zone vp-zone-right" id="vpZoneRight">
                <div class="vp-zone-guide">
                  <span>🔊 右側上下滑：音量</span>
                  <span class="vp-zone-guide-sub">目前 <strong id="vpGuideVolumeVal">${n.volume}%</strong> • 雙擊快轉 10 秒</span>
                </div>
              </div>
            </div>

            <!-- Left Floating Brightness HUD Meter -->
            <div class="vp-hud-pill vp-hud-brightness" id="vpHudBrightness">
              <span class="vp-hud-icon">☀️</span>
              <span class="vp-hud-label">亮度記憶</span>
              <div class="vp-hud-bar-track">
                <div class="vp-hud-bar-fill" id="vpHudBrightnessFill" style="height: ${n.brightness}%;"></div>
              </div>
              <span class="vp-hud-value" id="vpHudBrightnessVal">${n.brightness}%</span>
            </div>

            <!-- Right Floating Volume HUD Meter -->
            <div class="vp-hud-pill vp-hud-volume" id="vpHudVolume">
              <span class="vp-hud-icon" id="vpHudVolumeIcon">🔊</span>
              <span class="vp-hud-label">音量控制</span>
              <div class="vp-hud-bar-track">
                <div class="vp-hud-bar-fill" id="vpHudVolumeFill" style="height: ${n.muted?0:n.volume}%;"></div>
              </div>
              <span class="vp-hud-value" id="vpHudVolumeVal">${n.muted?"靜音":`${n.volume}%`}</span>
            </div>

            <!-- Center Play / Pause Animated Ripple Feedback -->
            <div class="vp-center-ripple" id="vpCenterRipple">
              <span id="vpCenterRippleIcon">⏯️</span>
              <span class="vp-center-ripple-label" id="vpCenterRippleLabel">播放</span>
            </div>

            <!-- Double-Tap Seek ±10s Indicator -->
            <div class="vp-seek-indicator" id="vpSeekIndicator">⏪ -10s</div>
          </div>
        </div>

        <!-- Side Drawer: Complete System & Player Settings Center (#drawerSettings) -->
        <aside class="vp-drawer" id="drawerSettings" aria-label="系統與播放設定中心">
          <div class="vp-drawer-header">
            <div class="vp-drawer-title">⚙️ 系統與播放設定中心</div>
            <button type="button" class="vp-drawer-close" data-close-drawer>×</button>
          </div>
          <div class="vp-drawer-body">
            <!-- Section 1: Cloud OTA & Version Center (Learned from LIFE Project) -->
            <div class="vp-settings-section vp-eq-band" style="border-color: rgba(56, 189, 248, 0.4); background: linear-gradient(135deg, rgba(15, 23, 42, 0.8), rgba(30, 27, 75, 0.55));">
              <div class="vp-eq-band-row">
                <span class="vp-settings-label" style="font-weight:700; color: var(--accent-cyan-light);">☁️ P2R-OTA 雲端熱更與版本中心</span>
                <span class="vp-badge" id="settings-ota-ver-label">OTA v${ue} (${be})</span>
              </div>
              <div class="vp-settings-desc" id="settings-ota-layer-label" style="font-size:0.75rem; color: var(--text-secondary);">
                📦 目前載入圖層檢測中...
              </div>
              <div style="display:flex; flex-direction:column; gap:6px; margin-top:4px;">
                <div style="display:flex; gap:6px;">
                  <button type="button" class="vp-btn vp-btn-primary" id="btnSettingsOpenOta" style="flex:1;">
                    ☁️ 開啟雲端更新中心
                  </button>
                  <button type="button" class="vp-btn" id="btnSettingsCheckOta" style="flex:1;">
                    🔄 立即檢查新版本
                  </button>
                </div>
                <button type="button" class="vp-btn" id="btnSettingsUpgradeApk" style="border-color: rgba(16, 185, 129, 0.5); color: var(--accent-emerald);">
                  📦 下載並安裝最新完整版 Android APK (Tier-3)
                </button>
              </div>
            </div>

            <!-- Section 2: Gesture & Control Settings -->
            <div class="vp-settings-section vp-eq-band">
              <div style="font-weight:700; font-size:0.84rem; color: var(--accent-amber-light);">👆 手勢與操控設定</div>

              <div class="vp-settings-row vp-eq-band-row">
                <span class="vp-settings-label">☀️ 畫面亮度記憶 (<strong id="settingsBrightnessVal">${n.brightness}%</strong>)</span>
                <button type="button" class="vp-btn" id="btnSettingsResetBrightness" style="padding:3px 8px; font-size:0.72rem;">重設 85%</button>
              </div>
              <input type="range" class="vp-slider vp-brightness-slider" id="settingsSliderBrightness" min="0" max="100" step="1" value="${n.brightness}" />

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">🔊 預設音量大小 (<strong id="settingsVolumeVal">${n.muted?"靜音":`${n.volume}%`}</strong>)</span>
              </div>
              <input type="range" class="vp-slider vp-volume-slider" id="settingsSliderVolume" min="0" max="100" step="1" value="${n.muted?0:n.volume}" />

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:6px;">
                <div>
                  <div class="vp-settings-label">上下滑動手勢靈敏度</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">調整左亮度 / 右音量垂直滑動反應速度</div>
                </div>
                <div class="vp-seg-group" id="settingsSensitivityGroup" style="display:flex; gap:4px;">
                  ${[.8,1,1.2,1.5].map(o=>`<button type="button" class="vp-btn ${n.gestureSensitivity===o?"is-active":""}" data-sens="${o}" style="padding:4px 7px; font-size:0.72rem;">${o}x</button>`).join("")}
                </div>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <div>
                  <div class="vp-settings-label">⏮/⏭ 鍵盤左右方向鍵 (← / →) 模式</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">開啟時按 ←/→ 直接切換同目錄前後片；關閉時快進退 5 秒</div>
                </div>
                <button type="button" class="vp-btn ${n.arrowKeySwitchMode?"is-active":""}" id="btnSettingsArrowMode">
                  ${n.arrowKeySwitchMode?"同目錄換片":"快轉 ±5秒"}
                </button>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">👆 顯示三區手勢導覽提示層</span>
                <button type="button" class="vp-btn ${n.showGestureGuide?"is-active":""}" id="btnSettingsGestureGuide">
                  ${n.showGestureGuide?"已開啟":"已隱藏"}
                </button>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">⏱️ 自動記憶各影片上次播放進度</span>
                <button type="button" class="vp-btn ${n.rememberResumePosition?"is-active":""}" id="btnSettingsRememberResume">
                  ${n.rememberResumePosition?"已開啟":"已關閉"}
                </button>
              </div>
            </div>

            <!-- Section 3: Orientation & Lossless Scale(1) Maximization -->
            <div class="vp-settings-section vp-eq-band">
              <div style="font-weight:700; font-size:0.84rem; color: var(--primary-light);">🔄 畫面與無損自動轉向 (Scale 1.00x)</div>

              <div class="vp-settings-row vp-eq-band-row">
                <div>
                  <div class="vp-settings-label">智慧偵測比例自動轉向滿版</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">固定 Scale(1) 零裁切、零變形最大化</div>
                </div>
                <button type="button" class="vp-btn ${n.autoRotate?"is-active":""}" id="btnSettingsAutoRotate">
                  ${n.autoRotate?"已開啟":"已關閉"}
                </button>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">手動基準旋轉角度</span>
                <div class="vp-seg-group" id="settingsRotationGroup" style="display:flex; gap:4px;">
                  ${[0,90,180,270].map(o=>`<button type="button" class="vp-btn ${n.manualRotation===o?"is-active":""}" data-rot="${o}" style="padding:4px 8px; font-size:0.72rem;">${o}°</button>`).join("")}
                </div>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <span class="vp-settings-label">📱 模擬 9:16 手機直向視窗框體</span>
                <button type="button" class="vp-btn ${n.simPortrait?"is-active":""}" id="btnSettingsSimPortrait">
                  ${n.simPortrait?"模擬中 (9:16)":"全寬視窗"}
                </button>
              </div>
            </div>

            <!-- Section 4: Hardware Decoding, Eco Power Saving & Factory Reset -->
            <div class="vp-settings-section vp-eq-band">
              <div style="font-weight:700; font-size:0.84rem; color: var(--accent-emerald);">⚡ 硬體解碼與智慧節電 (預設開啟)</div>

              <div class="vp-settings-row vp-eq-band-row">
                <div>
                  <div class="vp-settings-label">⚡ GPU 硬體解碼加速 (MPO Zero-Copy)</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">優先啟用硬體圖層與零拷貝亮度遮罩</div>
                </div>
                <button type="button" class="vp-btn ${n.hwDecodeEnabled?"is-active":""}" id="btnSettingsHwDecode">
                  ${n.hwDecodeEnabled?"已開啟":"已關閉"}
                </button>
              </div>

              <div class="vp-settings-row vp-eq-band-row" style="margin-top:4px;">
                <div>
                  <div class="vp-settings-label">🍃 智慧節省電力模式 (Eco Mode)</div>
                  <div class="vp-settings-desc" style="font-size:0.7rem; color:var(--text-muted);">4Hz UI 輪詢休眠、30FPS Eco 渲染與智慧喚醒鎖</div>
                </div>
                <button type="button" class="vp-btn ${n.powerSaveEnabled?"is-active":""}" id="btnSettingsPowerSave">
                  ${n.powerSaveEnabled?"節電開啟":"全速效能"}
                </button>
              </div>

              <div style="margin-top:8px; padding-top:8px; border-top:1px solid var(--glass-border); display:flex; justify-content:space-between; align-items:center;">
                <span style="font-size:0.75rem; color:var(--text-muted);">重設所有播放器偏好設定</span>
                <button type="button" class="vp-btn" id="btnSettingsFactoryReset" style="border-color: rgba(244, 63, 94, 0.45); color: #fda4af;">
                  🔄 恢復出廠預設設定
                </button>
              </div>
            </div>
          </div>
        </aside>

        <!-- Side Drawer: Same-Directory Playlist -->
        <aside class="vp-drawer" id="drawerPlaylist" aria-label="同目錄播放清單">
          <div class="vp-drawer-header">
            <div class="vp-drawer-title">🎬 同目錄片單 &amp; 比例測試串流</div>
            <button type="button" class="vp-drawer-close" data-close-drawer>×</button>
          </div>
          <div class="vp-drawer-body">
            <!-- Same-Directory Status Banner (.vp-dir-banner) -->
            <div class="vp-dir-banner" id="vpDirBanner">
              <div class="vp-dir-banner-header">
                <span class="vp-dir-title">📁 <span id="vpDirBannerName">${n.directoryName}</span></span>
                <span class="vp-dir-count" id="vpDirBannerCount">1 / ${n.playlist.length} 部</span>
              </div>
              <div class="vp-dir-path" id="vpDirBannerPath">${n.directoryPath}</div>
              <div style="font-size: 0.72rem; color: var(--text-muted); margin-top: 2px;">
                💡 開啟單一影片時會自動掃描同資料夾內所有影片；按 <code>⏮/⏭</code>、<code>PageUp/PageDown</code>、<code>P/N</code>、<code>Shift+←/→</code> 或 <code>←/→</code> 即可直接換片！
              </div>
            </div>

            <div style="display:flex; gap:6px; flex-wrap:wrap;">
              <button type="button" class="vp-btn vp-btn-primary" id="btnDrawerAddFile" style="flex:1;">📂 選取影片 (自動同目錄)</button>
              <button type="button" class="vp-btn" id="btnDrawerOpenFolder" style="flex:1;">📁 開啟資料夾</button>
              <button type="button" class="vp-btn" id="btnDrawerResetDemo" title="載入內建 4 組比例測試串流">🎞️ 內建測試片</button>
            </div>

            <div class="vp-playlist-list" id="vpPlaylistContainer"></div>
          </div>
        </aside>

        <!-- Side Drawer: Equalizer -->
        <aside class="vp-drawer" id="drawerEq" aria-label="音效等化器">
          <div class="vp-drawer-header">
            <div class="vp-drawer-title">🎚️ 3 頻段 Web Audio 等化器</div>
            <button type="button" class="vp-drawer-close" data-close-drawer>×</button>
          </div>
          <div class="vp-drawer-body">
            <div class="vp-eq-presets" id="vpEqPresetsContainer"></div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>低頻 Bass (100 Hz)</span>
                <strong id="eqBassVal">0 dB</strong>
              </div>
              <input type="range" class="vp-slider" id="eqBassSlider" min="-12" max="12" step="0.5" value="0" />
            </div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>中頻人聲 Mid (1000 Hz)</span>
                <strong id="eqMidVal">0 dB</strong>
              </div>
              <input type="range" class="vp-slider" id="eqMidSlider" min="-12" max="12" step="0.5" value="0" />
            </div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>高頻細節 Treble (8000 Hz)</span>
                <strong id="eqTrebleVal">0 dB</strong>
              </div>
              <input type="range" class="vp-slider" id="eqTrebleSlider" min="-12" max="12" step="0.5" value="0" />
            </div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>前級增益 Preamp Boost</span>
                <strong id="eqBoostVal">1.00x</strong>
              </div>
              <input type="range" class="vp-slider" id="eqBoostSlider" min="0.5" max="2.0" step="0.05" value="1.0" />
            </div>

            <button type="button" class="vp-btn" id="btnEqReset">🔄 重設為原音直通 (Flat)</button>
          </div>
        </aside>

        <!-- Side Drawer: Hardware Decoding & Power Saving Telemetry -->
        <aside class="vp-drawer" id="drawerHw" aria-label="硬體解碼與智慧節電引擎">
          <div class="vp-drawer-header">
            <div class="vp-drawer-title">⚡ 硬體解碼 &amp; 🍃 智慧節電引擎</div>
            <button type="button" class="vp-drawer-close" data-close-drawer>×</button>
          </div>
          <div class="vp-drawer-body">
            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>⚡ GPU 硬體解碼加速 (預設開啟)</span>
                <button type="button" class="vp-btn ${n.hwDecodeEnabled?"is-active":""}" id="btnPanelHwToggle">
                  ${n.hwDecodeEnabled?"已開啟 (Prefer-HW)":"已關閉 (軟體)"}
                </button>
              </div>
              <div style="font-size: 0.74rem; color: var(--text-muted);">
                啟用硬體圖層提升與 Zero-Copy MPO 零拷貝亮度遮罩（亮度 ≤ 85% 時免除像素著色器濾鏡耗電）。
              </div>
            </div>

            <div class="vp-eq-band">
              <div class="vp-eq-band-row">
                <span>🍃 智慧節省電力模式 (預設開啟)</span>
                <button type="button" class="vp-btn ${n.powerSaveEnabled?"is-active":""}" id="btnPanelPowerToggle">
                  ${n.powerSaveEnabled?"節電開啟 (Eco)":"全速效能"}
                </button>
              </div>
              <div style="font-size: 0.74rem; color: var(--text-muted);">
                自動降低非必要 UI 輪詢至 4Hz (250ms) 讓 CPU 進入深層休眠、背景分頁自動降頻至 5FPS，並智慧管理螢幕喚醒鎖。
              </div>
            </div>

            <div class="vp-eq-band" id="vpHwTelemetryCard">
              <div class="vp-eq-band-row">
                <span>解碼管線路徑</span>
                <strong id="hwDecodePathVal" style="color: var(--accent-emerald);">GPU 硬體加速 (MPO Zero-Copy)</strong>
              </div>
              <div class="vp-eq-band-row">
                <span>節電狀態與預估功耗節省</span>
                <strong id="hwPowerSaveVal" style="color: var(--accent-cyan-light);">節電中 (-42% 功耗)</strong>
              </div>
              <div class="vp-eq-band-row">
                <span>電池 / 電源狀態</span>
                <strong id="hwBatteryVal">電源直供 / 100%</strong>
              </div>
              <div class="vp-eq-band-row">
                <span>UI 更新頻率 / 掉幀率</span>
                <strong id="hwFrameQualityVal">4Hz Eco • 掉幀 0 (0.00%)</strong>
              </div>
            </div>

            <div class="vp-eq-band">
              <div style="font-size: 0.8rem; font-weight: 600; margin-bottom: 4px;">硬體解碼器能力探測 (MediaCapabilities)</div>
              <div id="vpCodecList" style="display:flex; flex-direction:column; gap:6px; font-size:0.76rem;"></div>
            </div>
          </div>
        </aside>

        <!-- Drag & Drop Overlay -->
        <div class="vp-drop-overlay" id="vpDropOverlay">
          <div style="font-size: 2.6rem;">📂</div>
          <div>放開滑鼠以載入本機影片、整個資料夾或字幕檔 (.mp4 / .webm / .mkv / .srt / .vtt)</div>
        </div>
      </main>

      <!-- Bottom Control Bar -->
      <footer class="vp-controls" id="vpControls">
        <!-- Timeline Row -->
        <div class="vp-timeline-row">
          <span class="vp-time-display"><strong id="vpCurrentTime">00:00</strong> / <span id="vpDuration">02:00</span></span>

          <div class="vp-progress-wrap" id="vpProgressWrap">
            <div class="vp-progress-bar" id="vpProgressBar">
              <div class="vp-progress-buffered" id="vpProgressBuffered"></div>
              <div class="vp-ab-range" id="vpAbRange" style="display:none;"></div>
              <div class="vp-ab-marker" id="vpAbMarkerA" data-label="A" style="display:none;"></div>
              <div class="vp-ab-marker" id="vpAbMarkerB" data-label="B" style="display:none;"></div>
              <div class="vp-progress-played" id="vpProgressPlayed"></div>
            </div>
            <div class="vp-time-tooltip" id="vpTimeTooltip">00:00</div>
          </div>

          <!-- A-B Loop Controls -->
          <div class="vp-control-group">
            <button type="button" class="vp-btn" id="btnSetPointA" title="設定 A-B 循環起點 A (快捷鍵 [)">點 A</button>
            <button type="button" class="vp-btn" id="btnSetPointB" title="設定 A-B 循環終點 B (快捷鍵 ])">點 B</button>
            <button type="button" class="vp-btn" id="btnClearAb" title="清除 A-B 區間循環" style="display:none;">清除 A-B</button>
          </div>
        </div>

        <!-- Transport & Dual Sliders Row -->
        <div class="vp-transport-row">
          <div class="vp-controls-left">
            <button type="button" class="vp-play-btn" id="btnPlayPause" title="播放 / 暫停 (空白鍵 或 點擊畫面中央)">▶</button>
            <button type="button" class="vp-btn" id="btnPrevVideo" title="同目錄上一片 (PageUp / P / Shift+← / ←)">⏮ 上一片</button>
            <button type="button" class="vp-btn" id="btnNextVideo" title="同目錄下一片 (PageDown / N / Shift+→ / →)">下一片 ⏭</button>
            <button type="button" class="vp-btn" id="btnSeekBack" title="快退 10 秒">⏪ -10s</button>
            <button type="button" class="vp-btn" id="btnSeekForward" title="快轉 10 秒">+10s ⏩</button>
            <button type="button" class="vp-btn" id="btnStepBack" title="倒退 1 幀">-1幀</button>
            <button type="button" class="vp-btn" id="btnStepForward" title="前進 1 幀">+1幀</button>
          </div>

          <div class="vp-controls-center">
            <!-- Brightness Quick Slider (Synced with Left Vertical Swipe & localStorage) -->
            <div class="vp-slider-group" title="畫面亮度控制（與畫面左側上下滑動同步，並自動記憶設定）">
              <span class="vp-slider-icon" id="btnBrightnessReset" title="點擊恢復預設 85% 亮度">☀️</span>
              <span class="vp-slider-label">亮度</span>
              <input
                type="range"
                class="vp-slider vp-brightness-slider"
                id="sliderBrightness"
                min="0"
                max="100"
                step="1"
                value="${n.brightness}"
                aria-label="畫面亮度"
              />
              <span class="vp-slider-val" id="sliderBrightnessVal">${n.brightness}%</span>
            </div>

            <!-- Volume Quick Slider (Synced with Right Vertical Swipe & localStorage) -->
            <div class="vp-slider-group" title="音量大小控制（與畫面右側上下滑動同步）">
              <span class="vp-slider-icon" id="btnMuteToggle" title="點擊切換靜音 (快捷鍵 M)">${n.muted||n.volume===0?"🔇":"🔊"}</span>
              <span class="vp-slider-label">音量</span>
              <input
                type="range"
                class="vp-slider vp-volume-slider"
                id="sliderVolume"
                min="0"
                max="100"
                step="1"
                value="${n.muted?0:n.volume}"
                aria-label="音量大小"
              />
              <span class="vp-slider-val" id="sliderVolumeVal">${n.muted?"靜音":`${n.volume}%`}</span>
            </div>
          </div>

          <div class="vp-controls-right">
            <select class="vp-select" id="selectSpeed" title="播放速度">
              ${Xn.map(o=>`<option value="${o}" ${o===n.playbackRate?"selected":""}>${o}x 速度</option>`).join("")}
            </select>

            <button type="button" class="vp-btn" id="btnLoopMode" title="切換循環播放模式">
              🔁 循環: 全部
            </button>

            <button type="button" class="vp-btn ${n.subtitlesEnabled?"is-active":""}" id="btnSubToggle" title="顯示/隱藏字幕">
              💬 字幕
            </button>

            <button type="button" class="vp-btn" id="btnPip" title="子母畫面 (Picture-in-Picture)">
              🖼️ 子母畫面
            </button>

            <button type="button" class="vp-btn" id="btnFullscreen" title="全螢幕切換 (快捷鍵 F)">
              ⛶ 全螢幕
            </button>
          </div>
        </div>
      </footer>

      <!-- Modal: Keyboard & Gesture Shortcuts -->
      <div class="vp-modal-backdrop" id="modalShortcuts">
        <div class="vp-modal">
          <div class="vp-modal-header">
            <div class="vp-modal-title">⌨️ 手勢操作與鍵盤快捷鍵一覽</div>
            <button type="button" class="vp-drawer-close" data-close-modal>×</button>
          </div>
          <div class="vp-modal-body">
            <div class="vp-eq-band" style="border-color: rgba(255, 184, 48, 0.35);">
              <div style="font-weight:700; font-size:0.86rem; color: var(--accent-amber-light);">👆 三區直覺觸控 / 滑鼠拖曳手勢 &amp; 同目錄換片</div>
              <div style="font-size:0.8rem; color: var(--text-secondary); display:grid; gap:4px;">
                <div>• <strong>畫面左側 (0%–35%) 上下滑動</strong>：無段調整畫面亮度 (0%–100%)，自動記憶於 <code>localStorage</code> 與 Android 系統</div>
                <div>• <strong>畫面中央 (35%–65%) 單擊</strong>：立即切換 播放 / 暫停（防垂直滑動誤觸）</div>
                <div>• <strong>畫面右側 (65%–100%) 上下滑動</strong>：無段調整音量大小 (0%–100%)</div>
                <div>• <strong>同目錄按前後鍵換片</strong>：按 <code>PageUp / PageDown</code>、<code>P / N</code>、<code>Shift + ← / →</code>、方向鍵 <code>← / →</code> 或畫面兩側 <code>⏮ / ⏭</code> 按鈕立即切換同資料夾上一部 / 下一部影片</div>
              </div>
            </div>
            <div class="vp-shortcuts-grid">
              ${Yn.map(o=>`
                <div class="vp-shortcut-item">
                  <div>
                    <div style="font-weight:600; font-size:0.82rem;">${o.action}</div>
                    <div style="font-size:0.7rem; color:var(--text-muted);">${o.desc}</div>
                  </div>
                  <kbd class="vp-kbd">${o.key}</kbd>
                </div>
              `).join("")}
            </div>
          </div>
        </div>
      </div>

      <!-- Modal: Load Stream / Video URL -->
      <div class="vp-modal-backdrop" id="modalUrl">
        <div class="vp-modal">
          <div class="vp-modal-header">
            <div class="vp-modal-title">🔗 載入影片或串流網址</div>
            <button type="button" class="vp-drawer-close" data-close-modal>×</button>
          </div>
          <div class="vp-modal-body">
            <label style="font-size:0.82rem; color:var(--text-secondary);">請輸入 MP4 / WebM / Ogg 影片直連網址：</label>
            <input type="url" class="vp-input" id="inputStreamUrl" placeholder="https://example.com/video.mp4" />
            <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:6px;">
              <button type="button" class="vp-btn" data-close-modal>取消</button>
              <button type="button" class="vp-btn vp-btn-primary" id="btnConfirmUrl">載入並播放</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Toast Notifications -->
      <div class="vp-toast-container" id="vpToastContainer"></div>
    </div>
  `;const e={app:document.getElementById("vpApp"),stageShell:document.getElementById("vpStageShell"),stage:document.getElementById("vpStage"),rotator:document.getElementById("vpRotator"),video:document.getElementById("vpVideo"),subtitleBox:document.getElementById("vpSubtitleBox"),brightnessVeil:document.getElementById("vpBrightnessVeil"),stageBadgeText:document.getElementById("vpStageBadgeText"),gestureLayer:document.getElementById("vpGestureLayer"),switchToast:document.getElementById("vpSwitchToast"),switchToastBadge:document.getElementById("vpSwitchToastBadge"),switchToastTitle:document.getElementById("vpSwitchToastTitle"),btnEdgePrev:document.getElementById("btnEdgePrev"),btnEdgeNext:document.getElementById("btnEdgeNext"),edgePrevLabel:document.getElementById("edgePrevLabel"),edgePrevFilename:document.getElementById("edgePrevFilename"),edgeNextLabel:document.getElementById("edgeNextLabel"),edgeNextFilename:document.getElementById("edgeNextFilename"),videoTitle:document.getElementById("vpVideoTitle"),aspectBadge:document.getElementById("vpAspectBadge"),dirPill:document.getElementById("vpDirPill"),dirPillVal:document.getElementById("vpDirPillVal"),brightnessPillVal:document.getElementById("vpBrightnessPillVal"),brightnessMemoryTag:document.getElementById("vpBrightnessMemoryTag"),volumePillIcon:document.getElementById("vpVolumePillIcon"),volumePillVal:document.getElementById("vpVolumePillVal"),orientationPillVal:document.getElementById("vpOrientationPillVal"),hwPowerPill:document.getElementById("vpHwPowerPill"),hwPowerPillVal:document.getElementById("vpHwPowerPillVal"),guideBrightnessVal:document.getElementById("vpGuideBrightnessVal"),guideVolumeVal:document.getElementById("vpGuideVolumeVal"),hudBrightness:document.getElementById("vpHudBrightness"),hudBrightnessFill:document.getElementById("vpHudBrightnessFill"),hudBrightnessVal:document.getElementById("vpHudBrightnessVal"),hudVolume:document.getElementById("vpHudVolume"),hudVolumeIcon:document.getElementById("vpHudVolumeIcon"),hudVolumeFill:document.getElementById("vpHudVolumeFill"),hudVolumeVal:document.getElementById("vpHudVolumeVal"),centerRipple:document.getElementById("vpCenterRipple"),centerRippleIcon:document.getElementById("vpCenterRippleIcon"),centerRippleLabel:document.getElementById("vpCenterRippleLabel"),seekIndicator:document.getElementById("vpSeekIndicator"),btnDrawerSettings:document.getElementById("btnDrawerSettings"),btnOpenFile:document.getElementById("btnOpenFile"),btnOpenFolder:document.getElementById("btnOpenFolder"),btnArrowSwitchMode:document.getElementById("btnArrowSwitchMode"),btnAutoRotate:document.getElementById("btnAutoRotate"),btnRotate90:document.getElementById("btnRotate90"),btnSimPortrait:document.getElementById("btnSimPortrait"),btnHwDecode:document.getElementById("btnHwDecode"),btnPowerSave:document.getElementById("btnPowerSave"),btnGestureGuide:document.getElementById("btnGestureGuide"),btnOpenUrl:document.getElementById("btnOpenUrl"),btnOpenSub:document.getElementById("btnOpenSub"),btnScreenshot:document.getElementById("btnScreenshot"),btnDrawerHw:document.getElementById("btnDrawerHw"),btnDrawerEq:document.getElementById("btnDrawerEq"),btnDrawerPlaylist:document.getElementById("btnDrawerPlaylist"),btnModalShortcuts:document.getElementById("btnModalShortcuts"),inputVideoFile:document.getElementById("inputVideoFile"),inputFolderFiles:document.getElementById("inputFolderFiles"),inputSubFile:document.getElementById("inputSubFile"),drawerSettings:document.getElementById("drawerSettings"),drawerPlaylist:document.getElementById("drawerPlaylist"),drawerEq:document.getElementById("drawerEq"),drawerHw:document.getElementById("drawerHw"),btnSettingsOpenOta:document.getElementById("btnSettingsOpenOta"),btnSettingsCheckOta:document.getElementById("btnSettingsCheckOta"),btnSettingsUpgradeApk:document.getElementById("btnSettingsUpgradeApk"),settingsBrightnessVal:document.getElementById("settingsBrightnessVal"),settingsSliderBrightness:document.getElementById("settingsSliderBrightness"),btnSettingsResetBrightness:document.getElementById("btnSettingsResetBrightness"),settingsVolumeVal:document.getElementById("settingsVolumeVal"),settingsSliderVolume:document.getElementById("settingsSliderVolume"),settingsSensitivityGroup:document.getElementById("settingsSensitivityGroup"),btnSettingsArrowMode:document.getElementById("btnSettingsArrowMode"),btnSettingsGestureGuide:document.getElementById("btnSettingsGestureGuide"),btnSettingsRememberResume:document.getElementById("btnSettingsRememberResume"),btnSettingsAutoRotate:document.getElementById("btnSettingsAutoRotate"),settingsRotationGroup:document.getElementById("settingsRotationGroup"),btnSettingsSimPortrait:document.getElementById("btnSettingsSimPortrait"),btnSettingsHwDecode:document.getElementById("btnSettingsHwDecode"),btnSettingsPowerSave:document.getElementById("btnSettingsPowerSave"),btnSettingsFactoryReset:document.getElementById("btnSettingsFactoryReset"),dirBannerName:document.getElementById("vpDirBannerName"),dirBannerCount:document.getElementById("vpDirBannerCount"),dirBannerPath:document.getElementById("vpDirBannerPath"),playlistContainer:document.getElementById("vpPlaylistContainer"),btnDrawerAddFile:document.getElementById("btnDrawerAddFile"),btnDrawerOpenFolder:document.getElementById("btnDrawerOpenFolder"),btnDrawerResetDemo:document.getElementById("btnDrawerResetDemo"),eqPresetsContainer:document.getElementById("vpEqPresetsContainer"),eqBassSlider:document.getElementById("eqBassSlider"),eqMidSlider:document.getElementById("eqMidSlider"),eqTrebleSlider:document.getElementById("eqTrebleSlider"),eqBoostSlider:document.getElementById("eqBoostSlider"),eqBassVal:document.getElementById("eqBassVal"),eqMidVal:document.getElementById("eqMidVal"),eqTrebleVal:document.getElementById("eqTrebleVal"),eqBoostVal:document.getElementById("eqBoostVal"),btnEqReset:document.getElementById("btnEqReset"),btnPanelHwToggle:document.getElementById("btnPanelHwToggle"),btnPanelPowerToggle:document.getElementById("btnPanelPowerToggle"),hwDecodePathVal:document.getElementById("hwDecodePathVal"),hwPowerSaveVal:document.getElementById("hwPowerSaveVal"),hwBatteryVal:document.getElementById("hwBatteryVal"),hwFrameQualityVal:document.getElementById("hwFrameQualityVal"),codecList:document.getElementById("vpCodecList"),dropOverlay:document.getElementById("vpDropOverlay"),currentTime:document.getElementById("vpCurrentTime"),duration:document.getElementById("vpDuration"),progressWrap:document.getElementById("vpProgressWrap"),progressBar:document.getElementById("vpProgressBar"),progressBuffered:document.getElementById("vpProgressBuffered"),progressPlayed:document.getElementById("vpProgressPlayed"),abRange:document.getElementById("vpAbRange"),abMarkerA:document.getElementById("vpAbMarkerA"),abMarkerB:document.getElementById("vpAbMarkerB"),timeTooltip:document.getElementById("vpTimeTooltip"),btnSetPointA:document.getElementById("btnSetPointA"),btnSetPointB:document.getElementById("btnSetPointB"),btnClearAb:document.getElementById("btnClearAb"),btnPlayPause:document.getElementById("btnPlayPause"),btnPrevVideo:document.getElementById("btnPrevVideo"),btnNextVideo:document.getElementById("btnNextVideo"),btnSeekBack:document.getElementById("btnSeekBack"),btnSeekForward:document.getElementById("btnSeekForward"),btnStepBack:document.getElementById("btnStepBack"),btnStepForward:document.getElementById("btnStepForward"),sliderBrightness:document.getElementById("sliderBrightness"),sliderBrightnessVal:document.getElementById("sliderBrightnessVal"),btnBrightnessReset:document.getElementById("btnBrightnessReset"),sliderVolume:document.getElementById("sliderVolume"),sliderVolumeVal:document.getElementById("sliderVolumeVal"),btnMuteToggle:document.getElementById("btnMuteToggle"),selectSpeed:document.getElementById("selectSpeed"),btnLoopMode:document.getElementById("btnLoopMode"),btnSubToggle:document.getElementById("btnSubToggle"),btnPip:document.getElementById("btnPip"),btnFullscreen:document.getElementById("btnFullscreen"),modalShortcuts:document.getElementById("modalShortcuts"),modalUrl:document.getElementById("modalUrl"),inputStreamUrl:document.getElementById("inputStreamUrl"),btnConfirmUrl:document.getElementById("btnConfirmUrl"),toastContainer:document.getElementById("vpToastContainer")};function s(o,d=2200){if(!e.toastContainer)return;const u=document.createElement("div");u.className="vp-toast",u.textContent=o,e.toastContainer.appendChild(u),setTimeout(()=>{u.style.opacity="0",u.style.transition="opacity 0.2s ease",setTimeout(()=>u.remove(),220)},d)}typeof window<"u"&&(window._showOmniPlayToast=s);let l=null;function m(o,d,u=1900){e.switchToast&&(e.switchToastBadge&&(e.switchToastBadge.textContent=o),e.switchToastTitle&&(e.switchToastTitle.textContent=d),e.switchToast.classList.add("is-visible"),l&&clearTimeout(l),l=setTimeout(()=>{e.switchToast.classList.remove("is-visible")},u))}const p=ii({videoEl:e.video,stageEl:e.stage,veilEl:e.brightnessVeil,onStatusChange(o){T(o)}}),h=Mi(e.video,{preset:n.eqPreset,...n.eqCustom}),g=Bi({stageEl:e.stage,rotatorEl:e.rotator,videoEl:e.video,autoRotate:n.autoRotate,manualRotation:n.manualRotation,simulateViewport:n.simPortrait?"portrait":"none",onUpdate(o){y(o)}});function y(o){if(!o)return;const d=o.autoRotate?"開啟":"關閉",u=o.effectiveRotation,v=o.isAutoRotated?" (智慧轉向滿版)":"",A=Number(o.scale||1).toFixed(2);if(e.orientationPillVal&&(e.orientationPillVal.textContent=`${d} | 旋轉: ${u}°${v} | Scale: ${A}x 無損最大化`),e.stageBadgeText){const P=p.getTelemetry(),j=P.hwDecodeEnabled?P.mpoZeroCopyActive?"GPU MPO 零拷貝":"GPU 硬體解碼":"軟體解碼";e.stageBadgeText.textContent=`${o.videoWidth}×${o.videoHeight} (${o.videoAspectLabel}) → 視窗適配 ${o.targetWidth}×${o.targetHeight} • 旋轉 ${u}° • Scale ${A}x 無損最大化 • ${j}`}if(e.btnAutoRotate&&e.btnAutoRotate.classList.toggle("is-active",!!o.autoRotate),e.btnSettingsAutoRotate&&(e.btnSettingsAutoRotate.classList.toggle("is-active",!!o.autoRotate),e.btnSettingsAutoRotate.textContent=o.autoRotate?"已開啟":"已關閉"),e.btnSimPortrait&&e.btnSimPortrait.classList.toggle("is-active",o.simulateViewport==="portrait"),e.btnSettingsSimPortrait){const P=o.simulateViewport==="portrait";e.btnSettingsSimPortrait.classList.toggle("is-active",P),e.btnSettingsSimPortrait.textContent=P?"模擬中 (9:16)":"全寬視窗"}e.settingsRotationGroup&&e.settingsRotationGroup.querySelectorAll("[data-rot]").forEach(P=>{P.classList.toggle("is-active",Number(P.getAttribute("data-rot"))===Number(o.manualRotation))})}function T(o){o&&(n.hwDecodeEnabled=o.hwDecodeEnabled,n.powerSaveEnabled=o.powerSaveEnabled,e.hwPowerPillVal&&(e.hwPowerPillVal.textContent=o.topbarBadgeText),e.btnHwDecode&&e.btnHwDecode.classList.toggle("is-active",o.hwDecodeEnabled),e.btnPowerSave&&e.btnPowerSave.classList.toggle("is-active",o.powerSaveEnabled),e.btnPanelHwToggle&&(e.btnPanelHwToggle.classList.toggle("is-active",o.hwDecodeEnabled),e.btnPanelHwToggle.textContent=o.hwDecodeEnabled?"已開啟 (Prefer-HW)":"已關閉 (軟體)"),e.btnSettingsHwDecode&&(e.btnSettingsHwDecode.classList.toggle("is-active",o.hwDecodeEnabled),e.btnSettingsHwDecode.textContent=o.hwDecodeEnabled?"已開啟":"已關閉"),e.btnPanelPowerToggle&&(e.btnPanelPowerToggle.classList.toggle("is-active",o.powerSaveEnabled),e.btnPanelPowerToggle.textContent=o.powerSaveEnabled?"節電開啟 (Eco)":"全速效能"),e.btnSettingsPowerSave&&(e.btnSettingsPowerSave.classList.toggle("is-active",o.powerSaveEnabled),e.btnSettingsPowerSave.textContent=o.powerSaveEnabled?"節電開啟":"全速效能"),e.hwDecodePathVal&&(e.hwDecodePathVal.textContent=o.decodeModeLabel),e.hwPowerSaveVal&&(e.hwPowerSaveVal.textContent=`${o.powerStateLabel} (-${o.estimatedPowerSavingPercent}% 功耗)`),e.hwBatteryVal&&o.battery&&(e.hwBatteryVal.textContent=o.battery.statusLabel),e.hwFrameQualityVal&&(e.hwFrameQualityVal.textContent=`${o.uiTickHz}Hz Tick • 掉幀 ${o.droppedVideoFrames}/${o.totalVideoFrames} (${o.dropRatePercent.toFixed(2)}%)`),e.codecList&&o.codecs&&(e.codecList.innerHTML=Object.values(o.codecs).map(d=>`
          <div style="display:flex; justify-content:space-between; align-items:center; padding:4px 8px; border-radius:6px; background:rgba(255,255,255,0.04);">
            <span>${d.name}</span>
            <span style="font-family:var(--font-mono); color:${d.powerEfficient?"var(--accent-emerald)":"var(--accent-amber-light)"};">
              ${d.supported?d.powerEfficient?"✓ 硬體節電解碼":"✓ 支援解碼":"✗ 未支援"}
            </span>
          </div>
        `).join("")))}function k(o,d={}){var A,P;const u=(d==null?void 0:d.source)||"user",v=Dn(o,u);n.brightness=v;try{(P=(A=window.AndroidPlayerBridge)==null?void 0:A.setScreenBrightness)==null||P.call(A,Number(v))}catch{}return p.applyBrightness(v),e.brightnessPillVal&&(e.brightnessPillVal.textContent=`${v}%`),e.brightnessMemoryTag&&(e.brightnessMemoryTag.textContent=u==="init-restore"&&n.brightnessRestored?"已還原上次設定":"已記憶"),e.sliderBrightness&&Number(e.sliderBrightness.value)!==v&&(e.sliderBrightness.value=String(v)),e.sliderBrightnessVal&&(e.sliderBrightnessVal.textContent=`${v}%`),e.settingsSliderBrightness&&Number(e.settingsSliderBrightness.value)!==v&&(e.settingsSliderBrightness.value=String(v)),e.settingsBrightnessVal&&(e.settingsBrightnessVal.textContent=`${v}%`),e.guideBrightnessVal&&(e.guideBrightnessVal.textContent=`${v}%`),e.hudBrightnessFill&&(e.hudBrightnessFill.style.height=`${v}%`),e.hudBrightnessVal&&(e.hudBrightnessVal.textContent=`${v}%`),v}function C(o,d={}){var j,z;const u=Math.max(0,Math.min(100,Math.round(Number(o)||0)));n.volume=u,u>0&&n.muted&&(d==null?void 0:d.source)!=="init"&&(n.muted=!1);const v=n.muted?0:u;e.video&&(e.video.volume=v/100,e.video.muted=n.muted);try{(z=(j=window.AndroidPlayerBridge)==null?void 0:j.setSystemVolume)==null||z.call(j,Number(v))}catch{}ee({volume:n.volume,muted:n.muted});const A=n.muted||v===0?"🔇":v<50?"🔉":"🔊",P=n.muted?"靜音":`${u}%`;return e.volumePillIcon&&(e.volumePillIcon.textContent=A),e.volumePillVal&&(e.volumePillVal.textContent=P),e.btnMuteToggle&&(e.btnMuteToggle.textContent=A),e.sliderVolume&&Number(e.sliderVolume.value)!==v&&(e.sliderVolume.value=String(v)),e.sliderVolumeVal&&(e.sliderVolumeVal.textContent=P),e.settingsSliderVolume&&Number(e.settingsSliderVolume.value)!==v&&(e.settingsSliderVolume.value=String(v)),e.settingsVolumeVal&&(e.settingsVolumeVal.textContent=P),e.guideVolumeVal&&(e.guideVolumeVal.textContent=P),e.hudVolumeIcon&&(e.hudVolumeIcon.textContent=A),e.hudVolumeFill&&(e.hudVolumeFill.style.height=`${v}%`),e.hudVolumeVal&&(e.hudVolumeVal.textContent=P),u}function N(){n.muted=!n.muted,!n.muted&&n.volume===0&&(n.volume=50),C(n.volume,{source:"mute-toggle"}),s(n.muted?"🔇 已靜音":`🔊 音量恢復 ${n.volume}%`,1400)}function R(){var d,u,v;const o=ce(e.video);return o?{currentTime:o.getCurrentTime(),duration:o.getDuration(),paused:o.paused}:{currentTime:Number((d=e.video)==null?void 0:d.currentTime)||0,duration:Number.isFinite((u=e.video)==null?void 0:u.duration)?e.video.duration:0,paused:!!((v=e.video)!=null&&v.paused)}}function V(o){const{duration:d}=R(),u=d>0?d:120,v=Math.max(0,Math.min(u,Number(o)||0)),A=ce(e.video);return A?A.seek(v):e.video&&(e.video.currentTime=v),K(),v}function w(o){const{currentTime:d}=R();return V(d+o)}function D(o="button"){h.resume();const d=ce(e.video);let u=!1;return d?u=d.togglePlay():e.video&&(e.video.paused||e.video.ended?(e.video.play().catch(()=>{}),u=!0):(e.video.pause(),u=!1)),S(u),p.syncWakeLock(),e.centerRippleIcon&&e.centerRippleLabel&&(e.centerRippleIcon.textContent=u?"▶️":"⏸️",e.centerRippleLabel.textContent=u?"播放中":"已暫停"),o!=="center-tap"&&$(),u}let B=null;function $(){e.centerRipple&&(e.centerRipple.classList.add("is-visible"),B&&clearTimeout(B),B=setTimeout(()=>{e.centerRipple.classList.remove("is-visible")},550))}function S(o){var d,u;try{(u=(d=window.AndroidPlayerBridge)==null?void 0:d.setKeepScreenOn)==null||u.call(d,!!o)}catch{}e.btnPlayPause&&(e.btnPlayPause.textContent=o?"⏸":"▶",e.btnPlayPause.title=o?"暫停 (空白鍵 或 點擊畫面中央)":"播放 (空白鍵 或 點擊畫面中央)")}Ei(e.gestureLayer,{getBrightness:()=>n.brightness,setBrightness:(o,d)=>{k(o,d)},getVolume:()=>n.muted?0:n.volume,setVolume:(o,d)=>{C(o,d)},onTogglePlayPause:o=>{D(o||"center-tap")},onDoubleTapSeek:o=>{w(o)},onGestureHud:(o,d,u)=>{if(o==="brightness"&&e.hudBrightness)e.hudBrightness.classList.toggle("is-active",!!d);else if(o==="volume"&&e.hudVolume)e.hudVolume.classList.toggle("is-active",!!d);else if(o==="play-pause"&&e.centerRipple)e.centerRipple.classList.toggle("is-visible",!!d);else if(o==="seek"&&e.seekIndicator){if(d){const v=Number(u)>0?`+${u}s ⏩`:`⏪ ${u}s`;e.seekIndicator.textContent=v}e.seekIndicator.classList.toggle("is-visible",!!d)}}});function E(){const o=Math.max(1,n.playlist.length),d=Math.max(0,Math.min(o-1,n.currentIndex)),u=(d-1+o)%o,v=(d+1)%o,A=n.playlist[u],P=n.playlist[v];e.dirPillVal&&(e.dirPillVal.textContent=`${d+1}/${o} (${n.directoryName})`),e.dirBannerName&&(e.dirBannerName.textContent=n.directoryName),e.dirBannerCount&&(e.dirBannerCount.textContent=`${d+1} / ${o} 部`),e.dirBannerPath&&(e.dirBannerPath.textContent=n.directoryPath||n.directoryName),e.edgePrevLabel&&A&&(e.edgePrevLabel.textContent=`⏮ 同目錄上一片 (${u+1}/${o})`),e.edgePrevFilename&&A&&(e.edgePrevFilename.textContent=A.title),e.edgeNextLabel&&P&&(e.edgeNextLabel.textContent=`同目錄下一片 (${v+1}/${o}) ⏭`),e.edgeNextFilename&&P&&(e.edgeNextFilename.textContent=P.title),e.btnPrevVideo&&A&&(e.btnPrevVideo.title=`⏮ 同目錄上一片 (${u+1}/${o})：${A.title} [快捷鍵: PageUp / P / Shift+← / ←]`),e.btnNextVideo&&P&&(e.btnNextVideo.title=`⏭ 同目錄下一片 (${v+1}/${o})：${P.title} [快捷鍵: PageDown / N / Shift+→ / →]`)}function M(o=1,d="button"){const u=n.playlist.length;if(u===0)return;const v=(n.currentIndex+o+u)%u,A=o<0?"prev":"next";I(v,!0,{switchDirection:A})}function F(o){if(o!=null&&o.pairedSubtitleFile){const d=new FileReader;d.onload=()=>{const u=Tn(String(d.result||""));u.length>0&&(n.customSubtitles=u,n.customSubtitleName=o.pairedSubtitleFile.name,K())},d.readAsText(o.pairedSubtitleFile,"utf-8")}else o!=null&&o.isDemo&&(n.customSubtitles=null,n.customSubtitleName="")}function I(o,d=!0,u={}){var Q;if(o<0||o>=n.playlist.length)return;const v=n.playlist[n.currentIndex],A=R();n.rememberResumePosition&&v&&A.currentTime>1&&Pn(v.id,A.currentTime,A.duration),n.currentIndex=o;const P=n.playlist[o];ee({lastVideoId:P.id}),P.directoryName&&(n.directoryName=P.directoryName),P.directoryPath&&(n.directoryPath=P.directoryPath),le(),k(qe(),{source:"video-switch"}),F(P);const j=n.playlist.length,z=`${o+1}/${j}`;if(e.videoTitle&&(e.videoTitle.textContent=P.title),e.aspectBadge&&(e.aspectBadge.textContent=P.aspectLabel||z),u.switchDirection){const q=u.switchDirection==="prev"?"⏮ 上一片":"⏭ 下一片";m(`${q} (${o+1}/${j})`,`${n.directoryName} • ${P.title}`)}if(P.isDemo){g.setIntrinsicSize(P.width,P.height);const q=mi(e.video,P,{autoPlay:d,onLoadedMetadata:({width:oe,height:ge})=>{g.setIntrinsicSize(oe,ge),g.recalculate()},onTimeUpdate:()=>{K()},onPlayChange:oe=>{S(oe)},onEnded:()=>{G()}});if(q){q.setPlaybackRate(n.playbackRate),(Q=q.setPowerSaveMode)==null||Q.call(q,n.powerSaveEnabled);const oe=h.getState();q.setEqGains(oe)}S(d)}else{Cn(e.video),g.setIntrinsicSize(0,0),e.video.src=P.url,e.video.playbackRate=n.playbackRate,e.video.volume=n.muted?0:n.volume/100,e.video.muted=n.muted,e.video.load();const q=n.rememberResumePosition?Ii(P.id):0,oe=()=>{e.video.removeEventListener("loadedmetadata",oe);const ge=e.video.videoWidth||1280,ke=e.video.videoHeight||720;P.width=ge,P.height=ke,g.recalculate();const Hn=g.getState();P.aspectLabel=`${Hn.videoAspectLabel} • ${o+1}/${n.playlist.length}`,e.aspectBadge&&(e.aspectBadge.textContent=P.aspectLabel),W(),q>2&&q<(e.video.duration||0)-3&&(e.video.currentTime=q,s(`⏱️ 已從上次進度 ${ve(q)} 接續播放`,1600)),h.syncSource(),d&&e.video.play().catch(()=>{})};e.video.addEventListener("loadedmetadata",oe)}E(),W(),K()}function G(){if(n.loopMode==="one"){V(0);const o=ce(e.video);o?o.play():e.video.play().catch(()=>{})}else n.loopMode==="all"?M(1,"auto-next"):S(!1)}function W(){if(!e.playlistContainer)return;const o=n.playlist.length;e.playlistContainer.innerHTML=n.playlist.map((d,u)=>{const v=u===n.currentIndex;return`
          <div class="vp-playlist-item ${v?"is-active":""}" data-playlist-idx="${u}">
            <span class="vp-playlist-index">${u+1}</span>
            <div class="vp-playlist-meta">
              <div class="vp-playlist-title">${v?"▶ ":""}${d.title}</div>
              <div class="vp-playlist-sub">${d.subtitle||`${d.width||1280}×${d.height||720}`}</div>
            </div>
            <span class="vp-badge">${d.aspectLabel||`${u+1}/${o}`}</span>
          </div>
        `}).join(""),e.playlistContainer.querySelectorAll("[data-playlist-idx]").forEach(d=>{d.addEventListener("click",()=>{const u=Number(d.getAttribute("data-playlist-idx"));I(u,!0,{switchDirection:u<n.currentIndex?"prev":"next"})})})}function H(){const o=h.getState();e.eqPresetsContainer&&(e.eqPresetsContainer.innerHTML=bn.map(d=>`
          <button type="button" class="vp-eq-preset-btn ${o.preset===d.id?"is-active":""}" data-eq-preset="${d.id}">
            ${d.name}
          </button>
        `).join(""),e.eqPresetsContainer.querySelectorAll("[data-eq-preset]").forEach(d=>{d.addEventListener("click",()=>{var A;const u=d.getAttribute("data-eq-preset"),v=bn.find(P=>P.id===u);if(v){const P=h.setPreset(v);(A=ce(e.video))==null||A.setEqGains(P),ee({eqPreset:v.id,eqCustom:{bass:P.bass,mid:P.mid,treble:P.treble,boost:P.boost}}),H(),s(`🎚️ 已套用音效預設：${v.name}`,1500)}})})),e.eqBassSlider&&(e.eqBassSlider.value=String(o.bass)),e.eqMidSlider&&(e.eqMidSlider.value=String(o.mid)),e.eqTrebleSlider&&(e.eqTrebleSlider.value=String(o.treble)),e.eqBoostSlider&&(e.eqBoostSlider.value=String(o.boost)),e.eqBassVal&&(e.eqBassVal.textContent=`${o.bass>0?"+":""}${o.bass} dB`),e.eqMidVal&&(e.eqMidVal.textContent=`${o.mid>0?"+":""}${o.mid} dB`),e.eqTrebleVal&&(e.eqTrebleVal.textContent=`${o.treble>0?"+":""}${o.treble} dB`),e.eqBoostVal&&(e.eqBoostVal.textContent=`${Number(o.boost).toFixed(2)}x`)}function K(){var A,P;const{currentTime:o,duration:d}=R(),u=d>0?d:120;if(n.abLoop.a!==null&&n.abLoop.b!==null&&n.abLoop.b>n.abLoop.a+.2&&o>=n.abLoop.b){V(n.abLoop.a);return}const v=Math.max(0,Math.min(100,o/u*100));if(e.progressPlayed&&(e.progressPlayed.style.width=`${v.toFixed(2)}%`),e.currentTime&&(e.currentTime.textContent=ve(o)),e.duration&&(e.duration.textContent=ve(u)),e.progressBuffered){if(Be(e.video))e.progressBuffered.style.width="100%";else if(((P=(A=e.video)==null?void 0:A.buffered)==null?void 0:P.length)>0){const j=e.video.buffered.end(e.video.buffered.length-1),z=Math.min(100,j/u*100);e.progressBuffered.style.width=`${z.toFixed(1)}%`}}J(o)}function J(o){if(!e.subtitleBox)return;if(!n.subtitlesEnabled){e.subtitleBox.innerHTML="";return}const d=n.customSubtitles&&n.customSubtitles.length>0?n.customSubtitles:Be(e.video)?Jn:[];if(d.length===0){e.subtitleBox.innerHTML="";return}const u=n.customSubtitles&&n.customSubtitles.length>0?o:o%30,v=d.find(A=>u>=A.start&&u<=A.end);v?e.subtitleBox.innerHTML=`<span class="vp-subtitle-text">${v.text}</span>`:e.subtitleBox.innerHTML=""}function se(){var A,P,j,z;const{duration:o}=R(),d=o>0?o:120,{a:u,b:v}=n.abLoop;if(u!==null&&e.abMarkerA?(e.abMarkerA.style.display="block",e.abMarkerA.style.left=`${Math.min(100,u/d*100)}%`,(A=e.btnSetPointA)==null||A.classList.add("is-active")):e.abMarkerA&&(e.abMarkerA.style.display="none",(P=e.btnSetPointA)==null||P.classList.remove("is-active")),v!==null&&e.abMarkerB?(e.abMarkerB.style.display="block",e.abMarkerB.style.left=`${Math.min(100,v/d*100)}%`,(j=e.btnSetPointB)==null||j.classList.add("is-active")):e.abMarkerB&&(e.abMarkerB.style.display="none",(z=e.btnSetPointB)==null||z.classList.remove("is-active")),u!==null&&v!==null&&v>u&&e.abRange){const Q=Math.min(100,u/d*100),q=Math.min(100-Q,(v-u)/d*100);e.abRange.style.display="block",e.abRange.style.left=`${Q}%`,e.abRange.style.width=`${q}%`}else e.abRange&&(e.abRange.style.display="none");e.btnClearAb&&(e.btnClearAb.style.display=u!==null||v!==null?"inline-flex":"none")}function le(){n.abLoop.a=null,n.abLoop.b=null,se()}function U(o){var d,u,v,A,P,j,z,Q;n.activeDrawer=n.activeDrawer===o?null:o,(d=e.drawerSettings)==null||d.classList.toggle("is-open",n.activeDrawer==="settings"),(u=e.drawerPlaylist)==null||u.classList.toggle("is-open",n.activeDrawer==="playlist"),(v=e.drawerEq)==null||v.classList.toggle("is-open",n.activeDrawer==="eq"),(A=e.drawerHw)==null||A.classList.toggle("is-open",n.activeDrawer==="hw"),(P=e.btnDrawerSettings)==null||P.classList.toggle("is-active",n.activeDrawer==="settings"),(j=e.btnDrawerPlaylist)==null||j.classList.toggle("is-active",n.activeDrawer==="playlist"),(z=e.btnDrawerEq)==null||z.classList.toggle("is-active",n.activeDrawer==="eq"),(Q=e.btnDrawerHw)==null||Q.classList.toggle("is-active",n.activeDrawer==="hw")}function Y(o){var d,u;n.activeModal=o,(d=e.modalShortcuts)==null||d.classList.toggle("is-open",o==="shortcuts"),(u=e.modalUrl)==null||u.classList.toggle("is-open",o==="url"),o==="url"&&setTimeout(()=>{var v;return(v=e.inputStreamUrl)==null?void 0:v.focus()},60)}function L(){var o,d;n.activeModal=null,(o=e.modalShortcuts)==null||o.classList.remove("is-open"),(d=e.modalUrl)==null||d.classList.remove("is-open")}async function b(o,d=""){var j;if(!o||o.length===0)return;const u=Array.from(o),v=u.filter(z=>{var Q;return z&&(((Q=z.type)==null?void 0:Q.startsWith("video/"))||ze(z.name))}),A=u.filter(z=>z&&Ue(z.name));if(v.length===0&&A.length>0){const z=A[0],Q=new FileReader;Q.onload=()=>{var oe;const q=Tn(String(Q.result||""));q.length>0&&(n.customSubtitles=q,n.customSubtitleName=z.name,n.subtitlesEnabled=!0,(oe=e.btnSubToggle)==null||oe.classList.add("is-active"),s(`💬 已載入字幕：${z.name} (${q.length} 句)`),K())},Q.readAsText(z,"utf-8");return}if(v.length===0)return;const P=Fn(u,v[0].name,d);if(n.playlist=P.items,n.directoryName=P.directoryName,n.directoryPath=d?`${P.directoryName} (共 ${P.total} 部同目錄影片)`:`本機選取檔案 (${P.total} 部)`,I(P.currentIndex,!0),v.length===1){const z=v[0],Q=(j=n.playlist[0])==null?void 0:j.url,q=await Vi(z,n.lastDirectoryPath);if(q.found&&q.items.length>0){const oe=q.items.map((ge,ke)=>ke===q.currentIndex&&Q?{...ge,url:Q,file:z}:ge);if(n.playlist=oe,n.currentIndex=q.currentIndex,n.directoryName=q.directoryName,n.directoryPath=q.directoryPath,ee({lastDirectoryPath:q.directoryPath}),e.aspectBadge){const ge=g.getState();e.aspectBadge.textContent=`${ge.videoAspectLabel} • ${n.currentIndex+1}/${oe.length}`}E(),W(),m(`📁 同目錄連播 (${n.currentIndex+1}/${oe.length})`,`已載入「${q.directoryName}」共 ${oe.length} 部影片，可按 ⏮/⏭ 前後鍵換片`)}else s(`📂 已開始播放：${z.title||z.name}`)}else m(`📁 同目錄連播 (1/${P.total})`,`已載入「${P.directoryName}」共 ${P.total} 部影片，可按 ⏮/⏭ 前後鍵換片`)}async function O(){var d;const o=await Di();if(o.supported){!o.cancelled&&o.items&&o.items.length>0?(n.playlist=o.items,n.directoryName=o.directoryName,n.directoryPath=`${o.directoryName} (同目錄共 ${o.total} 部影片)`,I(o.currentIndex,!0),m(`📁 同目錄連播 (1/${o.total})`,`已載入資料夾「${o.directoryName}」共 ${o.total} 部影片`)):o.cancelled||s("⚠️ 該資料夾內未找到支援的影片檔");return}(d=e.inputFolderFiles)==null||d.click()}function Z(){try{const o=ce(e.video);let d="";if(o)d=o.captureFrameDataUrl("image/png");else if(e.video&&e.video.videoWidth>0){const v=document.createElement("canvas");v.width=e.video.videoWidth,v.height=e.video.videoHeight,v.getContext("2d").drawImage(e.video,0,0,v.width,v.height),d=v.toDataURL("image/png")}if(!d){s("⚠️ 目前尚無可擷取的視訊畫面");return}const u=document.createElement("a");u.href=d,u.download=`OmniPlay_Frame_${Date.now()}.png`,document.body.appendChild(u),u.click(),u.remove(),s("📸 已擷取無損畫面並下載 PNG")}catch{s("⚠️ 截圖失敗（跨網域視訊受 CORS 保護）")}}(je=e.dirPill)==null||je.addEventListener("click",()=>U("playlist")),(Ze=e.btnDrawerSettings)==null||Ze.addEventListener("click",()=>U("settings"));const ae=()=>{var o;n.arrowKeySwitchMode=!n.arrowKeySwitchMode,(o=e.btnArrowSwitchMode)==null||o.classList.toggle("is-active",n.arrowKeySwitchMode),e.btnSettingsArrowMode&&(e.btnSettingsArrowMode.classList.toggle("is-active",n.arrowKeySwitchMode),e.btnSettingsArrowMode.textContent=n.arrowKeySwitchMode?"同目錄換片":"快轉 ±5秒"),ee({arrowKeySwitchMode:n.arrowKeySwitchMode}),s(n.arrowKeySwitchMode?te==null?void 0:te.arrowKeySwitchOnTip:te==null?void 0:te.arrowKeySwitchOffTip,2400)};(Qe=e.btnArrowSwitchMode)==null||Qe.addEventListener("click",ae),(Ye=e.btnSettingsArrowMode)==null||Ye.addEventListener("click",ae);const re=()=>{const o=g.toggleAutoRotate();n.autoRotate=o.autoRotate,ee({autoRotate:n.autoRotate}),s(n.autoRotate?"🔄 自動轉向無損最大化：已開啟 (Scale 1.00x)":"🔄 自動轉向：已關閉（維持手動角度）")};(Xe=e.btnAutoRotate)==null||Xe.addEventListener("click",re),(Je=e.btnSettingsAutoRotate)==null||Je.addEventListener("click",re),(et=e.btnRotate90)==null||et.addEventListener("click",()=>{const o=g.rotateBy(90);n.manualRotation=o.manualRotation,ee({manualRotation:n.manualRotation}),s(`↪️ 旋轉角度：${o.effectiveRotation}° (Scale 1.00x 無損最大化)`,1500)}),e.settingsRotationGroup&&e.settingsRotationGroup.querySelectorAll("[data-rot]").forEach(o=>{o.addEventListener("click",()=>{const d=Number(o.getAttribute("data-rot"))||0,u=g.setManualRotation(d);n.manualRotation=u.manualRotation,ee({manualRotation:n.manualRotation}),s(`↪️ 已設定基準角度：${d}°`)})});const x=()=>{n.simPortrait=!n.simPortrait,ee({simPortrait:n.simPortrait});const o=n.simPortrait?"portrait":"none",d=g.setSimulateViewport(o);s(n.simPortrait?`📱 已切換至 9:16 直向手機框（自動旋轉: ${d.effectiveRotation}°）`:"🖥️ 已恢復 100% 滿版寬螢幕視窗")};(tt=e.btnSimPortrait)==null||tt.addEventListener("click",x),(nt=e.btnSettingsSimPortrait)==null||nt.addEventListener("click",x);const X=()=>{const o=p.toggleHwDecode();ee({hwDecodeEnabled:o}),g.recalculate(),s(o?"⚡ GPU 硬體解碼已開啟 (Zero-Copy MPO 優先)":"🖥️ 已切換為軟體解碼模式")};(it=e.btnHwDecode)==null||it.addEventListener("click",X),(ot=e.btnPanelHwToggle)==null||ot.addEventListener("click",X),(at=e.btnSettingsHwDecode)==null||at.addEventListener("click",X);const de=()=>{var d,u;const o=p.togglePowerSave();(u=(d=ce(e.video))==null?void 0:d.setPowerSaveMode)==null||u.call(d,o),ee({powerSaveEnabled:o}),s(o?"🍃 智慧節省電力模式已開啟 (4Hz UI Tick • CPU 深度節電)":"🔥 已切換為全速效能模式 (60Hz)")};(rt=e.btnPowerSave)==null||rt.addEventListener("click",de),(st=e.btnPanelPowerToggle)==null||st.addEventListener("click",de),(lt=e.btnSettingsPowerSave)==null||lt.addEventListener("click",de),(dt=e.hwPowerPill)==null||dt.addEventListener("click",()=>U("hw")),(ct=e.btnDrawerHw)==null||ct.addEventListener("click",()=>U("hw")),(ut=e.btnDrawerEq)==null||ut.addEventListener("click",()=>U("eq")),(pt=e.btnDrawerPlaylist)==null||pt.addEventListener("click",()=>U("playlist")),document.querySelectorAll("[data-close-drawer]").forEach(o=>{o.addEventListener("click",()=>U(null))});const ye=()=>{var o,d;n.showGestureGuide=!n.showGestureGuide,(o=e.gestureLayer)==null||o.classList.toggle("show-guide",n.showGestureGuide),(d=e.btnGestureGuide)==null||d.classList.toggle("is-active",n.showGestureGuide),e.btnSettingsGestureGuide&&(e.btnSettingsGestureGuide.classList.toggle("is-active",n.showGestureGuide),e.btnSettingsGestureGuide.textContent=n.showGestureGuide?"已開啟":"已隱藏"),ee({showGestureGuide:n.showGestureGuide})};(mt=e.btnGestureGuide)==null||mt.addEventListener("click",ye),(gt=e.btnSettingsGestureGuide)==null||gt.addEventListener("click",ye),(vt=e.btnSettingsOpenOta)==null||vt.addEventListener("click",()=>Ae()),(bt=e.btnSettingsCheckOta)==null||bt.addEventListener("click",()=>Ee(!1)),(ft=e.btnSettingsUpgradeApk)==null||ft.addEventListener("click",()=>{Ae(),Ge()}),(ht=e.settingsSliderBrightness)==null||ht.addEventListener("input",o=>{k(Number(o.target.value),{source:"settings-slider"})}),(yt=e.btnSettingsResetBrightness)==null||yt.addEventListener("click",()=>{k(85,{source:"settings-reset"}),s("☀️ 亮度已重設為標準 85%（並已記憶）",1400)}),(wt=e.settingsSliderVolume)==null||wt.addEventListener("input",o=>{C(Number(o.target.value),{source:"settings-slider"})}),e.settingsSensitivityGroup&&e.settingsSensitivityGroup.querySelectorAll("[data-sens]").forEach(o=>{o.addEventListener("click",()=>{const d=Number(o.getAttribute("data-sens"))||1.2;n.gestureSensitivity=d,ee({gestureSensitivity:d}),e.settingsSensitivityGroup.querySelectorAll("[data-sens]").forEach(u=>{u.classList.toggle("is-active",Number(u.getAttribute("data-sens"))===d)}),s(`👆 手勢垂直滑動靈敏度已設為 ${d}x`)})}),(St=e.btnSettingsRememberResume)==null||St.addEventListener("click",()=>{n.rememberResumePosition=!n.rememberResumePosition,e.btnSettingsRememberResume.classList.toggle("is-active",n.rememberResumePosition),e.btnSettingsRememberResume.textContent=n.rememberResumePosition?"已開啟":"已關閉",ee({rememberResumePosition:n.rememberResumePosition}),s(n.rememberResumePosition?"⏱️ 自動記憶播放進度：已開啟":"⏱️ 自動記憶播放進度：已關閉")}),(Et=e.btnSettingsFactoryReset)==null||Et.addEventListener("click",()=>{var d,u,v;const o=Ai();k(o.brightness,{source:"factory-reset"}),C(o.volume,{source:"factory-reset"}),n.autoRotate=o.autoRotate,n.manualRotation=o.manualRotation,n.simPortrait=o.simPortrait,n.arrowKeySwitchMode=o.arrowKeySwitchMode,n.showGestureGuide=o.showGestureGuide,n.rememberResumePosition=o.rememberResumePosition,g.setAutoRotate(n.autoRotate),g.setManualRotation(n.manualRotation),g.setSimulateViewport(n.simPortrait?"portrait":"none"),p.setHwDecodeEnabled(o.hwDecodeEnabled),p.setPowerSaveEnabled(o.powerSaveEnabled),(d=e.gestureLayer)==null||d.classList.toggle("show-guide",n.showGestureGuide),(u=e.btnGestureGuide)==null||u.classList.toggle("is-active",n.showGestureGuide),(v=e.btnArrowSwitchMode)==null||v.classList.toggle("is-active",n.arrowKeySwitchMode),e.btnSettingsArrowMode&&(e.btnSettingsArrowMode.classList.toggle("is-active",n.arrowKeySwitchMode),e.btnSettingsArrowMode.textContent="同目錄換片"),h.reset(),H(),s("✅ 已恢復所有出廠預設設定（亮度 85% / 硬體解碼開啟 / 節電開啟）")}),(Pt=e.btnOpenFile)==null||Pt.addEventListener("click",()=>{var o;return(o=e.inputVideoFile)==null?void 0:o.click()}),(Bt=e.btnDrawerAddFile)==null||Bt.addEventListener("click",()=>{var o;return(o=e.inputVideoFile)==null?void 0:o.click()}),(Tt=e.inputVideoFile)==null||Tt.addEventListener("change",o=>{b(o.target.files),o.target.value=""}),(At=e.btnOpenFolder)==null||At.addEventListener("click",O),(It=e.btnDrawerOpenFolder)==null||It.addEventListener("click",O),(Mt=e.inputFolderFiles)==null||Mt.addEventListener("change",o=>{b(o.target.files),o.target.value=""}),(Rt=e.btnDrawerResetDemo)==null||Rt.addEventListener("click",()=>{n.playlist=[...vn],n.directoryName="內建比例測試目錄",n.directoryPath="內建 4 組多比例幾何測試串流 (16:9 / 9:16 / 21:9 / 4:3)",I(0,!0),s("🎞️ 已切換回內建 4 組多比例測試串流")}),(Lt=e.btnOpenSub)==null||Lt.addEventListener("click",()=>{var o;return(o=e.inputSubFile)==null?void 0:o.click()}),(Ct=e.inputSubFile)==null||Ct.addEventListener("change",o=>{b(o.target.files),o.target.value=""}),(kt=e.btnOpenUrl)==null||kt.addEventListener("click",()=>Y("url")),(Vt=e.btnModalShortcuts)==null||Vt.addEventListener("click",()=>Y("shortcuts")),document.querySelectorAll("[data-close-modal]").forEach(o=>{o.addEventListener("click",L)}),(Dt=e.btnConfirmUrl)==null||Dt.addEventListener("click",()=>{var u,v;const o=(v=(u=e.inputStreamUrl)==null?void 0:u.value)==null?void 0:v.trim();if(!o)return;const d={id:`url-${Date.now()}`,title:o.split("/").pop()||"遠端串流影片",subtitle:o,url:o,aspectLabel:"Stream",isDemo:!1};n.playlist.push(d),L(),I(n.playlist.length-1,!0),s("🔗 已載入遠端串流網址")}),($t=e.btnScreenshot)==null||$t.addEventListener("click",Z);const pe=()=>{var P,j,z,Q,q;const o=Number(((P=e.eqBassSlider)==null?void 0:P.value)||0),d=Number(((j=e.eqMidSlider)==null?void 0:j.value)||0),u=Number(((z=e.eqTrebleSlider)==null?void 0:z.value)||0),v=Number(((Q=e.eqBoostSlider)==null?void 0:Q.value)||1),A=h.setValues({preset:"custom",bass:o,mid:d,treble:u,boost:v});(q=ce(e.video))==null||q.setEqGains(A),ee({eqPreset:"custom",eqCustom:{bass:A.bass,mid:A.mid,treble:A.treble,boost:A.boost}}),H()};(xt=e.eqBassSlider)==null||xt.addEventListener("input",pe),(Nt=e.eqMidSlider)==null||Nt.addEventListener("input",pe),(Ot=e.eqTrebleSlider)==null||Ot.addEventListener("input",pe),(Ft=e.eqBoostSlider)==null||Ft.addEventListener("input",pe),(_t=e.btnEqReset)==null||_t.addEventListener("click",()=>{var d;const o=h.reset();(d=ce(e.video))==null||d.setEqGains(o),ee({eqPreset:"flat",eqCustom:{bass:0,mid:0,treble:0,boost:1}}),H(),s("🎚️ 已重設為原音直通 (Flat)")}),(Ht=e.btnPlayPause)==null||Ht.addEventListener("click",()=>D("control-bar")),(qt=e.btnPrevVideo)==null||qt.addEventListener("click",()=>M(-1,"control-prev")),(Gt=e.btnNextVideo)==null||Gt.addEventListener("click",()=>M(1,"control-next")),(zt=e.btnEdgePrev)==null||zt.addEventListener("click",o=>{o.stopPropagation(),M(-1,"edge-prev")}),(Ut=e.btnEdgeNext)==null||Ut.addEventListener("click",o=>{o.stopPropagation(),M(1,"edge-next")}),(Wt=e.btnSeekBack)==null||Wt.addEventListener("click",()=>w(-10)),(Kt=e.btnSeekForward)==null||Kt.addEventListener("click",()=>w(10)),(jt=e.btnStepBack)==null||jt.addEventListener("click",()=>{const o=ce(e.video);o?(o.pause(),o.stepFrame(-1)):e.video&&(e.video.pause(),w(-1/60)),S(!1)}),(Zt=e.btnStepForward)==null||Zt.addEventListener("click",()=>{const o=ce(e.video);o?(o.pause(),o.stepFrame(1)):e.video&&(e.video.pause(),w(1/60)),S(!1)}),(Qt=e.sliderBrightness)==null||Qt.addEventListener("input",o=>{k(Number(o.target.value),{source:"slider"})}),(Yt=e.btnBrightnessReset)==null||Yt.addEventListener("click",()=>{k(85,{source:"reset"}),s("☀️ 亮度已重設為標準 85%（並已記憶）",1400)}),(Xt=e.sliderVolume)==null||Xt.addEventListener("input",o=>{C(Number(o.target.value),{source:"slider"})}),(Jt=e.btnMuteToggle)==null||Jt.addEventListener("click",N),(en=e.selectSpeed)==null||en.addEventListener("change",o=>{var u;const d=Number(o.target.value)||1;n.playbackRate=d,e.video&&(e.video.playbackRate=d),(u=ce(e.video))==null||u.setPlaybackRate(d),ee({playbackRate:d}),s(`⏩ 播放速度：${d}x`,1300)});const me=()=>{if(!e.btnLoopMode)return;const o={all:"🔁 循環: 全部",one:"🔂 循環: 單曲",off:"➡️ 循環: 關閉"};e.btnLoopMode.textContent=o[n.loopMode]||o.all};me(),(tn=e.btnLoopMode)==null||tn.addEventListener("click",()=>{const o=["all","one","off"],d=(o.indexOf(n.loopMode)+1)%o.length;n.loopMode=o[d],ee({loopMode:n.loopMode}),me()}),(nn=e.btnSubToggle)==null||nn.addEventListener("click",()=>{n.subtitlesEnabled=!n.subtitlesEnabled,e.btnSubToggle.classList.toggle("is-active",n.subtitlesEnabled),K(),s(n.subtitlesEnabled?"💬 字幕顯示：已開啟":"💬 字幕顯示：已隱藏",1300)}),(on=e.btnPip)==null||on.addEventListener("click",async()=>{var o;try{document.pictureInPictureElement?await document.exitPictureInPicture():(o=e.video)!=null&&o.requestPictureInPicture?await e.video.requestPictureInPicture():s("⚠️ 瀏覽器不支援子母畫面")}catch{s("⚠️ 無法進入子母畫面模式")}});const We=async()=>{var o,d,u,v,A;try{document.fullscreenElement?await((A=document.exitFullscreen)==null?void 0:A.call(document)):await(((d=(o=e.app)==null?void 0:o.requestFullscreen)==null?void 0:d.call(o))||((v=(u=document.documentElement).requestFullscreen)==null?void 0:v.call(u)))}catch{}};if((an=e.btnFullscreen)==null||an.addEventListener("click",We),(rn=e.btnSetPointA)==null||rn.addEventListener("click",()=>{const{currentTime:o}=R();n.abLoop.a=o,n.abLoop.b!==null&&n.abLoop.b<=n.abLoop.a&&(n.abLoop.b=null),se(),s(`🅰️ 已設定 A 點起點：${ve(o)}`,1400)}),(sn=e.btnSetPointB)==null||sn.addEventListener("click",()=>{const{currentTime:o}=R();n.abLoop.a===null&&(n.abLoop.a=0),o>n.abLoop.a+.3?(n.abLoop.b=o,se(),s(`🅱️ 已啟動 A-B 區間循環：${ve(n.abLoop.a)} → ${ve(n.abLoop.b)}`,1600)):s("⚠️ B 點必須大於 A 點時間",1400)}),(ln=e.btnClearAb)==null||ln.addEventListener("click",()=>{le(),s("已清除 A-B 區間循環",1300)}),e.progressWrap){const o=u=>{const v=e.progressWrap.getBoundingClientRect(),A=Math.max(0,Math.min(1,(u-v.left)/Math.max(1,v.width))),{duration:P}=R(),j=P>0?P:120;return{ratio:A,targetSec:A*j}};e.progressWrap.addEventListener("pointermove",u=>{const{ratio:v,targetSec:A}=o(u.clientX);e.timeTooltip&&(e.timeTooltip.style.left=`${(v*100).toFixed(1)}%`,e.timeTooltip.textContent=ve(A)),n.isScrubbing&&V(A)}),e.progressWrap.addEventListener("pointerdown",u=>{var A,P;n.isScrubbing=!0,(P=(A=e.progressWrap).setPointerCapture)==null||P.call(A,u.pointerId);const{targetSec:v}=o(u.clientX);V(v)});const d=u=>{var v,A;if(n.isScrubbing){n.isScrubbing=!1;try{(A=(v=e.progressWrap).releasePointerCapture)==null||A.call(v,u.pointerId)}catch{}}};e.progressWrap.addEventListener("pointerup",d),e.progressWrap.addEventListener("pointercancel",d)}(dn=e.video)==null||dn.addEventListener("timeupdate",()=>{Be(e.video)||K()}),(cn=e.video)==null||cn.addEventListener("play",()=>S(!0)),(un=e.video)==null||un.addEventListener("pause",()=>S(!1)),(pn=e.video)==null||pn.addEventListener("ended",()=>{Be(e.video)||G()}),window.addEventListener("dragover",o=>{var d;o.preventDefault(),(d=e.dropOverlay)==null||d.classList.add("is-active")}),window.addEventListener("dragleave",o=>{var d;o.relatedTarget||(d=e.dropOverlay)==null||d.classList.remove("is-active")}),window.addEventListener("drop",async o=>{var d;if(o.preventDefault(),(d=e.dropOverlay)==null||d.classList.remove("is-active"),o.dataTransfer){const u=await $i(o.dataTransfer);u.files.length>0&&b(u.files,u.folderName)}}),window.addEventListener("storage",o=>{o.key==="vp_brightness"&&o.newValue!==null&&k(Number(o.newValue),{source:"storage-sync"})}),window.addEventListener("keydown",o=>{var d,u,v,A,P;if(o.target&&(o.target.tagName==="INPUT"||o.target.tagName==="TEXTAREA"||o.target.tagName==="SELECT")){o.key==="Escape"&&L();return}switch(o.key){case" ":case"k":case"K":o.preventDefault(),D("keyboard");break;case"PageUp":case"p":case"P":case"MediaTrackPrevious":o.preventDefault(),M(-1,"keyboard-prev");break;case"PageDown":case"n":case"N":case"MediaTrackNext":o.preventDefault(),M(1,"keyboard-next");break;case"ArrowLeft":o.preventDefault(),o.shiftKey||n.arrowKeySwitchMode?M(-1,"keyboard-arrow-prev"):w(-5);break;case"ArrowRight":o.preventDefault(),o.shiftKey||n.arrowKeySwitchMode?M(1,"keyboard-arrow-next"):w(5);break;case"ArrowUp":o.preventDefault(),C(n.volume+5,{source:"keyboard"});break;case"ArrowDown":o.preventDefault(),C(n.volume-5,{source:"keyboard"});break;case"w":case"W":o.preventDefault(),k(n.brightness+5,{source:"keyboard"});break;case"s":case"S":o.preventDefault(),k(n.brightness-5,{source:"keyboard"});break;case"r":case"R":o.preventDefault(),(d=e.btnRotate90)==null||d.click();break;case"a":case"A":o.preventDefault(),(u=e.btnAutoRotate)==null||u.click();break;case"m":case"M":o.preventDefault(),N();break;case"f":case"F":o.preventDefault(),We();break;case"g":case"G":o.preventDefault(),(v=e.btnGestureGuide)==null||v.click();break;case"e":case"E":o.preventDefault(),de();break;case",":case"o":case"O":o.preventDefault(),U("settings");break;case"u":case"U":o.preventDefault(),Ae();break;case"[":o.preventDefault(),(A=e.btnSetPointA)==null||A.click();break;case"]":o.preventDefault(),(P=e.btnSetPointB)==null||P.click();break;case"Escape":L(),U(null);break}});let Ce=null;function Ke(){Ce&&clearTimeout(Ce);const o=p.getEcoTickInterval(!0);Ce=setTimeout(()=>{T(p.getTelemetry());const d=n.playlist[n.currentIndex],{currentTime:u,duration:v,paused:A}=R();n.rememberResumePosition&&d&&!A&&u>1&&Pn(d.id,u,v),Ke()},o)}try{k(n.brightness,{source:"init-restore"}),C(n.volume,{source:"init"}),H(),T(p.getTelemetry()),Qn(),I(n.currentIndex,!0),Ke()}catch(o){console.error("[OmniPlay Boot] Safe boot recovery:",o)}}try{document.readyState==="loading"?document.addEventListener("DOMContentLoaded",An):An()}catch(t){console.error("[OmniPlay Entry] Fatal protection caught:",t)}
